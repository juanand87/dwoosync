<?php
// Redirigir al panel de administración
header('Location: admin/index.php');
exit;
?>

