<?php
// Debug del plugin
$plugin_paths = [
    '../../wordpress/wp-content/plugins/Discogs-Importer/',
    '../../../wordpress/wp-content/plugins/Discogs-Importer/',
    '../../../../wordpress/wp-content/plugins/Discogs-Importer/',
    'C:/xampp/htdocs/wordpress/wp-content/plugins/Discogs-Importer/'
];

echo "<h1>Debug Plugin Paths</h1>";

foreach ($plugin_paths as $path) {
    echo "<h2>Probando: $path</h2>";
    echo "<p>Existe: " . (is_dir($path) ? 'SÍ' : 'NO') . "</p>";
    
    if (is_dir($path)) {
        $files = [];
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path));
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $relative_path = str_replace($path . DIRECTORY_SEPARATOR, '', $file->getPathname());
                $files[] = $relative_path;
            }
        }
        echo "<p>Archivos encontrados: " . count($files) . "</p>";
        echo "<ul>";
        foreach (array_slice($files, 0, 20) as $file) {
            echo "<li>$file</li>";
        }
        if (count($files) > 20) {
            echo "<li>... y " . (count($files) - 20) . " más</li>";
        }
        echo "</ul>";
    }
}
?>
