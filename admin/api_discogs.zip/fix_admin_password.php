<?php
/**
 * Script para corregir la contraseña del administrador
 */

define('API_ACCESS', true);
require_once 'config/config.php';
require_once 'classes/Database.php';

try {
    $db = Database::getInstance();
    
    // Generar hash correcto para admin123
    $password = 'admin123';
    $hash = password_hash($password, PASSWORD_DEFAULT);
    
    echo "Generando hash para contraseña: $password\n";
    echo "Hash generado: $hash\n";
    
    // Actualizar la contraseña en la base de datos
    $sql = "UPDATE admin_users SET password_hash = :hash WHERE username = 'admin'";
    $result = $db->query($sql, ['hash' => $hash]);
    
    if ($result) {
        echo "✅ Contraseña actualizada correctamente\n";
        
        // Verificar que se actualizó
        $user = $db->fetch("SELECT username, password_hash FROM admin_users WHERE username = 'admin'");
        echo "Usuario: " . $user['username'] . "\n";
        echo "Hash en BD: " . $user['password_hash'] . "\n";
        
        // Probar verificación
        if (password_verify($password, $user['password_hash'])) {
            echo "✅ Verificación de contraseña exitosa\n";
        } else {
            echo "❌ Error en verificación de contraseña\n";
        }
    } else {
        echo "❌ Error actualizando contraseña\n";
    }
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
}
