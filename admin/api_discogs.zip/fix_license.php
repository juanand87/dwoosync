<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>Corrigiendo Licencia</h1>";

try {
    define('API_ACCESS', true);
    require_once __DIR__ . '/config/config.php';
    require_once __DIR__ . '/classes/Database.php';
    
    $db = Database::getInstance();
    
    // Verificar estado actual
    echo "<h3>Estado actual:</h3>";
    $license = $db->fetch("SELECT * FROM licenses WHERE id = 1");
    echo "Status: '" . $license['status'] . "'<br>";
    echo "Usage Count: " . $license['usage_count'] . "<br>";
    echo "Usage Limit: " . $license['usage_limit'] . "<br><br>";
    
    // Actualizar la licencia para asegurar que esté activa
    echo "<h3>Actualizando licencia...</h3>";
    $result = $db->update(
        'licenses',
        ['status' => 'active'],
        'id = :id',
        ['id' => 1]
    );
    
    if ($result) {
        echo "✅ Licencia actualizada<br>";
        
        // Verificar el cambio
        $updatedLicense = $db->fetch("SELECT * FROM licenses WHERE id = 1");
        echo "<h3>Estado después de la actualización:</h3>";
        echo "Status: '" . $updatedLicense['status'] . "'<br>";
        echo "Usage Count: " . $updatedLicense['usage_count'] . "<br>";
        echo "Usage Limit: " . $updatedLicense['usage_limit'] . "<br>";
        
        if ($updatedLicense['status'] == 'active') {
            echo "<p style='color: green;'>✅ Licencia corregida correctamente</p>";
        } else {
            echo "<p style='color: red;'>❌ Error en la actualización</p>";
        }
    } else {
        echo "❌ Error al actualizar la licencia<br>";
    }
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "<br>";
}
?>
