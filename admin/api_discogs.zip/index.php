<?php
/**
 * Punto de entrada principal de la API
 * 
 * @package DiscogsAPI
 * @version 1.0.0
 */

// Redirigir a la API
header('Location: api/index.php');
exit;

