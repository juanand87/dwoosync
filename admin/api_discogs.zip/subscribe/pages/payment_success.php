<?php
/**
 * Página de confirmación de pago exitoso
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

// Iniciar sesión de forma segura
startSecureSession();

// Verificar que el usuario está logueado
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$plan_type = $_SESSION['plan_type'] ?? 'free';

// Obtener información del usuario
$db = getDatabase();
$stmt = $db->prepare("
    SELECT s.*, l.license_key 
    FROM subscribers s 
    LEFT JOIN licenses l ON s.id = l.subscriber_id 
    WHERE s.id = ?
");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user) {
    header('Location: login.php');
    exit;
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pago Exitoso - DiscogsSync</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .success-container {
            max-width: 600px;
            margin: 0 auto;
            padding: 2rem;
            text-align: center;
        }
        .success-card {
            background: white;
            border-radius: 16px;
            padding: 3rem;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            margin-bottom: 2rem;
        }
        .success-icon {
            font-size: 4rem;
            color: #10b981;
            margin-bottom: 1rem;
        }
        .license-info {
            background: #f8fafc;
            border-radius: 12px;
            padding: 1.5rem;
            margin: 2rem 0;
            text-align: left;
        }
        .license-key {
            background: #1f2937;
            color: #10b981;
            padding: 1rem;
            border-radius: 8px;
            font-family: monospace;
            font-size: 1.1rem;
            margin: 1rem 0;
            word-break: break-all;
        }
        .btn-copy {
            background: #10b981;
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.9rem;
            margin-left: 0.5rem;
        }
        .btn-copy:hover {
            background: #059669;
        }
        .next-steps {
            background: #f0fdf4;
            border: 1px solid #10b981;
            border-radius: 12px;
            padding: 1.5rem;
            margin: 2rem 0;
            text-align: left;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-logo">
                    <a href="../index.php" style="text-decoration: none; color: inherit;">
                        <h2><i class="fas fa-music"></i> DiscogsSync</h2>
                    </a>
                </div>
                <div class="nav-menu">
                    <a href="dashboard.php" class="nav-link btn-login">Ir al Dashboard</a>
                </div>
            </div>
        </nav>
    </header>

    <!-- Main Content -->
    <main style="padding-top: 100px; min-height: 100vh; background: #f8fafc;">
        <div class="success-container">
            <div class="success-card">
                <div class="success-icon">
                    <i class="fas fa-check-circle"></i>
                </div>
                
                <h1 style="color: #1f2937; margin-bottom: 1rem;">
                    ¡Pago Exitoso!
                </h1>
                
                <p style="color: #6b7280; font-size: 1.1rem; margin-bottom: 2rem;">
                    Tu suscripción mensual ha sido activada correctamente.
                </p>
                
                <div class="license-info">
                    <h3 style="margin: 0 0 1rem 0; color: #1f2937;">
                        <i class="fas fa-key"></i> Información de tu Licencia
                    </h3>
                    
                    <div style="margin-bottom: 1rem;">
                        <strong>Plan:</strong> <?php echo ucfirst($plan_type); ?><br>
                        <strong>Estado:</strong> <span style="color: #10b981; font-weight: bold;">Activo</span><br>
                        <strong>Dominio:</strong> <?php echo htmlspecialchars($user['domain']); ?>
                    </div>
                    
                    <div>
                        <label style="display: block; margin-bottom: 0.5rem; font-weight: bold;">
                            Clave de Licencia:
                        </label>
                        <div class="license-key" id="license-key">
                            <?php echo htmlspecialchars($user['license_key']); ?>
                        </div>
                        <button class="btn-copy" onclick="copyLicenseKey()">
                            <i class="fas fa-copy"></i> Copiar
                        </button>
                    </div>
                </div>
                
                <div class="next-steps">
                    <h4 style="margin: 0 0 1rem 0; color: #1f2937;">
                        <i class="fas fa-list-check"></i> Próximos Pasos
                    </h4>
                    <ol style="margin: 0; padding-left: 1.5rem; color: #374151;">
                        <li style="margin-bottom: 0.5rem;">
                            <strong>Instala el plugin</strong> en tu sitio WordPress
                        </li>
                        <li style="margin-bottom: 0.5rem;">
                            <strong>Configura la licencia</strong> con la clave proporcionada
                        </li>
                        <li style="margin-bottom: 0.5rem;">
                            <strong>Configura tus credenciales</strong> de Discogs API
                        </li>
                        <li style="margin-bottom: 0.5rem;">
                            <strong>¡Comienza a sincronizar!</strong> tus productos
                        </li>
                    </ol>
                </div>
                
                <div style="margin-top: 2rem;">
                    <a href="dashboard.php" class="btn btn-primary btn-large">
                        <i class="fas fa-tachometer-alt"></i> Ir al Dashboard
                    </a>
                </div>
            </div>
        </div>
    </main>

    <script src="../assets/js/script.js"></script>
    <script>
        function copyLicenseKey() {
            const licenseKey = document.getElementById('license-key').textContent;
            
            if (navigator.clipboard && window.isSecureContext) {
                // Usar la API moderna del clipboard
                navigator.clipboard.writeText(licenseKey).then(function() {
                    showCopySuccess();
                }).catch(function() {
                    fallbackCopyTextToClipboard(licenseKey);
                });
            } else {
                // Fallback para navegadores más antiguos
                fallbackCopyTextToClipboard(licenseKey);
            }
        }
        
        function fallbackCopyTextToClipboard(text) {
            const textArea = document.createElement("textarea");
            textArea.value = text;
            textArea.style.top = "0";
            textArea.style.left = "0";
            textArea.style.position = "fixed";
            textArea.style.opacity = "0";
            
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();
            
            try {
                const successful = document.execCommand('copy');
                if (successful) {
                    showCopySuccess();
                } else {
                    showCopyError();
                }
            } catch (err) {
                showCopyError();
            }
            
            document.body.removeChild(textArea);
        }
        
        function showCopySuccess() {
            const button = event.target;
            const originalText = button.innerHTML;
            button.innerHTML = '<i class="fas fa-check"></i> ¡Copiado!';
            button.style.background = '#10b981';
            
            setTimeout(() => {
                button.innerHTML = originalText;
                button.style.background = '#10b981';
            }, 2000);
        }
        
        function showCopyError() {
            const button = event.target;
            const originalText = button.innerHTML;
            button.innerHTML = '<i class="fas fa-times"></i> Error';
            button.style.background = '#ef4444';
            
            setTimeout(() => {
                button.innerHTML = originalText;
                button.style.background = '#10b981';
            }, 2000);
        }
    </script>
</body>
</html>