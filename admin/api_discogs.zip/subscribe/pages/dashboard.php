<?php
// Definir constante para acceso a la API
define('API_ACCESS', true);

// Incluir configuración de base de datos
require_once '../../config/database.php';

// Verificar sesión
session_start();
if (!isset($_SESSION['subscriber_id'])) {
    header('Location: ../index.php');
    exit;
}

$subscriber_id = $_SESSION['subscriber_id'];
$license_key = $_SESSION['license_key'] ?? '';

// Obtener información del suscriptor
$subscriber = $pdo->prepare("SELECT * FROM subscribers WHERE id = ?");
$subscriber->execute([$subscriber_id]);
$subscriber_data = $subscriber->fetch(PDO::FETCH_ASSOC);

// Obtener información de la licencia
$license = $pdo->prepare("SELECT * FROM licenses WHERE subscriber_id = ? AND license_key = ?");
$license->execute([$subscriber_id, $license_key]);
$license_data = $license->fetch(PDO::FETCH_ASSOC);

// Obtener ciclo activo actual
$current_billing_cycle = $pdo->prepare("
    SELECT * FROM billing_cycles 
    WHERE subscriber_id = ? AND license_key = ? AND is_active = 1
");
$current_billing_cycle->execute([$subscriber_id, $license_key]);
$cycle_data = $current_billing_cycle->fetch(PDO::FETCH_ASSOC);

// Obtener ciclo de facturación más reciente del suscriptor
$current_billing_cycle = $pdo->prepare("
    SELECT * FROM billing_cycles 
    WHERE subscriber_id = ? AND license_key = ?
     ORDER BY created_at DESC 
    LIMIT 1
");
$current_billing_cycle->execute([$subscriber_id, $license_key]);
$billing_cycle_data = $current_billing_cycle->fetch(PDO::FETCH_ASSOC);


// Obtener historial de ciclos (últimos 6)
$billing_cycle_history = $pdo->prepare("
    SELECT * FROM billing_cycles 
    WHERE subscriber_id = ? AND license_key = ? 
    ORDER BY cycle_start_date DESC 
    LIMIT 6
");
$billing_cycle_history->execute([$subscriber_id, $license_key]);
$history_data = $billing_cycle_history->fetchAll(PDO::FETCH_ASSOC);

// Obtener estadísticas de uso diario (últimos 30 días)
$daily_stats = $pdo->prepare("
    SELECT date, requests_count, requests_successful, requests_failed 
    FROM usage_stats 
     WHERE subscriber_id = ? 
    ORDER BY date DESC 
    LIMIT 30
");
$daily_stats->execute([$subscriber_id]);
$daily_data = $daily_stats->fetchAll(PDO::FETCH_ASSOC);


// Calcular días restantes del ciclo actual
$days_remaining = 0;
if ($cycle_data && $cycle_data['cycle_end_date']) {
    $end_date = new DateTime($cycle_data['cycle_end_date']);
    $today = new DateTime();
    $days_remaining = $today->diff($end_date)->days;
    if ($today > $end_date) {
        $days_remaining = 0; // Ciclo expirado
    }
}

// Calcular porcentajes de uso (solo para importaciones, las llamadas API no tienen límite)
$sync_percentage = 0;
if ($license_data && $cycle_data) {
    $sync_percentage = ($cycle_data['sync_count'] / $license_data['usage_limit']) * 100;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - dwoosync</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/pages.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            min-height: 100vh;
        }
        
        .header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            padding: 20px;
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
        }
        
        .nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1400px;
            margin: 0 auto;
        }
        
        .logo {
            font-size: 28px;
            font-weight: bold;
            background: linear-gradient(45deg, #10b981, #059669);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .nav-links {
            display: flex;
            gap: 20px;
        }
        
        .nav-links a {
            color: #333;
            text-decoration: none;
            padding: 12px 20px;
            border-radius: 25px;
            transition: all 0.3s ease;
            font-weight: 500;
        }
        
        .nav-links a:hover {
            background: linear-gradient(45deg, #10b981, #059669);
            color: white;
            transform: translateY(-2px);
        }
        
        .btn-logout {
            background: linear-gradient(45deg, #ef4444, #dc2626);
            color: white;
        }
        
        .btn-logout:hover {
            background: linear-gradient(45deg, #dc2626, #b91c1c);
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 30px 20px;
        }
        
        .dashboard-header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            text-align: center;
        }
        
        .dashboard-header h1 {
            background: linear-gradient(45deg, #10b981, #059669);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 15px;
            font-size: 2.5rem;
        }
        
        .dashboard-header p {
            color: #666;
            font-size: 1.2rem;
        }
        
        .welcome-info {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 20px;
            padding: 20px;
            background: rgba(102, 126, 234, 0.1);
            border-radius: 15px;
        }
        
        .welcome-info h2 {
            color: #333;
            font-size: 1.5rem;
        }
        
        .welcome-info .plan-badge {
            background: linear-gradient(45deg, #10b981, #059669);
            color: white;
            padding: 10px 20px;
            border-radius: 25px;
            font-weight: 600;
            font-size: 1.1rem;
        }
        
        .plan-container {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .plan-badge.free {
            background: linear-gradient(45deg, #6b7280, #4b5563);
        }
        
        .btn-upgrade {
            background: linear-gradient(45deg, #f59e0b, #d97706);
            color: white;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }
        
        .btn-upgrade:hover {
            background: linear-gradient(45deg, #d97706, #b45309);
            transform: translateY(-2px);
            box-shadow: 0 8px 16px rgba(245, 158, 11, 0.3);
        }
        
        .plan-info {
            text-align: center;
            padding: 20px;
        }
        
        .plan-badge-large {
            display: inline-block;
            background: linear-gradient(45deg, #10b981, #059669);
            color: white;
            padding: 15px 30px;
            border-radius: 30px;
            font-weight: 700;
            font-size: 1.5rem;
            margin-bottom: 20px;
            box-shadow: 0 8px 20px rgba(16, 185, 129, 0.3);
        }
        
        .plan-badge-large.free {
            background: linear-gradient(45deg, #6b7280, #4b5563);
            box-shadow: 0 8px 20px rgba(107, 114, 128, 0.3);
        }
        
        .plan-badge-large.premium {
            background: linear-gradient(45deg, #10b981, #059669);
            box-shadow: 0 8px 20px rgba(102, 126, 234, 0.3);
        }
        
        .plan-badge-large.enterprise {
            background: linear-gradient(45deg, #8b5cf6, #7c3aed);
            box-shadow: 0 8px 20px rgba(139, 92, 246, 0.3);
        }
        
        .plan-description {
            color: #6b7280;
            font-size: 1.1rem;
            line-height: 1.6;
            margin-bottom: 20px;
        }
        
        .btn-upgrade-spotify {
            background: linear-gradient(45deg, #8b5cf6, #7c3aed);
            color: white;
            padding: 12px 24px;
            border-radius: 25px;
            font-size: 1rem;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-upgrade-spotify:hover {
            background: linear-gradient(45deg, #7c3aed, #6d28d9);
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(139, 92, 246, 0.4);
        }
        
        .sync-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 25px;
        }
        
        .sync-stat-item {
            text-align: center;
            padding: 20px;
            background: linear-gradient(135deg, #f8fafc, #e2e8f0);
            border-radius: 15px;
            border: 2px solid #e2e8f0;
            transition: all 0.3s ease;
        }
        
        .sync-stat-item:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            border-color: #059669;
        }
        
        .sync-stat-number {
            font-size: 2.5rem;
            font-weight: bold;
            color: #1f2937;
            margin-bottom: 8px;
            background: linear-gradient(45deg, #10b981, #059669);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .sync-stat-label {
            color: #6b7280;
            font-size: 0.9rem;
            font-weight: 500;
        }
        
        .sync-stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin: 15px 0;
        }
        
        .sync-stats h4 {
            color: #1f2937;
            margin: 0 0 15px 0;
            font-size: 1.1rem;
            font-weight: 600;
        }
        
        .sync-count-simple {
            margin-top: 15px;
            padding: 10px 15px;
            background: linear-gradient(135deg, #f0f9ff, #e0f2fe);
            border: 1px solid #bae6fd;
            border-radius: 8px;
            color: #0c4a6e;
            font-size: 0.95rem;
            text-align: center;
        }
        
        .sync-info {
            background: linear-gradient(135deg, #dbeafe, #bfdbfe);
            border: 1px solid #93c5fd;
            border-radius: 12px;
            padding: 15px;
            margin-top: 20px;
        }
        
        .sync-info p {
            margin: 0;
            color: #1e40af;
            font-size: 0.95rem;
            line-height: 1.5;
        }
        
        .payment-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 10px;
            margin: 10px 0;
            transition: all 0.3s ease;
            border-left: 4px solid #e2e8f0;
        }
        
        .payment-item:hover {
            background: #e9ecef;
            transform: translateX(5px);
        }
        
        .payment-info {
            flex: 1;
        }
        
        .payment-date {
            font-weight: 600;
            color: #1f2937;
            font-size: 0.95rem;
            margin-bottom: 4px;
        }
        
        .payment-id {
            font-size: 0.8rem;
            color: #6b7280;
            font-family: 'Courier New', monospace;
        }
        
        .payment-details {
            text-align: right;
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
        
        .payment-amount {
            font-size: 1.2rem;
            font-weight: bold;
            color: #10b981;
        }
        
        .payment-status {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
        }
        
        .payment-status.completed {
            background: #d1fae5;
            color: #065f46;
        }
        
        .payment-status.pending {
            background: #fef3c7;
            color: #92400e;
        }
        
        .payment-status.failed {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .payment-method {
            font-size: 0.8rem;
            color: #6b7280;
            text-transform: capitalize;
        }
        
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }
        
        .dashboard-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.15);
        }
        
        .dashboard-card h3 {
            color: #333;
            margin-bottom: 20px;
            font-size: 1.4rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .cycle-info {
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
            padding: 25px;
            border-radius: 15px;
            margin-bottom: 20px;
        }
        
        .cycle-info h4 {
            font-size: 1.2rem;
            margin-bottom: 15px;
        }
        
        .cycle-dates {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-bottom: 15px;
        }
        
        .cycle-date {
            text-align: center;
            padding: 10px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 10px;
        }
        
        .cycle-date-label {
            font-size: 0.9rem;
            opacity: 0.8;
        }
        
        .cycle-date-value {
            font-size: 1.1rem;
            font-weight: bold;
        }
        
        .days-remaining {
            text-align: center;
            font-size: 1.3rem;
            font-weight: bold;
            margin-top: 10px;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        
        .stat-item {
            text-align: center;
            padding: 20px;
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            border-radius: 15px;
            transition: transform 0.3s ease;
        }
        
        .stat-item:hover {
            transform: scale(1.05);
        }
        
        .stat-number {
            font-size: 2.2rem;
            font-weight: bold;
            background: linear-gradient(45deg, #10b981, #059669);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 5px;
        }
        
        .stat-label {
            color: #666;
            font-size: 0.9rem;
            font-weight: 500;
        }
        
        .progress-container {
            margin: 20px 0;
        }
        
        .progress-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }
        
        .progress-label {
            font-weight: 600;
            color: #333;
        }
        
        .progress-percentage {
            font-weight: bold;
            color: #059669;
        }
        
        .progress-bar {
            width: 100%;
            height: 25px;
            background: #e5e7eb;
            border-radius: 15px;
            overflow: hidden;
            position: relative;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #10b981, #059669);
            border-radius: 15px;
            transition: width 0.5s ease;
            position: relative;
        }
        
        .progress-fill::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
            animation: shimmer 2s infinite;
        }
        
        @keyframes shimmer {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }
        
        .warning {
            background: linear-gradient(135deg, #fef3c7, #fde68a);
            color: #92400e;
            padding: 15px;
            border-radius: 10px;
            margin: 15px 0;
            border-left: 4px solid #f59e0b;
        }
        
        .danger {
            background: linear-gradient(135deg, #fee2e2, #fecaca);
            color: #991b1b;
            padding: 15px;
            border-radius: 10px;
            margin: 15px 0;
            border-left: 4px solid #dc2626;
        }
        
        .success {
            background: linear-gradient(135deg, #d1fae5, #a7f3d0);
            color: #065f46;
            padding: 15px;
            border-radius: 10px;
            margin: 15px 0;
            border-left: 4px solid #10b981;
        }
        
        .history-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 10px;
            margin: 10px 0;
            transition: background 0.3s ease;
        }
        
        .history-item:hover {
            background: #e9ecef;
        }
        
        .history-period {
            font-weight: 600;
            color: #333;
        }
        
        .history-stats {
            display: flex;
            gap: 20px;
            font-size: 0.9rem;
            color: #666;
        }
        
        .recent-activity {
            max-height: 400px;
            overflow-y: auto;
        }
        
        .activity-item {
            display: flex;
            align-items: center;
            padding: 12px;
            border-bottom: 1px solid #eee;
            gap: 15px;
        }
        
        .activity-item:last-child {
            border-bottom: none;
        }
        
        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
        }
        
        .activity-sync {
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
        }
        
        .activity-api {
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
        }
        
        .activity-info {
            flex: 1;
        }
        
        .activity-title {
            font-weight: 600;
            color: #333;
            margin-bottom: 2px;
        }
        
        .activity-time {
            font-size: 0.8rem;
            color: #666;
        }
        
        .btn {
            display: inline-block;
            padding: 15px 30px;
            background: linear-gradient(45deg, #10b981, #059669);
            color: white;
            text-decoration: none;
            border-radius: 25px;
            margin: 0;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            text-align: center;
            white-space: nowrap;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }
        
        .btn-secondary {
            background: linear-gradient(45deg, #6b7280, #4b5563);
        }
        
        .btn-secondary:hover {
            box-shadow: 0 10px 20px rgba(107, 114, 128, 0.3);
        }
        
        .btn-danger {
            background: linear-gradient(45deg, #dc2626, #b91c1c);
        }
        
        .btn-danger:hover {
            box-shadow: 0 10px 20px rgba(220, 38, 38, 0.3);
        }
        
        .btn-success {
            background: linear-gradient(45deg, #10b981, #059669);
        }
        
        .btn-success:hover {
            box-shadow: 0 10px 20px rgba(16, 185, 129, 0.3);
        }
        
        .actions {
            text-align: center;
            margin-top: 40px;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 15px;
            align-items: center;
        }
        
        @media (max-width: 768px) {
            .actions {
                flex-direction: column;
                gap: 10px;
            }
            
            .btn {
                width: 100%;
                max-width: 300px;
            }
        }
        
        .footer {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            color: #333;
            text-align: center;
            padding: 30px;
            margin-top: 50px;
        }
        
        .chart-container {
            height: 300px;
            margin: 20px 0;
        }
        
        .no-data {
            text-align: center;
            color: #666;
            font-style: italic;
            padding: 40px;
        }
        
        .info-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px solid #eee;
        }
        
        .info-item:last-child {
            border-bottom: none;
        }
        
        .info-label {
            font-weight: 600;
            color: #333;
            flex: 1;
        }
        
        .info-value {
            color: #666;
            font-family: 'Courier New', monospace;
            background: #f8f9fa;
            padding: 6px 12px;
            border-radius: 6px;
            border: 1px solid #e9ecef;
            word-break: break-all;
            max-width: 300px;
            text-align: right;
        }
        
        .license-key-container {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .license-key-value {
            color: #059669;
            font-family: 'Courier New', monospace;
            background: #f0f4ff;
            padding: 8px 12px;
            border-radius: 8px;
            border: 1px solid #d1d5db;
            word-break: break-all;
            flex: 1;
            font-size: 0.9rem;
            font-weight: 600;
        }
        
        .btn-copy {
            background: linear-gradient(45deg, #10b981, #059669);
            color: white;
            padding: 8px 12px;
            border-radius: 6px;
            font-size: 0.8rem;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 5px;
            white-space: nowrap;
        }
        
        .btn-copy:hover {
            background: linear-gradient(45deg, #059669, #047857);
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(16, 185, 129, 0.3);
        }
        
        .btn-copy.copied {
            background: linear-gradient(45deg, #f59e0b, #d97706);
        }
        
        .status {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
        }
        
        .status-active {
            background: #d1fae5;
            color: #065f46;
        }
        
        .status-inactive {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .status-pending {
            background: #fef3c7;
            color: #92400e;
        }
        
        @media (max-width: 768px) {
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
            
            .cycle-dates {
                grid-template-columns: 1fr;
            }
            
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .nav {
                flex-direction: column;
                gap: 20px;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-logo">
                        <h2><i class="fas fa-music"></i> dwoosync</h2>
                </div>
                <div class="nav-menu">
                    <a href="dashboard.php" class="nav-link">🏠 Inicio</a>
                    <a href="profile.php" class="nav-link">👤 Perfil</a>
                    <a href="billing.php" class="nav-link">💳 Facturación</a>
                    <a href="plugin-config.php" class="nav-link btn-primary">⚙️ Configurar Plugin</a>
                    <a href="logout.php" class="nav-link btn-logout">🚪 Cerrar Sesión</a>
                </div>
            </div>
        </nav>
    </header>

    <main style="padding-top: 100px; min-height: 100vh; background: #f8fafc;">
        <div class="container">
            <div class="card">
                    <div class="plan-container">
                        <div class="plan-badge <?php echo ($subscriber_data['plan_type'] ?? 'free') === 'free' ? 'free' : ''; ?>">
                            <?php 
                            $plan_type = $subscriber_data['plan_type'] ?? 'free';
                            echo $plan_type === 'enterprise' ? '+Spotify' : ucfirst($plan_type);
                            ?>
                        </div>
            </div>

                <!-- Cuadros de información principal -->
                <div class="grid grid-3" style="margin-top: 2rem;">
                    <!-- Cuadro 1: Importaciones realizadas -->
                    <div style="text-align: center; padding: 1.5rem; background: #f9fafb; border-radius: 8px;">
                        <div style="font-size: 2.5rem; color: #059669; margin-bottom: 0.5rem;">
                            <i class="fas fa-sync-alt"></i>
                </div>
                        <h3 style="color: #1f2937; margin-bottom: 0.5rem;">Importaciones Realizadas</h3>
                        <div style="font-size: 2rem; font-weight: bold; color: #059669; margin-bottom: 0.5rem;">
                            <?php echo $cycle_data['sync_count'] ?? 0; ?>
                </div>
                        <p style="color: #6b7280; margin: 0; font-size: 0.9rem;">
                            <?php if (($subscriber_data['plan_type'] ?? 'free') === 'free'): ?>
                                de 10 disponibles
                            <?php else: ?>
                                ilimitadas
                            <?php endif; ?>
                        </p>
                </div>

                    <!-- Cuadro 2: Fecha de renovación -->
                    <div style="text-align: center; padding: 1.5rem; background: #f9fafb; border-radius: 8px;">
                        <div style="font-size: 2.5rem; color: #059669; margin-bottom: 0.5rem;">
                            <i class="fas fa-calendar-alt"></i>
                        </div>
                        <h3 style="color: #1f2937; margin-bottom: 0.5rem;">Estado de Suscripción</h3>
                        <div style="font-size: 1.2rem; font-weight: bold; margin-bottom: 0.5rem;">
                        <?php 
                            if (($subscriber_data['plan_type'] ?? 'free') === 'free') {
                                echo '<span style="color: #6b7280;">Plan Gratuito</span>';
                            } else {
                                // Para planes pagos, verificar el estado de la factura
                                if ($billing_cycle_data) {
                                    $invoice_status = $billing_cycle_data['status'];
                                    
                                    if ($invoice_status === 'paid') {
                                        // Factura pagada - verificar si el ciclo está vencido
                                        if ($cycle_data && $cycle_data['cycle_end_date']) {
                                            $today = new DateTime();
                                            $cycle_end = new DateTime($cycle_data['cycle_end_date']);
                                            $grace_end = clone $cycle_end;
                                            $grace_end->add(new DateInterval('P3D')); // +3 días de gracia
                                            
                                            if ($today > $grace_end) {
                                                echo '<span style="color: #dc2626;">Suspendido</span>';
                                            } elseif ($today > $cycle_end) {
                                                echo '<span style="color: #f59e0b;">Período de Gracia</span>';
                                            } else {
                                                $days_left = $today->diff($cycle_end)->days;
                                                if ($days_left <= 3) {
                                                    echo '<span style="color: #f59e0b;">Próximo a Vencer</span>';
                                                } else {
                                                    echo '<span style="color: #059669;">Activo</span>';
                                                }
                                            }
                                        } else {
                                            echo '<span style="color: #059669;">Activo</span>';
                                        }
                                    } elseif ($invoice_status === 'pending') {
                                        // Factura pendiente - verificar si está vencida
                                        $today = new DateTime();
                                        $due_date = new DateTime($billing_cycle_data['due_date']);
                                        
                                        if ($today > $due_date) {
                                            echo '<span style="color: #dc2626;">Vencido</span>';
                                        } else {
                                            echo '<span style="color: #f59e0b;">Pendiente de Pago</span>';
                                        }
                                    } else {
                                        echo '<span style="color: #dc2626;">Inactivo</span>';
                                    }
                                } else {
                                    // Buscar cualquier factura del suscriptor
                                    $any_invoice = $pdo->prepare("
                                        SELECT status, due_date FROM invoices 
                                        WHERE subscriber_id = ? 
                                        ORDER BY created_at DESC 
                                        LIMIT 1
                                    ");
                                    $any_invoice->execute([$subscriber_id]);
                                    $any_invoice_data = $any_invoice->fetch(PDO::FETCH_ASSOC);
                                    
                                    if ($any_invoice_data) {
                                        if ($any_invoice_data['status'] === 'pending') {
                                            $today = new DateTime();
                                            $due_date = new DateTime($any_invoice_data['due_date']);
                                            
                                            if ($today > $due_date) {
                                                echo '<span style="color: #dc2626;">Vencido</span>';
                                            } else {
                                                echo '<span style="color: #f59e0b;">Pendiente de Pago</span>';
                                            }
                                        } else {
                                            echo '<span style="color: #dc2626;">Inactivo</span>';
                                        }
                                    } else {
                                        echo '<span style="color: #dc2626;">Sin Factura</span>';
                                    }
                                }
                            }
                        ?>
                    </div>
                        <p style="color: #6b7280; margin: 0; font-size: 0.9rem;">
                            <?php 
                            if (($subscriber_data['plan_type'] ?? 'free') === 'free') {
                                echo 'Sin renovación requerida';
                            } else {
                                // Usar la misma lógica mejorada para el mensaje descriptivo
                                if ($billing_cycle_data) {
                                    $invoice_status = $billing_cycle_data['status'];
                                    
                                    if ($invoice_status === 'paid') {
                                        // Factura pagada - mostrar información del ciclo
                                        if ($cycle_data && $cycle_data['cycle_end_date']) {
                                            $today = new DateTime();
                                            $cycle_end = new DateTime($cycle_data['cycle_end_date']);
                                            $grace_end = clone $cycle_end;
                                            $grace_end->add(new DateInterval('P3D'));
                                            
                                            if ($today > $grace_end) {
                                                echo 'Suscripción expirada';
                                            } elseif ($today > $cycle_end) {
                                                $grace_days = $today->diff($grace_end)->days;
                                                echo $grace_days . ' días de gracia restantes';
                                            } else {
                                                $days_left = $today->diff($cycle_end)->days;
                                                if ($days_left > 0) {
                                                    echo 'Vence el ' . $cycle_end->format('d/m/Y');
                                                } else {
                                                    echo 'Vence hoy';
                                                }
                                            }
                                        } else {
                                            echo 'Suscripción activa';
                                        }
                                    } elseif ($invoice_status === 'pending') {
                                        // Factura pendiente - mostrar fecha de vencimiento
                                        $today = new DateTime();
                                        $due_date = new DateTime($billing_cycle_data['due_date']);
                                        
                                        if ($today > $due_date) {
                                            echo 'Vence el ' . $due_date->format('d/m/Y') . ' - Debe pagar o enviar comprobante a soporte';
                                        } else {
                                            $days_left = $today->diff($due_date)->days;
                                            echo 'Vence el ' . $due_date->format('d/m/Y') . ' (' . $days_left . ' días)';
                                        }
                                    } else {
                                        echo 'Contacta soporte para reactivar';
                                    }
                                } else {
                                    // Buscar cualquier factura del suscriptor para el mensaje descriptivo
                                    $any_invoice_msg = $pdo->prepare("
                                        SELECT status, due_date FROM invoices 
                                        WHERE subscriber_id = ? 
                                        ORDER BY created_at DESC 
                                        LIMIT 1
                                    ");
                                    $any_invoice_msg->execute([$subscriber_id]);
                                    $any_invoice_msg_data = $any_invoice_msg->fetch(PDO::FETCH_ASSOC);
                                    
                                    if ($any_invoice_msg_data) {
                                        if ($any_invoice_msg_data['status'] === 'pending') {
                                            $today = new DateTime();
                                            $due_date = new DateTime($any_invoice_msg_data['due_date']);
                                            
                                            if ($today > $due_date) {
                                                echo 'Vence el ' . $due_date->format('d/m/Y') . ' - Debe pagar o enviar comprobante a soporte';
                                            } else {
                                                $days_left = $today->diff($due_date)->days;
                                                echo 'Vence el ' . $due_date->format('d/m/Y') . ' (' . $days_left . ' días)';
                                            }
                                        } else {
                                            echo 'Contacta soporte para reactivar';
                                        }
                                    } else {
                                        echo 'Sin factura generada';
                                    }
                                }
                            }
                            ?>
                        </p>
                        <?php if (($subscriber_data['plan_type'] ?? 'free') !== 'enterprise'): ?>
                            <div style="text-align: center; margin-top: 1rem;">
                                <button onclick="openPlansModal()" class="btn-upgrade" style="background: linear-gradient(45deg, #f59e0b, #d97706); color: white; padding: 8px 16px; border-radius: 20px; font-size: 0.9rem; font-weight: 600; text-decoration: none; transition: all 0.3s ease; border: none; cursor: pointer;">Mejorar Plan</button>
                </div>
                        <?php endif; ?>
            </div>

                    <!-- Cuadro 3: Datos de la cuenta -->
                    <div style="text-align: center; padding: 1.5rem; background: #f9fafb; border-radius: 8px;">
                        <div style="font-size: 2.5rem; color: #059669; margin-bottom: 0.5rem;">
                            <i class="fas fa-user-circle"></i>
                    </div>
                        <h3 style="color: #1f2937; margin-bottom: 1rem;">Datos de la Cuenta</h3>
                        <div style="text-align: left; margin-bottom: 0.75rem;">
                            <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                                <span style="color: #6b7280; font-weight: 500;">Nombre:</span>
                                <span style="color: #1f2937; font-weight: bold;">
                                    <?php echo htmlspecialchars($subscriber_data['first_name'] ?? 'N/A'); ?>
                                        </span>
                            </div>
                            <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                                <span style="color: #6b7280; font-weight: 500;">Dominio:</span>
                                <span style="color: #1f2937; font-weight: bold;">
                                    <?php echo htmlspecialchars($subscriber_data['domain'] ?? 'N/A'); ?>
                                        </span>
                                    </div>
                            <div style="display: flex; justify-content: space-between;">
                                <span style="color: #6b7280; font-weight: 500;">Licencia:</span>
                                <span style="color: #1f2937; font-weight: bold; font-family: monospace; font-size: 0.9rem;">
                                    <?php echo htmlspecialchars($license_key ?? 'N/A'); ?>
                                </span>
                                </div>
                        </div>
                    </div>
                </div>
            </div>

        <!-- Alertas de Estado -->
                                        <?php 
        // Verificar estado del ciclo
        $cycle_status = 'active';
        $grace_days_remaining = 0;
        
        if ($cycle_data) {
            $today = new DateTime();
            $cycle_end = new DateTime($cycle_data['cycle_end_date']);
            $grace_end = clone $cycle_end;
            $grace_end->add(new DateInterval('P3D')); // +3 días
            
            if ($today > $grace_end) {
                $cycle_status = 'expired';
            } elseif ($today > $cycle_end) {
                $cycle_status = 'grace_period';
                $grace_days_remaining = $today->diff($grace_end)->days;
            } elseif ($today->diff($cycle_end)->days <= 3) {
                $cycle_status = 'warning';
            }
        }
        ?>
        
        <?php if ($cycle_status === 'warning'): ?>
            <div class="warning">
                ⚠️ <strong>Advertencia:</strong> Tu ciclo de facturación expira en <?php echo $days_remaining; ?> días. 
                Renueva tu suscripción para continuar usando el servicio.
                                </div>
        <?php elseif ($cycle_status === 'grace_period'): ?>
            <div class="warning" style="background: linear-gradient(135deg, #fef3c7, #fde68a); border-left: 4px solid #f59e0b;">
                ⏰ <strong>Período de Gracia:</strong> Tu suscripción expiró pero tienes <?php echo $grace_days_remaining; ?> días de gracia restantes. 
                <a href="checkout.php?plan=<?php echo $subscriber_data['plan_type']; ?>&renewal=true" style="color: #f59e0b; text-decoration: underline; font-weight: bold;">Renueva ahora</a> para evitar la suspensión.
                            </div>
        <?php elseif ($cycle_status === 'expired'): ?>
            <div class="danger">
                🚨 <strong>Suspendido:</strong> Tu período de gracia ha expirado. 
                <a href="checkout.php?plan=<?php echo $subscriber_data['plan_type']; ?>&renewal=true" style="color: #dc2626; text-decoration: underline; font-weight: bold;">Renueva inmediatamente</a> para reactivar el servicio.
                                </div>
        <?php endif; ?>

        <!-- Alerta para cuentas inactivas -->
        <?php if (isset($_SESSION['account_status']) && $_SESSION['account_status'] !== 'active'): ?>
            <div class="danger">
                🚨 <strong>Cuenta Inactiva:</strong> Tu cuenta no está activa (Estado: <?php echo ucfirst($_SESSION['account_status']); ?>). 
                                    <?php 
                $current_plan = $subscriber_data['plan_type'] ?? 'free';
                if ($current_plan === 'free'): 
                        ?>
                    <a href="plans.php" style="color: #dc2626; text-decoration: underline; font-weight: bold;">Haz clic aquí para elegir un plan</a> y activar tu cuenta.
                <?php else: ?>
                    <a href="checkout.php?plan=<?php echo $current_plan; ?>&renewal=true" style="color: #dc2626; text-decoration: underline; font-weight: bold;">Haz clic aquí para Pagar</a> y reactivar tu cuenta. Si ya realizaste el pago envía el comprobante de pago a <a href="mailto:contact@dwoosync.com" style="color: #dc2626; text-decoration: underline; font-weight: bold;">contact@dwoosync.com</a>
                <?php endif; ?>
                                </div>
        <?php endif; ?>

        <!-- Alerta de límite de uso para plan Free -->
        <?php if (($subscriber_data['plan_type'] ?? 'free') === 'free' && $cycle_data && $sync_percentage > 80): ?>
            <div class="warning">
                ⚠️ <strong>Límite de Uso:</strong> Has utilizado el <?php echo round($sync_percentage); ?>% de tus importaciones del ciclo actual (<?php echo $cycle_data['sync_count']; ?>/10). 
                <a href="https://www.dwoosync.com" target="_blank" style="color: #f59e0b; text-decoration: underline; font-weight: bold;">Mejora tu plan</a> para obtener importaciones ilimitadas.
                            </div>
        <?php endif; ?>



        <div class="dashboard-grid">
            <!-- Información del Ciclo Actual -->
            <div class="dashboard-card">
                <h3>📅 Ciclo de Suscripción Actual</h3>
                <?php if ($cycle_data): ?>
                    <div class="cycle-info">
                        <h4>Período Activo</h4>
                        <div class="cycle-dates">
                            <div class="cycle-date">
                                <div class="cycle-date-label">Inicio del Ciclo</div>
                                <div class="cycle-date-value"><?php echo date('d/m/Y', strtotime($cycle_data['cycle_start_date'])); ?></div>
                                </div>
                            <div class="cycle-date">
                                <div class="cycle-date-label">Fin del Ciclo</div>
                                <div class="cycle-date-value"><?php echo date('d/m/Y', strtotime($cycle_data['cycle_end_date'])); ?></div>
                                </div>
                </div>
                        <div class="days-remaining">
                            <?php if ($days_remaining > 0): ?>
                                <?php echo $days_remaining; ?> días restantes
                <?php else: ?>
                                Ciclo expirado
                                <?php endif; ?>
                            </div>
                            
                            <div class="sync-count-simple">
                                Sincronizaciones realizadas: <strong><?php echo number_format($cycle_data['sync_count']); ?></strong>
                            </div>
                        </div>
                <?php else: ?>
                    <div class="no-data">
                        No hay ciclo activo. Contacta soporte.
                    </div>
                            <?php endif; ?>
                        </div>

            <!-- Plan Actual -->
            <div class="dashboard-card">
                <h3>📊 Plan Actual</h3>
                <div class="plan-info">
                    <div class="plan-badge-large <?php echo $subscriber_data['plan_type'] ?? 'free'; ?>">
                                    <?php 
                        $plan_type = $subscriber_data['plan_type'] ?? 'free';
                        echo $plan_type === 'enterprise' ? '+Spotify' : ucfirst($plan_type);
                        ?>
                    </div>
                    
                    <div class="plan-description">
                        <?php 
                        switch($plan_type) {
                            case 'free':
                                echo 'Plan gratuito con funcionalidades básicas e importaciones ilimitadas';
                                break;
                            case 'premium':
                                echo 'Plan premium con soporte prioritario e importaciones ilimitadas';
                                break;
                            case 'enterprise':
                                echo 'Plan +Spotify con integración avanzada e importaciones ilimitadas';
                                break;
                            default:
                                echo 'Plan personalizado';
                        }
                        ?>
                </div>
                            
                    <?php if ($plan_type !== 'enterprise'): ?>
                        <div style="margin-top: 20px;">
                            <button onclick="openPlansModal()" class="btn-upgrade-spotify">
                                <i class="fas fa-arrow-up"></i> Mejorar a Plan +Spotify
                            </button>
                                </div>
                    <?php else: ?>
                        <div style="margin-top: 20px; text-align: center; color: #10b981; font-weight: 600;">
                            <i class="fas fa-crown"></i> ¡Tienes el plan más avanzado!
            </div>
            <?php endif; ?>
                    </div>
                    </div>
                            
            <!-- Información de la Licencia -->
            <div class="dashboard-card">
                <h3>🔑 Información de Licencia</h3>
                <?php if ($license_data): ?>
                <div class="info-item">
                        <span class="info-label">Clave de Licencia:</span>
                        <div class="license-key-container">
                            <span class="license-key-value" id="licenseKey"><?php echo htmlspecialchars($license_data['license_key']); ?></span>
                            <button class="btn-copy" onclick="copyLicenseKey()" id="copyBtn">
                                📋 Copiar
                            </button>
                    </div>
                </div>
                <div class="info-item">
                    <span class="info-label">Estado:</span>
                        <span class="status status-<?php echo $license_data['status']; ?>">
                            <?php echo ucfirst($license_data['status']); ?>
                        </span>
                    </div>
                <div class="info-item">
                        <span class="info-label">Versión del Plugin:</span>
                        <span class="info-value"><?php echo $license_data['plugin_version']; ?></span>
                                </div>
                <div class="info-item">
                        <span class="info-label">Último Uso:</span>
                        <span class="info-value">
                            <?php echo $license_data['last_used'] ? date('d/m/Y H:i', strtotime($license_data['last_used'])) : 'Nunca'; ?>
                        </span>
                    </div>
                <div class="info-item">
                        <span class="info-label">Límite de Uso:</span>
                        <span class="info-value"><?php echo number_format($license_data['usage_limit']); ?> por ciclo</span>
                    </div>
                <?php else: ?>
                    <div class="no-data">
                        No se encontró información de licencia.
                </div>
                <?php endif; ?>
            </div>




        <div class="actions">
            <button class="btn" onclick="refreshData()">🔄 Actualizar Datos</button>
            <a href="billing.php" class="btn btn-success">💳 Gestionar Suscripción</a>
            <a href="profile.php" class="btn btn-secondary">⚙️ Configuración</a>
            <a href="logout.php" class="btn btn-danger">🚪 Cerrar Sesión</a>
        </div>
    </div>

    <div class="footer">
        <p>&copy; 2024 dwoosync. Todos los derechos reservados.</p>
    </div>

    <script>

        function refreshData() {
            location.reload();
        }

        // Función para copiar la clave de licencia
        function copyLicenseKey() {
            const licenseKey = document.getElementById('licenseKey').textContent;
            const copyBtn = document.getElementById('copyBtn');
            
            // Intentar usar la API moderna del portapapeles
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(licenseKey).then(function() {
                    showCopySuccess(copyBtn);
                }).catch(function(err) {
                    console.error('Error al copiar: ', err);
                    fallbackCopyTextToClipboard(licenseKey, copyBtn);
                });
            } else {
                // Fallback para navegadores más antiguos
                fallbackCopyTextToClipboard(licenseKey, copyBtn);
            }
        }

        // Función de respaldo para copiar texto
        function fallbackCopyTextToClipboard(text, button) {
            const textArea = document.createElement("textarea");
            textArea.value = text;
            textArea.style.top = "0";
            textArea.style.left = "0";
            textArea.style.position = "fixed";
            textArea.style.opacity = "0";
            
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();
            
            try {
                const successful = document.execCommand('copy');
                if (successful) {
                    showCopySuccess(button);
                } else {
                    showCopyError(button);
                }
            } catch (err) {
                console.error('Fallback: Error al copiar', err);
                showCopyError(button);
            }
            
            document.body.removeChild(textArea);
        }

        // Mostrar éxito al copiar
        function showCopySuccess(button) {
            const originalText = button.innerHTML;
            button.innerHTML = '✅ Copiado';
            button.classList.add('copied');
            
            setTimeout(function() {
                button.innerHTML = originalText;
                button.classList.remove('copied');
            }, 2000);
        }

        // Mostrar error al copiar
        function showCopyError(button) {
            const originalText = button.innerHTML;
            button.innerHTML = '❌ Error';
            button.style.background = 'linear-gradient(45deg, #dc2626, #b91c1c)';
            
            setTimeout(function() {
                button.innerHTML = originalText;
                button.style.background = '';
            }, 2000);
        }

        // Auto-refresh cada 5 minutos
        setInterval(refreshData, 300000);

        // Funciones del modal de planes
        function openPlansModal() {
            // Filtrar planes según el plan actual
            const currentPlan = '<?php echo $subscriber_data['plan_type'] ?? 'free'; ?>';
            const planCards = document.querySelectorAll('.plan-card');
            
            planCards.forEach(card => {
                const planType = card.getAttribute('data-plan') || card.onclick.toString().match(/selectPlan\('(\w+)'\)/)?.[1];
                
                if (currentPlan === 'free') {
                    // Mostrar solo premium y enterprise
                    card.style.display = (planType === 'premium' || planType === 'enterprise') ? 'block' : 'none';
                } else if (currentPlan === 'premium') {
                    // Mostrar solo enterprise
                    card.style.display = (planType === 'enterprise') ? 'block' : 'none';
                } else {
                    // Ocultar todos si ya es enterprise
                    card.style.display = 'none';
                }
            });
            
            document.getElementById('plansModal').style.display = 'block';
            document.body.style.overflow = 'hidden';
        }

        function closePlansModal() {
            document.getElementById('plansModal').style.display = 'none';
            document.body.style.overflow = 'auto';
        }

        function selectPlan(planId) {
            // Cerrar el modal
            closePlansModal();
            
            // Redirigir al checkout con el plan seleccionado
            window.location.href = `checkout.php?plan=${planId}&renewal=true`;
        }

        // Cerrar modal al hacer clic fuera de él
        window.onclick = function(event) {
            const modal = document.getElementById('plansModal');
            if (event.target === modal) {
                closePlansModal();
            }
        }

        // Cerrar modal con tecla Escape
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                closePlansModal();
            }
        });
    </script>

    <!-- Modal de Planes -->
    <div id="plansModal" class="modal" style="display: none;">
        <div class="modal-content">
            <div class="modal-header">
                <h2><i class="fas fa-crown"></i> Selecciona tu Plan</h2>
                <button class="modal-close" onclick="closePlansModal()">&times;</button>
            </div>
            <div class="modal-body">
                <div class="plans-grid">
                    <!-- Plan Free -->
                    <div class="plan-card" data-plan="free" onclick="selectPlan('free')">
                        <div class="plan-header">
                            <h3>Free</h3>
                            <div class="plan-price">€0<span>/mes</span></div>
                        </div>
                        <div class="plan-features">
                            <ul>
                                <li><i class="fas fa-check"></i> Importaciones ilimitadas</li>
                                <li><i class="fas fa-check"></i> Llamadas API ilimitadas</li>
                                <li><i class="fas fa-check"></i> Soporte por email</li>
                                <li><i class="fas fa-check"></i> Actualizaciones básicas</li>
                            </ul>
                        </div>
                        <div class="plan-button">
                            <span class="current-plan">Plan Actual</span>
                        </div>
                    </div>

                    <!-- Plan Premium -->
                    <div class="plan-card premium" data-plan="premium" onclick="selectPlan('premium')">
                        <div class="plan-badge">Más Popular</div>
                        <div class="plan-header">
                            <h3>Premium</h3>
                            <div class="plan-price">€22<span>/mes</span></div>
                        </div>
                        <div class="plan-features">
                            <ul>
                                <li><i class="fas fa-check"></i> Importaciones ilimitadas</li>
                                <li><i class="fas fa-check"></i> Llamadas API ilimitadas</li>
                                <li><i class="fas fa-check"></i> Soporte prioritario</li>
                                <li><i class="fas fa-check"></i> Todas las actualizaciones</li>
                                <li><i class="fas fa-check"></i> Estadísticas avanzadas</li>
                                <li><i class="fas fa-times" style="color: #dc2626;"></i> Widget Spotify</li>
                            </ul>
                        </div>
                        <div class="plan-button">
                            <button class="btn-select">Seleccionar</button>
                        </div>
                    </div>

                    <!-- Plan +Spotify -->
                    <div class="plan-card enterprise" data-plan="enterprise" onclick="selectPlan('enterprise')">
                        <div class="plan-header">
                            <h3>+Spotify</h3>
                            <div class="plan-price">€29<span>/mes</span></div>
                        </div>
                        <div class="plan-features">
                            <ul>
                                <li><i class="fas fa-check"></i> Importaciones ilimitadas</li>
                                <li><i class="fas fa-check"></i> Llamadas API ilimitadas</li>
                                <li><i class="fas fa-check"></i> Integración con Spotify</li>
                                <li><i class="fas fa-check"></i> Soporte prioritario</li>
                                <li><i class="fas fa-check"></i> Todas las actualizaciones</li>
                                <li><i class="fas fa-check"></i> Estadísticas avanzadas</li>
                            </ul>
                        </div>
                        <div class="plan-button">
                            <button class="btn-select">Seleccionar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <style>
        /* Estilos del Modal */
        .modal {
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            backdrop-filter: blur(5px);
        }

        .modal-content {
            background: white;
            margin: 5% auto;
            padding: 0;
            border-radius: 20px;
            width: 90%;
            max-width: 1000px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 25px 50px rgba(0,0,0,0.3);
            animation: modalSlideIn 0.3s ease-out;
        }

        @keyframes modalSlideIn {
            from {
                opacity: 0;
                transform: translateY(-50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .modal-header {
            background: linear-gradient(45deg, #10b981, #059669);
            color: white;
            padding: 25px 30px;
            border-radius: 20px 20px 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-header h2 {
            margin: 0;
            font-size: 1.8rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .modal-close {
            background: none;
            border: none;
            color: white;
            font-size: 2rem;
            cursor: pointer;
            padding: 0;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s ease;
        }

        .modal-close:hover {
            background: rgba(255,255,255,0.2);
        }

        .modal-body {
            padding: 30px;
        }

        .plans-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 25px;
        }

        .plan-card {
            background: #f8f9fa;
            border: 2px solid #e5e7eb;
            border-radius: 15px;
            padding: 25px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
        }

        .plan-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.1);
        }

        .plan-card.premium {
            border-color: #f59e0b;
            background: linear-gradient(135deg, #fef3c7, #fde68a);
        }

        .plan-card.enterprise {
            border-color: #8b5cf6;
            background: linear-gradient(135deg, #f3e8ff, #e9d5ff);
        }

        .plan-badge {
            position: absolute;
            top: -10px;
            left: 50%;
            transform: translateX(-50%);
            background: linear-gradient(45deg, #f59e0b, #d97706);
            color: white;
            padding: 8px 20px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .plan-header h3 {
            font-size: 1.5rem;
            font-weight: bold;
            color: #1f2937;
            margin-bottom: 10px;
        }

        .plan-price {
            font-size: 2.5rem;
            font-weight: bold;
            color: #059669;
            margin-bottom: 20px;
        }

        .plan-price span {
            font-size: 1rem;
            color: #6b7280;
            font-weight: normal;
        }

        .plan-features ul {
            list-style: none;
            padding: 0;
            margin: 0 0 25px 0;
        }

        .plan-features li {
            padding: 8px 0;
            color: #4b5563;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .plan-features i {
            color: #10b981;
            font-size: 0.9rem;
        }

        .plan-button {
            margin-top: auto;
        }

        .btn-select {
            background: linear-gradient(45deg, #10b981, #059669);
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 25px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            width: 100%;
        }

        .btn-select:hover {
            background: linear-gradient(45deg, #5a67d8, #6b46c1);
            transform: translateY(-2px);
        }

        .current-plan {
            background: #6b7280;
            color: white;
            padding: 12px 30px;
            border-radius: 25px;
            font-weight: 600;
            display: inline-block;
            width: 100%;
        }

        @media (max-width: 768px) {
            .modal-content {
                margin: 2% auto;
                width: 95%;
            }
            
            .plans-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
    
    <script>
        
        function simulatePayment() {
            if (confirm('¿Simular pago y activar la cuenta? Esto activará tu suscripción inmediatamente.')) {
                // Simular pago exitoso
                fetch('simulate-payment.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'action=simulate_payment'
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('¡Pago simulado exitosamente! Tu cuenta ha sido activada.');
                        location.reload();
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    alert('Error al simular el pago: ' + error);
                });
            }
        }
    </script>
</body>
</html>