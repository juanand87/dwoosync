<?php
/**
 * Página de capturas de pantalla
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Screenshots - DiscogsSync</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-logo">
                    <a href="../index.php" style="text-decoration: none; color: inherit;">
                        <h2><i class="fas fa-music"></i> DiscogsSync</h2>
                    </a>
                </div>
                <div class="nav-menu">
                    <a href="../index.php" class="nav-link">Inicio</a>
                    <a href="../index.php#plans" class="nav-link">Planes</a>
                    <a href="../index.php#features" class="nav-link">Características</a>
                    <a href="screenshots.php" class="nav-link active">Screenshots</a>
                    <a href="contact.php" class="nav-link">Contacto</a>
                    <a href="login.php" class="nav-link btn-login">Iniciar Sesión</a>
                </div>
            </div>
        </nav>
    </header>

    <!-- Main Content -->
    <main style="padding-top: 100px; min-height: 100vh; background: #f8fafc;">
        <div class="container">
            
            <!-- Header Section -->
            <div style="text-align: center; margin-bottom: 4rem;">
                <h1 style="color: #1f2937; margin-bottom: 1rem; font-size: 3rem;">Capturas de Pantalla</h1>
                <p style="color: #6b7280; font-size: 1.25rem; max-width: 600px; margin: 0 auto;">
                    Descubre cómo se ve DiscogsSync en acción. Explora la interfaz del plugin y todas sus funcionalidades.
                </p>
            </div>

            <!-- Screenshots Grid -->
            <div class="screenshots-grid">
                <div class="screenshot-item">
                    <div class="screenshot-placeholder">
                        <i class="fas fa-image" style="font-size: 4rem; color: #d1d5db; margin-bottom: 1.5rem;"></i>
                        <h3>Panel de Control Principal</h3>
                        <p>Gestiona todas tus importaciones desde un dashboard intuitivo y fácil de usar.</p>
                        <div style="background: #f3f4f6; padding: 1rem; border-radius: 8px; margin-top: 1rem;">
                            <small style="color: #6b7280;">Próximamente: Vista completa del dashboard</small>
                        </div>
                    </div>
                </div>

                <div class="screenshot-item">
                    <div class="screenshot-placeholder">
                        <i class="fas fa-image" style="font-size: 4rem; color: #d1d5db; margin-bottom: 1.5rem;"></i>
                        <h3>Configuración de API</h3>
                        <p>Configura fácilmente tu API de Discogs con solo unos clics. Interfaz simple y clara.</p>
                        <div style="background: #f3f4f6; padding: 1rem; border-radius: 8px; margin-top: 1rem;">
                            <small style="color: #6b7280;">Próximamente: Pantalla de configuración</small>
                        </div>
                    </div>
                </div>

                <div class="screenshot-item">
                    <div class="screenshot-placeholder">
                        <i class="fas fa-image" style="font-size: 4rem; color: #d1d5db; margin-bottom: 1.5rem;"></i>
                        <h3>Productos Sincronizados</h3>
                        <p>Vista de todos los productos importados desde Discogs en tu tienda WooCommerce.</p>
                        <div style="background: #f3f4f6; padding: 1rem; border-radius: 8px; margin-top: 1rem;">
                            <small style="color: #6b7280;">Próximamente: Lista de productos</small>
                        </div>
                    </div>
                </div>

                <div class="screenshot-item">
                    <div class="screenshot-placeholder">
                        <i class="fas fa-image" style="font-size: 4rem; color: #d1d5db; margin-bottom: 1.5rem;"></i>
                        <h3>Widget Spotify</h3>
                        <p>Reproduce música directamente en tu tienda con el widget integrado de Spotify.</p>
                        <div style="background: #f3f4f6; padding: 1rem; border-radius: 8px; margin-top: 1rem;">
                            <small style="color: #6b7280;">Próximamente: Widget en acción</small>
                        </div>
                    </div>
                </div>

                <div class="screenshot-item">
                    <div class="screenshot-placeholder">
                        <i class="fas fa-image" style="font-size: 4rem; color: #d1d5db; margin-bottom: 1.5rem;"></i>
                        <h3>Estadísticas Detalladas</h3>
                        <p>Monitorea el rendimiento de tus importaciones con gráficos y métricas en tiempo real.</p>
                        <div style="background: #f3f4f6; padding: 1rem; border-radius: 8px; margin-top: 1rem;">
                            <small style="color: #6b7280;">Próximamente: Dashboard de estadísticas</small>
                        </div>
                    </div>
                </div>

                <div class="screenshot-item">
                    <div class="screenshot-placeholder">
                        <i class="fas fa-image" style="font-size: 4rem; color: #d1d5db; margin-bottom: 1.5rem;"></i>
                        <h3>Configuración de Licencias</h3>
                        <p>Gestiona tus licencias y dominios desde una interfaz centralizada y segura.</p>
                        <div style="background: #f3f4f6; padding: 1rem; border-radius: 8px; margin-top: 1rem;">
                            <small style="color: #6b7280;">Próximamente: Panel de licencias</small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Call to Action -->
            <div style="text-align: center; margin-top: 4rem; padding: 3rem; background: linear-gradient(135deg, #10b981 0%, #059669 100%); border-radius: 16px; color: white;">
                <h2 style="margin-bottom: 1rem; color: white;">¿Listo para probar DiscogsSync?</h2>
                <p style="margin-bottom: 2rem; opacity: 0.9; font-size: 1.125rem;">
                    Comienza a sincronizar tus productos de Discogs con WooCommerce hoy mismo.
                </p>
                <div style="display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap;">
                    <a href="../index.php#plans" class="btn btn-white btn-large">
                        <i class="fas fa-rocket"></i> Ver Planes
                    </a>
                    <a href="login.php" class="btn btn-outline-white btn-large">
                        <i class="fas fa-sign-in-alt"></i> Iniciar Sesión
                    </a>
                </div>
            </div>

            <!-- Back to Home -->
            <div style="text-align: center; margin-top: 2rem;">
                <a href="../index.php" style="color: #059669; text-decoration: none; font-weight: 500;">
                    <i class="fas fa-arrow-left"></i> Volver al Inicio
                </a>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>DiscogsSync</h3>
                    <p>El mejor plugin para integrar Discogs con WooCommerce - WordPress</p>
                </div>
                <div class="footer-section">
                    <h4>Enlaces</h4>
                    <ul>
                        <li><a href="../index.php#plans">Planes</a></li>
                        <li><a href="../index.php#features">Características</a></li>
                        <li><a href="screenshots.php">Screenshots</a></li>
                        <li><a href="login.php">Iniciar Sesión</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Soporte</h4>
                    <ul>
                        <li><a href="mailto:support@discogsync.com">support@discogsync.com</a></li>
                        <li><a href="#">Documentación</a></li>
                        <li><a href="contact.php">Contacto</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2024 DiscogsSync. Todos los derechos reservados.</p>
            </div>
        </div>
    </footer>

    <script src="../assets/js/script.js"></script>
</body>
</html>

