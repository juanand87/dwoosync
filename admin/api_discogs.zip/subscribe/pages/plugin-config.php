<?php
/**
 * Página de configuración del plugin DiscogsSync
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

// Iniciar sesión
startSecureSession();

// Verificar que el usuario esté logueado
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

// Obtener datos del usuario
$userId = $_SESSION['user_id'];
$userEmail = $_SESSION['user_email'];
$userName = $_SESSION['user_name'];
$userDomain = $_SESSION['user_domain'];
$userPlan = $_SESSION['user_plan'];
$licenseKey = $_SESSION['license_key'];

// Obtener información de la licencia
try {
    $db = Database::getInstance();
    $license = $db->fetch('SELECT * FROM licenses WHERE subscriber_id = ? AND status = "active"', [$userId]);
    
    if (!$license) {
        throw new Exception('No se encontró una licencia activa');
    }
    
    $subscriber = $db->fetch('SELECT * FROM subscribers WHERE id = ?', [$userId]);
    
} catch (Exception $e) {
    $error = 'Error al cargar la información: ' . $e->getMessage();
}

// Obtener planes para mostrar características
$plans = getSubscriptionPlans();
$currentPlan = null;
foreach ($plans as $plan) {
    if ($plan['id'] === $userPlan) {
        $currentPlan = $plan;
        break;
    }
}

$success = '';
$error = '';

// Procesar descarga del plugin
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_plugin'])) {
    try {
        // Crear archivo ZIP del plugin
        $pluginDir = 'C:\xampp\htdocs\wordpress\wp-content\plugins\Discogs-Importer/';
        $zipFile = __DIR__ . '/../../temp/discogs-sync-plugin-' . $licenseKey . '.zip';
        
        // Debug logs
        error_log('[Plugin Download Debug] Plugin directory: ' . $pluginDir);
        error_log('[Plugin Download Debug] Directory exists: ' . (is_dir($pluginDir) ? 'YES' : 'NO'));
        error_log('[Plugin Download Debug] Zip file: ' . $zipFile);
        
        // Crear directorio temp si no existe
        if (!is_dir(__DIR__ . '/../../temp/')) {
            mkdir(__DIR__ . '/../../temp/', 0755, true);
        }
        
        // Verificar si ZipArchive está disponible
        if (!class_exists('ZipArchive')) {
            throw new Exception('La extensión ZipArchive no está disponible en este servidor. Contacta al administrador para habilitarla.');
        }
        
        // Crear ZIP usando PHP
        $zip = new ZipArchive();
        $zipResult = $zip->open($zipFile, ZipArchive::CREATE);
        error_log('[Plugin Download Debug] Zip open result: ' . $zipResult);
        
        if ($zipResult === TRUE) {
            error_log('[Plugin Download Debug] Starting to add files to ZIP');
            // Agregar archivos del plugin de forma recursiva
            $iterator = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($pluginDir, RecursiveDirectoryIterator::SKIP_DOTS),
                RecursiveIteratorIterator::SELF_FIRST
            );
            
            $fileCount = 0;
            foreach ($iterator as $file) {
                $filePath = $file->getPathname();
                
                // Normalizar las rutas para evitar problemas con separadores de directorio
                $normalizedPluginDir = rtrim(str_replace('\\', '/', $pluginDir), '/') . '/';
                $normalizedFilePath = str_replace('\\', '/', $filePath);
                
                // Obtener la ruta relativa dentro del plugin
                $relativePath = str_replace($normalizedPluginDir, '', $normalizedFilePath);
                
                // Solo agregar el prefijo 'discogs-sync/' sin incluir la ruta completa
                $zipPath = 'discogs-sync/' . $relativePath;
                
                if ($file->isDir()) {
                    $zip->addEmptyDir($zipPath);
                    error_log('[Plugin Download Debug] Added directory: ' . $zipPath);
                } else {
                    $zip->addFile($filePath, $zipPath);
                    error_log('[Plugin Download Debug] Added file: ' . $zipPath);
                    $fileCount++;
                }
            }
            error_log('[Plugin Download Debug] Total files added: ' . $fileCount);
            
            $zip->close();
            error_log('[Plugin Download Debug] ZIP closed successfully');
            
            // Verificar que el archivo ZIP se creó
            if (!file_exists($zipFile)) {
                throw new Exception('El archivo ZIP no se creó correctamente');
            }
            
            $fileSize = filesize($zipFile);
            error_log('[Plugin Download Debug] ZIP file size: ' . $fileSize . ' bytes');
            
            // Descargar el archivo
            header('Content-Type: application/zip');
            header('Content-Disposition: attachment; filename="discogs-sync-plugin.zip"');
            header('Content-Length: ' . $fileSize);
            readfile($zipFile);
            unlink($zipFile); // Eliminar archivo temporal
            error_log('[Plugin Download Debug] File downloaded and deleted successfully');
            exit;
            
        } else {
            throw new Exception('No se pudo crear el archivo ZIP');
        }
        
    } catch (Exception $e) {
        $error = 'Error al generar el plugin: ' . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurar Plugin - DiscogsSync</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/pages.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .config-container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 2rem;
        }
        .config-card {
            background: white;
            border-radius: 16px;
            padding: 2rem;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            margin-bottom: 2rem;
        }
        .license-info {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 2rem;
            border-radius: 12px;
            margin-bottom: 2rem;
        }
        .config-section {
            background: #f8fafc;
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }
        .code-block {
            background: #1f2937;
            color: #f9fafb;
            padding: 1rem;
            border-radius: 8px;
            font-family: 'Courier New', monospace;
            font-size: 0.9rem;
            overflow-x: auto;
            margin: 1rem 0;
        }
        .step {
            display: flex;
            align-items: flex-start;
            margin-bottom: 1.5rem;
            padding: 1rem;
            background: white;
            border-radius: 8px;
            border-left: 4px solid #059669;
        }
        .step-number {
            background: #059669;
            color: white;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            margin-right: 1rem;
            flex-shrink: 0;
        }
        .btn-download {
            background: linear-gradient(135deg, #059669 0%, #047857 100%);
            color: white;
            padding: 1rem 2rem;
            border: none;
            border-radius: 8px;
            font-size: 1.1rem;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }
        .btn-download:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(5, 150, 105, 0.3);
        }
        .feature-list {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 1rem;
            margin: 1rem 0;
        }
        .feature-item {
            display: flex;
            align-items: center;
            padding: 0.75rem;
            background: white;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
        }
        .feature-item i {
            color: #059669;
            margin-right: 0.75rem;
            font-size: 1.2rem;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-logo">
                    <a href="../index.php" style="text-decoration: none; color: inherit;">
                        <h2><i class="fas fa-music"></i> DiscogsSync</h2>
                    </a>
                </div>
                <div class="nav-menu">
                    <a href="dashboard.php" class="nav-link">🏠 Inicio</a>
                    <a href="profile.php" class="nav-link">👤 Perfil</a>
                    <a href="billing.php" class="nav-link">💳 Facturación</a>
                    <a href="plugin-config.php" class="nav-link btn-primary">⚙️ Configurar Plugin</a>
                    <a href="logout.php" class="nav-link btn-logout">🚪 Cerrar Sesión</a>
                </div>
            </div>
        </nav>
    </header>

    <!-- Main Content -->
    <main style="padding-top: 100px; min-height: 100vh; background: #f8fafc;">
        <div class="config-container">
            
            <?php if (!empty($error)): ?>
                <div class="alert alert-error" style="background: #fef2f2; border: 1px solid #fecaca; color: #dc2626; padding: 1rem; border-radius: 8px; margin-bottom: 2rem;">
                    <i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?>
        </div>
            <?php endif; ?>

            <?php if (!empty($success)): ?>
                <div class="alert alert-success" style="background: #f0fdf4; border: 1px solid #bbf7d0; color: #166534; padding: 1rem; border-radius: 8px; margin-bottom: 2rem;">
                    <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?>
    </div>
            <?php endif; ?>

            <!-- Información de la Licencia -->
            <div class="license-info">
                <h2 style="margin-bottom: 1rem;">
                    <i class="fas fa-key"></i> Tu Licencia de DiscogsSync
                </h2>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
                    <div>
                        <strong>Clave de Licencia:</strong><br>
                        <code style="background: rgba(255,255,255,0.2); padding: 0.5rem; border-radius: 4px; font-size: 1.1rem;">
                            <?php echo htmlspecialchars($licenseKey); ?>
                        </code>
                    </div>
                    <div>
                        <strong>Plan:</strong><br>
                        <span style="font-size: 1.2rem; font-weight: bold;">
                            <?php echo htmlspecialchars($currentPlan['name'] ?? 'N/A'); ?>
                        </span>
                    </div>
                    <div>
                        <strong>Dominio:</strong><br>
                        <span style="font-size: 1.1rem;">
                            <?php echo htmlspecialchars($userDomain); ?>
                        </span>
                    </div>
                    <div>
                        <strong>Estado:</strong><br>
                        <span style="color: #10b981; font-weight: bold;">
                            <i class="fas fa-check-circle"></i> Activa
                        </span>
            </div>
        </div>
    </div>

            <!-- Descargar Plugin -->
            <div class="config-card">
                <h2 style="margin-bottom: 1.5rem; color: #1f2937;">
                    <i class="fas fa-download"></i> Descargar Plugin
                </h2>
                
                <div class="config-section">
                    <h3 style="margin-bottom: 1rem; color: #374151;">
                        <i class="fas fa-box"></i> Plugin Personalizado
                    </h3>
                    <p style="color: #6b7280; margin-bottom: 1.5rem;">
                        Descarga el plugin de DiscogsSync personalizado para tu sitio. El plugin incluye tu clave de licencia y está configurado para tu dominio.
                    </p>
                    
                    <form method="POST" style="text-align: center;">
                        <button type="submit" name="download_plugin" class="btn-download">
                            <i class="fas fa-download"></i> Descargar Plugin Personalizado
                        </button>
                    </form>
                </div>
        </div>

            <!-- Instrucciones de Instalación -->
            <div class="config-card">
                <h2 style="margin-bottom: 1.5rem; color: #1f2937;">
                    <i class="fas fa-cog"></i> Instrucciones de Instalación
                </h2>
                
                <div class="step">
                <div class="step-number">1</div>
                    <div>
                        <h4 style="margin: 0 0 0.5rem 0; color: #374151;">Subir el Plugin</h4>
                        <p style="margin: 0; color: #6b7280;">
                            Sube el archivo ZIP descargado a tu sitio WordPress a través del panel de administración: 
                            <strong>Plugins → Añadir nuevo → Subir plugin</strong>
                        </p>
                    </div>
            </div>

                <div class="step">
                <div class="step-number">2</div>
                    <div>
                        <h4 style="margin: 0 0 0.5rem 0; color: #374151;">Activar el Plugin</h4>
                        <p style="margin: 0; color: #6b7280;">
                            Una vez subido, ve a <strong>Plugins → Plugins instalados</strong> y activa "DiscogsSync".
                        </p>
                    </div>
            </div>

                <div class="step">
                <div class="step-number">3</div>
                    <div>
                        <h4 style="margin: 0 0 0.5rem 0; color: #374151;">Configurar la Licencia</h4>
                        <p style="margin: 0; color: #6b7280;">
                            Ve a <strong>DiscogsSync → Configuración</strong> en tu panel de WordPress y pega tu clave de licencia:
                        </p>
                        <div class="code-block">
                            <?php echo htmlspecialchars($licenseKey); ?>
                    </div>
                </div>
            </div>

                <div class="step">
                <div class="step-number">4</div>
                    <div>
                        <h4 style="margin: 0 0 0.5rem 0; color: #374151;">Crear App en Discogs</h4>
                        <p style="margin: 0 0 1rem 0; color: #6b7280;">
                            Necesitas crear una aplicación en Discogs para obtener las credenciales de la API:
                        </p>
                        <ol style="margin: 0; padding-left: 1.5rem; color: #6b7280;">
                            <li style="margin-bottom: 0.5rem;">
                                Ve a <a href="https://www.discogs.com/developers" target="_blank" style="color: #059669; text-decoration: underline;">Discogs Developers</a>
                            </li>
                            <li style="margin-bottom: 0.5rem;">
                                Haz clic en "Create a new application"
                            </li>
                            <li style="margin-bottom: 0.5rem;">
                                Completa el formulario con la información de tu tienda
                            </li>
                            <li style="margin-bottom: 0.5rem;">
                                Copia la <strong>Clave del cliente</strong> y <strong>Información secreta del cliente</strong>
                            </li>
                        </ol>
                    </div>
                </div>

                <div class="step">
                    <div class="step-number">5</div>
                    <div>
                        <h4 style="margin: 0 0 0.5rem 0; color: #374151;">Configurar Credenciales</h4>
                        <p style="margin: 0 0 1rem 0; color: #6b7280;">
                            En la configuración del plugin, pega las credenciales de Discogs:
                        </p>
                        <div class="code-block">
                            <div style="margin-bottom: 0.5rem; color: #9ca3af;">Clave del cliente:</div>
                            <div style="color: #f9fafb;">[Tu clave del cliente de Discogs]</div>
                            <br>
                            <div style="margin-bottom: 0.5rem; color: #9ca3af;">Información secreta del cliente:</div>
                            <div style="color: #f9fafb;">[Tu información secreta del cliente de Discogs]</div>
                        </div>
                    </div>
                </div>

                <div class="step">
                    <div class="step-number">6</div>
                    <div>
                        <h4 style="margin: 0 0 0.5rem 0; color: #374151;">¡Listo para Usar!</h4>
                        <p style="margin: 0; color: #6b7280;">
                            El plugin estará listo para sincronizar productos desde Discogs a tu tienda WooCommerce.
                        </p>
                    </div>
            </div>
        </div>

            <!-- Configuración de Discogs API -->
            <div class="config-card">
                <h2 style="margin-bottom: 1.5rem; color: #1f2937;">
                    <i class="fas fa-key"></i> Configuración de Discogs API
                </h2>
                
                <div class="config-section">
                    <h3 style="margin-bottom: 1rem; color: #374151;">
                        <i class="fas fa-info-circle"></i> ¿Por qué necesito credenciales de Discogs?
                    </h3>
                    <p style="color: #6b7280; margin-bottom: 1.5rem;">
                        Discogs requiere que registres una aplicación para acceder a su API. Esto es necesario para:
                    </p>
                    <ul style="color: #6b7280; margin-bottom: 1.5rem; padding-left: 1.5rem;">
                        <li style="margin-bottom: 0.5rem;">Buscar y obtener información de productos</li>
                        <li style="margin-bottom: 0.5rem;">Acceder a imágenes y metadatos</li>
                        <li style="margin-bottom: 0.5rem;">Respetar los límites de velocidad de la API</li>
                        <li style="margin-bottom: 0.5rem;">Identificar tu aplicación en las solicitudes</li>
                    </ul>
                </div>

                <div class="config-section">
                    <h3 style="margin-bottom: 1rem; color: #374151;">
                        <i class="fas fa-external-link-alt"></i> Enlaces Útiles
                    </h3>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1rem;">
                        <a href="https://www.discogs.com/developers" target="_blank" 
                           style="display: block; padding: 1rem; background: #f8fafc; border: 1px solid #e5e7eb; border-radius: 8px; text-decoration: none; color: #374151; transition: all 0.3s ease;"
                           onmouseover="this.style.borderColor='#059669'; this.style.background='#f0fdf4';"
                           onmouseout="this.style.borderColor='#e5e7eb'; this.style.background='#f8fafc';">
                            <i class="fas fa-code" style="color: #059669; margin-right: 0.5rem;"></i>
                            <strong>Discogs Developers</strong><br>
                            <small style="color: #6b7280;">Crear tu aplicación</small>
                        </a>
                        
                        <a href="https://www.discogs.com/developers/#page:authentication" target="_blank" 
                           style="display: block; padding: 1rem; background: #f8fafc; border: 1px solid #e5e7eb; border-radius: 8px; text-decoration: none; color: #374151; transition: all 0.3s ease;"
                           onmouseover="this.style.borderColor='#059669'; this.style.background='#f0fdf4';"
                           onmouseout="this.style.borderColor='#e5e7eb'; this.style.background='#f8fafc';">
                            <i class="fas fa-shield-alt" style="color: #059669; margin-right: 0.5rem;"></i>
                            <strong>Documentación de API</strong><br>
                            <small style="color: #6b7280;">Guía de autenticación</small>
                        </a>
                        
                        <a href="https://www.discogs.com/developers/#page:rate-limiting" target="_blank" 
                           style="display: block; padding: 1rem; background: #f8fafc; border: 1px solid #e5e7eb; border-radius: 8px; text-decoration: none; color: #374151; transition: all 0.3s ease;"
                           onmouseover="this.style.borderColor='#059669'; this.style.background='#f0fdf4';"
                           onmouseout="this.style.borderColor='#e5e7eb'; this.style.background='#f8fafc';">
                            <i class="fas fa-tachometer-alt" style="color: #059669; margin-right: 0.5rem;"></i>
                            <strong>Límites de Velocidad</strong><br>
                            <small style="color: #6b7280;">Información sobre límites</small>
            </a>
        </div>
    </div>

                <div class="config-section">
                    <h3 style="margin-bottom: 1rem; color: #374151;">
                        <i class="fas fa-lightbulb"></i> Consejos para la Configuración
                    </h3>
                    <div style="background: #fef3c7; border: 1px solid #f59e0b; border-radius: 8px; padding: 1rem; margin-bottom: 1rem;">
                        <div style="display: flex; align-items: flex-start;">
                            <i class="fas fa-exclamation-triangle" style="color: #f59e0b; margin-right: 0.75rem; margin-top: 0.25rem;"></i>
                            <div>
                                <strong style="color: #92400e;">Importante:</strong>
                                <p style="margin: 0.5rem 0 0 0; color: #92400e;">
                                    Guarda tus credenciales de Discogs en un lugar seguro. No las compartas públicamente.
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <ul style="color: #6b7280; margin: 0; padding-left: 1.5rem;">
                        <li style="margin-bottom: 0.5rem;">Usa un nombre descriptivo para tu aplicación (ej: "Mi Tienda - DiscogsSync")</li>
                        <li style="margin-bottom: 0.5rem;">La URL de la aplicación puede ser la URL de tu tienda</li>
                        <li style="margin-bottom: 0.5rem;">La descripción debe explicar que usas la API para sincronizar productos</li>
                        <li style="margin-bottom: 0.5rem;">Una vez creada, no podrás ver la información secreta del cliente nuevamente</li>
                    </ul>
        </div>
    </div>

            <!-- Características de tu Plan -->
            <?php if ($currentPlan): ?>
            <div class="config-card">
                <h2 style="margin-bottom: 1.5rem; color: #1f2937;">
                    <i class="fas fa-star"></i> Características de tu Plan
                </h2>
                
                <div class="feature-list">
                    <?php foreach ($currentPlan['features'] as $feature): ?>
                        <div class="feature-item">
                            <?php if ($userPlan === 'free' && ($feature === 'Sin soporte' || $feature === 'Estadística detallada' || $feature === 'Widget Spotify')): ?>
                                <i class="fas fa-times"></i>
                            <?php elseif ($userPlan === 'premium' && $feature === 'Widget Spotify'): ?>
                                <i class="fas fa-times"></i>
                            <?php else: ?>
                                <i class="fas fa-check"></i>
                            <?php endif; ?>
                            <span><?php echo htmlspecialchars($feature); ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Soporte -->
            <div class="config-card">
                <h2 style="margin-bottom: 1.5rem; color: #1f2937;">
                    <i class="fas fa-life-ring"></i> ¿Necesitas Ayuda?
                </h2>
                
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem;">
                    <div class="config-section">
                        <h4 style="margin: 0 0 1rem 0; color: #374151;">
                            <i class="fas fa-book"></i> Documentación
                        </h4>
                        <p style="color: #6b7280; margin-bottom: 1rem;">
                            Consulta nuestra documentación completa para configurar y usar el plugin.
                        </p>
                        <a href="#" class="btn btn-secondary" style="display: inline-block;">
                            Ver Documentación
                        </a>
                    </div>
                    
                    <div class="config-section">
                        <h4 style="margin: 0 0 1rem 0; color: #374151;">
                            <i class="fas fa-envelope"></i> Soporte Técnico
                        </h4>
                        <p style="color: #6b7280; margin-bottom: 1rem;">
                            ¿Tienes problemas? Nuestro equipo de soporte está aquí para ayudarte.
                        </p>
                        <a href="contact.php" class="btn btn-secondary" style="display: inline-block;">
                            Contactar Soporte
                        </a>
                    </div>
                </div>
            </div>

        </div>
    </main>

    <script src="../assets/js/script.js"></script>
</body>
</html>