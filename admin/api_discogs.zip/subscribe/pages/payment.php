<?php
// Definir constante para acceso a la API
define('API_ACCESS', true);

// Incluir configuración de base de datos
require_once '../../config/database.php';

// Verificar sesión
session_start();
if (!isset($_SESSION['subscriber_id'])) {
    header('Location: ../index.php');
    exit;
}

$subscriber_id = $_SESSION['subscriber_id'];

// Obtener información del suscriptor
$subscriber = $pdo->prepare("SELECT * FROM subscribers WHERE id = ?");
$subscriber->execute([$subscriber_id]);
$subscriber_data = $subscriber->fetch(PDO::FETCH_ASSOC);

// Obtener el plan seleccionado
$plan_type = $_GET['plan'] ?? 'premium';
$plan_prices = [
    'premium' => 29,
    'enterprise' => 99
];

if (!isset($plan_prices[$plan_type])) {
    header('Location: plans.php');
    exit;
}

$plan_price = $plan_prices[$plan_type];
$plan_name = ucfirst($plan_type);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pago - DiscogsSync</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            padding: 20px;
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
        }
        
        .nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1400px;
            margin: 0 auto;
        }
        
        .logo {
            font-size: 28px;
            font-weight: bold;
            background: linear-gradient(45deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .nav-links {
            display: flex;
            gap: 20px;
        }
        
        .nav-links a {
            color: #333;
            text-decoration: none;
            padding: 12px 20px;
            border-radius: 25px;
            transition: all 0.3s ease;
            font-weight: 500;
        }
        
        .nav-links a:hover {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            transform: translateY(-2px);
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 30px 20px;
        }
        
        .payment-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        .payment-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .payment-header h1 {
            background: linear-gradient(45deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 15px;
            font-size: 2.5rem;
        }
        
        .plan-summary {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 15px;
            margin-bottom: 30px;
            border-left: 5px solid #667eea;
        }
        
        .plan-summary h3 {
            color: #333;
            margin-bottom: 10px;
        }
        
        .plan-details {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .plan-name {
            font-size: 1.2rem;
            font-weight: bold;
            color: #333;
        }
        
        .plan-price {
            font-size: 1.5rem;
            font-weight: bold;
            color: #667eea;
        }
        
        .plan-features {
            list-style: none;
            margin-top: 15px;
        }
        
        .plan-features li {
            padding: 5px 0;
            color: #666;
        }
        
        .plan-features li::before {
            content: '✅';
            margin-right: 10px;
        }
        
        .payment-methods {
            margin-bottom: 30px;
        }
        
        .payment-methods h3 {
            margin-bottom: 20px;
            color: #333;
        }
        
        .payment-option {
            border: 2px solid #e9ecef;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .payment-option:hover {
            border-color: #667eea;
            background: #f8f9fa;
        }
        
        .payment-option.selected {
            border-color: #667eea;
            background: #f0f6fc;
        }
        
        .payment-option h4 {
            color: #333;
            margin-bottom: 10px;
        }
        
        .payment-option p {
            color: #666;
            margin-bottom: 10px;
        }
        
        .paypal-button {
            background: #0070ba;
            color: white;
            border: none;
            padding: 15px 30px;
            border-radius: 25px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            width: 100%;
        }
        
        .paypal-button:hover {
            background: #005ea6;
            transform: translateY(-2px);
        }
        
        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s ease;
        }
        
        .back-link:hover {
            color: #764ba2;
        }
        
        .security-info {
            background: #e8f5e8;
            border: 1px solid #28a745;
            border-radius: 10px;
            padding: 15px;
            margin-top: 20px;
            text-align: center;
        }
        
        .security-info p {
            color: #155724;
            margin: 0;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="nav">
            <div class="logo">🎵 DiscogsSync</div>
            <div class="nav-links">
                <a href="dashboard.php">🏠 Dashboard</a>
                <a href="plans.php">📋 Planes</a>
                <a href="logout.php">🚪 Cerrar Sesión</a>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="payment-card">
            <div class="payment-header">
                <h1>💳 Procesar Pago</h1>
                <p>Completa tu suscripción a DiscogsSync</p>
            </div>

            <!-- Resumen del Plan -->
            <div class="plan-summary">
                <h3>📋 Resumen de tu Suscripción</h3>
                <div class="plan-details">
                    <div class="plan-name">Plan <?php echo $plan_name; ?></div>
                    <div class="plan-price">$<?php echo $plan_price; ?>/mes</div>
                </div>
                <ul class="plan-features">
                    <?php if ($plan_type === 'premium'): ?>
                        <li>1,000 importaciones por mes</li>
                        <li>10,000 llamadas API por mes</li>
                        <li>Soporte prioritario</li>
                        <li>Actualizaciones automáticas</li>
                    <?php else: ?>
                        <li>Sincronizaciones ilimitadas</li>
                        <li>Llamadas API ilimitadas</li>
                        <li>Soporte 24/7</li>
                        <li>API personalizada</li>
                    <?php endif; ?>
                </ul>
            </div>

            <!-- Métodos de Pago -->
            <div class="payment-methods">
                <h3>💳 Métodos de Pago</h3>
                
                <div class="payment-option selected" id="paypal-option">
                    <h4>🅿️ PayPal</h4>
                    <p>Paga de forma segura con tu cuenta de PayPal</p>
                    <p><small>✅ Pago seguro y protegido</small></p>
                </div>
            </div>

            <!-- Botón de PayPal -->
            <button class="paypal-button" onclick="processPayPalPayment()">
                🅿️ Pagar con PayPal - $<?php echo $plan_price; ?>
            </button>

            <!-- Información de Seguridad -->
            <div class="security-info">
                <p>🔒 Tu pago está protegido por PayPal. No almacenamos información de tarjetas de crédito.</p>
            </div>
        </div>

        <div style="text-align: center;">
            <a href="plans.php" class="back-link">← Volver a Planes</a>
        </div>
    </div>

    <script>
        function processPayPalPayment() {
            // Aquí se integrará con la API de PayPal
            const planType = '<?php echo $plan_type; ?>';
            const planPrice = <?php echo $plan_price; ?>;
            const subscriberId = <?php echo $subscriber_id; ?>;
            
            // Mostrar loading
            const button = document.querySelector('.paypal-button');
            const originalText = button.innerHTML;
            button.innerHTML = '🔄 Procesando...';
            button.disabled = true;
            
            // Simular procesamiento (esto se reemplazará con la integración real de PayPal)
            setTimeout(() => {
                // Crear formulario para enviar a PayPal
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = 'process_payment.php';
                
                const planInput = document.createElement('input');
                planInput.type = 'hidden';
                planInput.name = 'plan_type';
                planInput.value = planType;
                
                const priceInput = document.createElement('input');
                priceInput.type = 'hidden';
                priceInput.name = 'plan_price';
                priceInput.value = planPrice;
                
                const subscriberInput = document.createElement('input');
                subscriberInput.type = 'hidden';
                subscriberInput.name = 'subscriber_id';
                subscriberInput.value = subscriberId;
                
                form.appendChild(planInput);
                form.appendChild(priceInput);
                form.appendChild(subscriberInput);
                
                document.body.appendChild(form);
                form.submit();
            }, 2000);
        }
    </script>
</body>
</html>

