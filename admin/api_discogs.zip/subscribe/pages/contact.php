<?php
/**
 * Formulario de contacto
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitizar datos
    $data = sanitizeInput($_POST);
    
    // Validaciones
    if (empty($data['name'])) {
        $errors[] = 'El nombre es obligatorio';
    }
    
    if (empty($data['email']) || !isValidEmail($data['email'])) {
        $errors[] = 'El email es obligatorio y debe ser válido';
    }
    
    if (empty($data['subject'])) {
        $errors[] = 'El asunto es obligatorio';
    }
    
    if (empty($data['message'])) {
        $errors[] = 'El mensaje es obligatorio';
    }
    
    // Si no hay errores, enviar email
    if (empty($errors)) {
        try {
            $to = 'support@discogsync.com'; // Cambiar por tu email de soporte
            $subject = 'Contacto desde DiscogsSync: ' . $data['subject'];
            $message = "
                <h2>Nuevo mensaje de contacto</h2>
                <p><strong>Nombre:</strong> " . htmlspecialchars($data['name']) . "</p>
                <p><strong>Email:</strong> " . htmlspecialchars($data['email']) . "</p>
                <p><strong>Asunto:</strong> " . htmlspecialchars($data['subject']) . "</p>
                <p><strong>Mensaje:</strong></p>
                <p>" . nl2br(htmlspecialchars($data['message'])) . "</p>
                <hr>
                <p><small>Enviado desde el formulario de contacto de DiscogsSync</small></p>
            ";
            
            if (sendEmail($to, $subject, $message)) {
                $success = 'Mensaje enviado correctamente. Te responderemos pronto.';
            } else {
                $errors[] = 'Error al enviar el mensaje. Por favor, inténtalo de nuevo.';
            }
        } catch (Exception $e) {
            $errors[] = 'Error al enviar el mensaje: ' . $e->getMessage();
        }
    }
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contacto - DiscogsSync</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-logo">
                    <a href="../index.php" style="text-decoration: none; color: inherit;">
                        <h2><i class="fas fa-music"></i> DiscogsSync</h2>
                    </a>
                </div>
                <div class="nav-menu">
                    <a href="../index.php" class="nav-link">Inicio</a>
                    <a href="login.php" class="nav-link">Iniciar Sesión</a>
                </div>
            </div>
        </nav>
    </header>

    <!-- Main Content -->
    <main style="padding-top: 100px; min-height: 100vh; background: #f8fafc;">
        <div class="container" style="max-width: 800px;">
            <div style="background: white; border-radius: 16px; padding: 3rem; box-shadow: 0 10px 25px rgba(0,0,0,0.1);">
                
                <!-- Header -->
                <div style="text-align: center; margin-bottom: 2rem;">
                    <h1 style="color: #1f2937; margin-bottom: 0.5rem;">Contacto</h1>
                    <p style="color: #6b7280;">¿Necesitas ayuda? Estamos aquí para asistirte</p>
                </div>
                
                <!-- Success Message -->
                <?php if (!empty($success)): ?>
                    <div class="alert alert-success" style="background: #d1fae5; color: #065f46; border: 1px solid #a7f3d0; padding: 1rem; border-radius: 8px; margin-bottom: 2rem;">
                        <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?>
                    </div>
                <?php endif; ?>
                
                <!-- Error Messages -->
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-error" style="background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; padding: 1rem; border-radius: 8px; margin-bottom: 2rem;">
                        <ul style="margin: 0; padding-left: 1rem;">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo $error; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <!-- Contact Form -->
                <form method="POST" data-validate>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="name">Nombre *</label>
                            <input type="text" id="name" name="name" class="form-control" 
                                   value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email *</label>
                            <input type="email" id="email" name="email" class="form-control" 
                                   value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="subject">Asunto *</label>
                        <input type="text" id="subject" name="subject" class="form-control" 
                               value="<?php echo htmlspecialchars($_POST['subject'] ?? ''); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="message">Mensaje *</label>
                        <textarea id="message" name="message" class="form-control" rows="6" 
                                  placeholder="Describe tu consulta o problema..." required><?php echo htmlspecialchars($_POST['message'] ?? ''); ?></textarea>
                    </div>

                    <div style="text-align: center; margin-top: 2rem;">
                        <button type="submit" class="btn btn-primary btn-large">
                            <i class="fas fa-paper-plane"></i> Enviar Mensaje
                        </button>
                    </div>
                </form>

                <!-- Contact Information -->
                <div style="margin-top: 3rem; padding-top: 2rem; border-top: 1px solid #e5e7eb;">
                    <h3 style="color: #1f2937; margin-bottom: 1.5rem;">Información de Contacto</h3>
                    
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem;">
                        <div style="text-align: center; padding: 1.5rem; background: #f9fafb; border-radius: 12px;">
                            <i class="fas fa-envelope" style="font-size: 2rem; color: #059669; margin-bottom: 1rem;"></i>
                            <h4 style="margin: 0 0 0.5rem 0; color: #1f2937;">Email</h4>
                            <p style="margin: 0; color: #6b7280;">support@discogsync.com</p>
                        </div>
                        
                        <div style="text-align: center; padding: 1.5rem; background: #f9fafb; border-radius: 12px;">
                            <i class="fas fa-clock" style="font-size: 2rem; color: #059669; margin-bottom: 1rem;"></i>
                            <h4 style="margin: 0 0 0.5rem 0; color: #1f2937;">Horario</h4>
                            <p style="margin: 0; color: #6b7280;">Lunes - Viernes<br>9:00 - 18:00</p>
                        </div>
                        
                        <div style="text-align: center; padding: 1.5rem; background: #f9fafb; border-radius: 12px;">
                            <i class="fas fa-headset" style="font-size: 2rem; color: #059669; margin-bottom: 1rem;"></i>
                            <h4 style="margin: 0 0 0.5rem 0; color: #1f2937;">Soporte</h4>
                            <p style="margin: 0; color: #6b7280;">Respuesta en 24h</p>
                        </div>
                    </div>
                </div>

                <!-- Back to Home -->
                <div style="text-align: center; margin-top: 2rem;">
                    <a href="../index.php" style="color: #059669; text-decoration: none;">
                        <i class="fas fa-arrow-left"></i> Volver al Inicio
                    </a>
                </div>
            </div>
        </div>
    </main>

    <script src="../assets/js/script.js"></script>
</body>
</html>

