<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

startSecureSession();
requireLogin();

$subscriber_id = $_SESSION['user_id'];

// Obtener información del suscriptor
$pdo = new PDO(
    "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
    DB_USER,
    DB_PASS,
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
);

$subscriber = $pdo->prepare("SELECT * FROM subscribers WHERE id = ?");
$subscriber->execute([$subscriber_id]);
$subscriber_data = $subscriber->fetch(PDO::FETCH_ASSOC);

// Obtener ciclos de facturación del suscriptor
$billing_cycles = $pdo->prepare("
    SELECT * FROM billing_cycles 
    WHERE subscriber_id = ? 
    ORDER BY created_at DESC 
    LIMIT 20
");
$billing_cycles->execute([$subscriber_id]);
$billing_cycles_data = $billing_cycles->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Facturación - dwoosync</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/pages.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-logo">
                    <a href="../index.php" style="text-decoration: none; color: inherit;">
                        <h2><i class="fas fa-music"></i> dwoosync</h2>
                    </a>
            </div>
                <div class="nav-menu">
                    <a href="dashboard.php" class="nav-link">🏠 Inicio</a>
                    <a href="profile.php" class="nav-link">👤 Perfil</a>
                    <a href="billing.php" class="nav-link btn-primary">💳 Facturación</a>
                    <a href="plugin-config.php" class="nav-link">⚙️ Configurar Plugin</a>
                    <a href="logout.php" class="nav-link btn-logout">🚪 Cerrar Sesión</a>
        </div>
    </div>
        </nav>
    </header>

    <!-- Main Content -->
    <main class="main">
    <div class="container">
            <div class="card">
                <h1 style="text-align: center; margin-bottom: 2rem; color: #1f2937;">
                    <i class="fas fa-file-invoice"></i> Facturación
                </h1>
                
                <p style="text-align: center; color: #6b7280; margin-bottom: 2rem;">
                    Gestiona tu suscripción, pagos y facturación
                </p>

                <?php if (($subscriber_data['plan_type'] ?? 'free') === 'free'): ?>
                    <!-- Mensaje para Plan Free -->
                    <div style="text-align: center; padding: 2rem; background: #f9fafb; border-radius: 12px; margin-bottom: 2rem;">
                        <div style="font-size: 4rem; margin-bottom: 1rem;">🎵</div>
                        <h2 style="color: #1f2937; margin-bottom: 1rem;">Plan Gratuito</h2>
                        <p style="color: #6b7280; margin-bottom: 1.5rem;">
                            Actualmente tienes el plan gratuito de dwoosync.
                        </p>
                        <button onclick="openPlansModal()" class="btn btn-primary">
                    <i class="fas fa-arrow-up"></i> Mejorar Plan
                </button>
            </div>
        <?php else: ?>
                    <!-- Estadísticas -->
                    <div class="grid grid-3" style="margin-bottom: 2rem;">
                        <div style="text-align: center; padding: 1.5rem; background: #f9fafb; border-radius: 8px;">
                            <div style="font-size: 2.5rem; color: #059669; margin-bottom: 0.5rem;">
                                <i class="fas fa-dollar-sign"></i>
                </div>
                            <h3 style="color: #1f2937; margin-bottom: 0.5rem;">Total Pagado</h3>
                            <div style="font-size: 1.5rem; font-weight: bold; color: #059669;">
                                $<?php 
                                $total = 0;
                                foreach ($billing_cycles_data as $invoice) {
                                    if ($invoice['status'] === 'paid') {
                                        $total += $invoice['amount'];
                                    }
                                }
                                echo number_format($total, 2);
                        ?>
                    </div>
                        </div>
                        
                        <div style="text-align: center; padding: 1.5rem; background: #f9fafb; border-radius: 8px;">
                            <div style="font-size: 2.5rem; color: #059669; margin-bottom: 0.5rem;">
                                <i class="fas fa-receipt"></i>
                            </div>
                            <h3 style="color: #1f2937; margin-bottom: 0.5rem;">Facturas</h3>
                            <div style="font-size: 1.5rem; font-weight: bold; color: #059669;">
                                <?php echo count($billing_cycles_data); ?>
                            </div>
                        </div>
                        
                        <div style="text-align: center; padding: 1.5rem; background: #f9fafb; border-radius: 8px;">
                            <div style="font-size: 2.5rem; color: #059669; margin-bottom: 0.5rem;">
                                <i class="fas fa-check-circle"></i>
                    </div>
                            <h3 style="color: #1f2937; margin-bottom: 0.5rem;">Pagadas</h3>
                            <div style="font-size: 1.5rem; font-weight: bold; color: #059669;">
                                <?php 
                                $paid_count = 0;
                                foreach ($billing_cycles_data as $invoice) {
                                    if ($invoice['status'] === 'paid') {
                                        $paid_count++;
                                    }
                                }
                                echo $paid_count;
                                ?>
                    </div>
            </div>
        </div>

                    <!-- Historial de Facturas -->
                    <div class="card">
                        <h2 style="margin-bottom: 1.5rem; color: #1f2937;">
                            <i class="fas fa-file-invoice"></i> Historial de Facturas
                </h2>
                
                        <?php if (!empty($billing_cycles_data)): ?>
                            <div style="overflow-x: auto;">
                                <table style="width: 100%; border-collapse: collapse; margin-top: 1rem;">
                            <thead>
                                        <tr style="background: #f8fafc; border-bottom: 2px solid #e5e7eb;">
                                            <th style="padding: 1rem; text-align: left; font-weight: 600; color: #374151;">Número</th>
                                            <th style="padding: 1rem; text-align: left; font-weight: 600; color: #374151;">Monto</th>
                                            <th style="padding: 1rem; text-align: left; font-weight: 600; color: #374151;">Estado</th>
                                            <th style="padding: 1rem; text-align: left; font-weight: 600; color: #374151;">Vencimiento</th>
                                            <th style="padding: 1rem; text-align: left; font-weight: 600; color: #374151;">Pago</th>
                                            <th style="padding: 1rem; text-align: left; font-weight: 600; color: #374151;">Período</th>
                                            <th style="padding: 1rem; text-align: center; font-weight: 600; color: #374151;">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                        <?php foreach ($billing_cycles_data as $invoice): ?>
                                            <tr style="border-bottom: 1px solid #e5e7eb;">
                                                <td style="padding: 1rem;">
                                                    <strong><?php echo htmlspecialchars($invoice['invoice_number']); ?></strong>
                                                </td>
                                                <td style="padding: 1rem;">
                                                    <strong>$<?php echo number_format($invoice['amount'], 2); ?></strong>
                                                </td>
                                                <td style="padding: 1rem;">
                                                    <?php
                                                    $status = $invoice['status'];
                                                    $status_class = '';
                                                    $status_icon = '';
                                                    
                                                    switch ($status) {
                                                        case 'paid':
                                                            $status_class = 'background: #d1fae5; color: #065f46;';
                                                            $status_icon = '✅';
                                                            break;
                                                        case 'pending':
                                                            $due_date = new DateTime($invoice['due_date']);
                                                            $today = new DateTime();
                                                            if ($today > $due_date) {
                                                                $status_class = 'background: #fee2e2; color: #991b1b;';
                                                                $status_icon = '⚠️';
                                                            } else {
                                                                $status_class = 'background: #fef3c7; color: #92400e;';
                                                                $status_icon = '⏳';
                                                            }
                                                            break;
                                                        case 'cancelled':
                                                            $status_class = 'background: #f3f4f6; color: #6b7280;';
                                                            $status_icon = '❌';
                                                            break;
                                                        case 'refunded':
                                                            $status_class = 'background: #e0e7ff; color: #3730a3;';
                                                            $status_icon = '🔄';
                                                            break;
                                                    }
                                                    ?>
                                                    <span style="padding: 6px 12px; border-radius: 20px; font-size: 0.8rem; font-weight: 600; <?php echo $status_class; ?>">
                                                        <?php echo $status_icon; ?> <?php echo strtoupper($status); ?>
                                            </span>
                                        </td>
                                                <td style="padding: 1rem;">
                                                    <?php echo date('d/m/Y', strtotime($invoice['due_date'])); ?>
                                                    <?php if ($status === 'pending'): ?>
                                                        <?php
                                                        $due_date = new DateTime($invoice['due_date']);
                                                        $today = new DateTime();
                                                        if ($today > $due_date) {
                                                            $days_overdue = $today->diff($due_date)->days;
                                                            echo '<br><small style="color: #dc2626;">Vencida hace ' . $days_overdue . ' días</small>';
                                                        } else {
                                                            $days_remaining = $today->diff($due_date)->days;
                                                            echo '<br><small style="color: #059669;">Vence en ' . $days_remaining . ' días</small>';
                                                        }
                                                        ?>
                                                    <?php endif; ?>
                                                </td>
                                                <td style="padding: 1rem;">
                                                    <?php 
                                                    if ($invoice['paid_date']) {
                                                        echo date('d/m/Y', strtotime($invoice['paid_date']));
                                                    } else {
                                                        echo '<span style="color: #6b7280;">-</span>';
                                                    }
                                                    ?>
                                                </td>
                                                <td style="padding: 1rem;">
                                                    <?php if ($invoice['cycle_start_date'] && $invoice['cycle_end_date']): ?>
                                                        <?php echo date('d/m/Y', strtotime($invoice['cycle_start_date'])); ?> - 
                                                        <?php echo date('d/m/Y', strtotime($invoice['cycle_end_date'])); ?>
                <?php else: ?>
                                                        <span style="color: #6b7280;">-</span>
                <?php endif; ?>
                                        </td>
                                                <td style="padding: 1rem; text-align: center;">
                                                    <?php if ($status === 'pending'): ?>
                                                        <a href="checkout.php?plan=<?php echo urlencode($subscriber_data['plan_type']); ?>&billing_cycle_id=<?php echo $invoice['id']; ?>" 
                                                           style="background: #059669; color: white; padding: 8px 16px; border-radius: 6px; text-decoration: none; font-size: 0.9rem; font-weight: 500; display: inline-block; transition: all 0.3s ease;"
                                                           onmouseover="this.style.background='#047857'; this.style.transform='translateY(-1px)'"
                                                           onmouseout="this.style.background='#059669'; this.style.transform='translateY(0)'">
                                                            <i class="fas fa-credit-card"></i> Pagar
                                                        </a>
                                                    <?php elseif ($status === 'paid'): ?>
                                                        <span style="color: #059669; font-weight: 500;">
                                                            <i class="fas fa-check-circle"></i> Pagada
                                                        </span>
                                                    <?php else: ?>
                                                        <span style="color: #6b7280;">
                                                            <i class="fas fa-ban"></i> No disponible
                                            </span>
                                                    <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                            <div style="text-align: center; padding: 3rem; color: #6b7280;">
                                <i class="fas fa-file-invoice" style="font-size: 3rem; margin-bottom: 1rem;"></i>
                                <p>No hay facturas registradas</p>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <script src="../assets/js/script.js"></script>

    <!-- Modal de Planes -->
    <div id="plansModal" class="modal" style="display: none;">
        <div class="modal-content">
            <div class="modal-header">
                <h2><i class="fas fa-crown"></i> Selecciona tu Plan</h2>
                <button class="modal-close" onclick="closePlansModal()">&times;</button>
            </div>
            <div class="modal-body">
                <div class="plans-grid">
                    <!-- Plan Free -->
                    <div class="plan-card" data-plan="free" onclick="selectPlan('free')">
                        <div class="plan-header">
                            <h3>Free</h3>
                            <div class="plan-price">€0<span>/mes</span></div>
                        </div>
                        <div class="plan-features">
                            <ul>
                                <li><i class="fas fa-check"></i> Importaciones ilimitadas</li>
                                <li><i class="fas fa-check"></i> Llamadas API ilimitadas</li>
                                <li><i class="fas fa-check"></i> Soporte por email</li>
                                <li><i class="fas fa-check"></i> Actualizaciones básicas</li>
                            </ul>
                        </div>
                        <div class="plan-button">
                            <span class="current-plan">Plan Actual</span>
                        </div>
                    </div>

                    <!-- Plan Premium -->
                    <div class="plan-card premium" data-plan="premium" onclick="selectPlan('premium')">
                        <div class="plan-badge">Más Popular</div>
                        <div class="plan-header">
                            <h3>Premium</h3>
                            <div class="plan-price">€22<span>/mes</span></div>
                        </div>
                        <div class="plan-features">
                            <ul>
                                <li><i class="fas fa-check"></i> Importaciones ilimitadas</li>
                                <li><i class="fas fa-check"></i> Llamadas API ilimitadas</li>
                                <li><i class="fas fa-check"></i> Soporte prioritario</li>
                                <li><i class="fas fa-check"></i> Todas las actualizaciones</li>
                                <li><i class="fas fa-check"></i> Estadísticas avanzadas</li>
                                <li><i class="fas fa-times" style="color: #dc2626;"></i> Widget Spotify</li>
                            </ul>
                        </div>
                        <div class="plan-button">
                            <button class="btn-select">Seleccionar</button>
                        </div>
                    </div>

                    <!-- Plan +Spotify -->
                    <div class="plan-card enterprise" data-plan="enterprise" onclick="selectPlan('enterprise')">
                        <div class="plan-header">
                            <h3>+Spotify</h3>
                            <div class="plan-price">€29<span>/mes</span></div>
                        </div>
                        <div class="plan-features">
                            <ul>
                                <li><i class="fas fa-check"></i> Importaciones ilimitadas</li>
                                <li><i class="fas fa-check"></i> Llamadas API ilimitadas</li>
                                <li><i class="fas fa-check"></i> Integración con Spotify</li>
                                <li><i class="fas fa-check"></i> Soporte prioritario</li>
                                <li><i class="fas fa-check"></i> Todas las actualizaciones</li>
                                <li><i class="fas fa-check"></i> Estadísticas avanzadas</li>
                            </ul>
                        </div>
                        <div class="plan-button">
                            <button class="btn-select">Seleccionar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Funciones del modal de planes
        function openPlansModal() {
            // Filtrar planes según el plan actual
            const currentPlan = '<?php echo $subscriber_data['plan_type'] ?? 'free'; ?>';
            const planCards = document.querySelectorAll('.plan-card');
            
            planCards.forEach(card => {
                const planType = card.getAttribute('data-plan');
                
                if (currentPlan === 'free') {
                    // Mostrar solo premium y enterprise
                    card.style.display = (planType === 'premium' || planType === 'enterprise') ? 'block' : 'none';
                } else if (currentPlan === 'premium') {
                    // Mostrar solo enterprise
                    card.style.display = (planType === 'enterprise') ? 'block' : 'none';
                } else {
                    // Ocultar todos si ya es enterprise
                    card.style.display = 'none';
                }
            });
            
            document.getElementById('plansModal').style.display = 'block';
            document.body.style.overflow = 'hidden';
        }

        function closePlansModal() {
            document.getElementById('plansModal').style.display = 'none';
            document.body.style.overflow = 'auto';
        }

        function selectPlan(planId) {
            // Cerrar el modal
            closePlansModal();
            
            // Redirigir al checkout con el plan seleccionado
            window.location.href = `checkout.php?plan=${planId}&renewal=true`;
        }

        // Cerrar modal al hacer clic fuera de él
        window.onclick = function(event) {
            const modal = document.getElementById('plansModal');
            if (event.target === modal) {
                closePlansModal();
            }
        }

        // Cerrar modal con tecla Escape
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                closePlansModal();
            }
        });
    </script>

    <style>
        /* Estilos del Modal */
        .modal {
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            backdrop-filter: blur(5px);
        }

        .modal-content {
            background: white;
            margin: 5% auto;
            padding: 0;
            border-radius: 20px;
            width: 90%;
            max-width: 1000px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 25px 50px rgba(0,0,0,0.3);
            animation: modalSlideIn 0.3s ease-out;
        }

        @keyframes modalSlideIn {
            from {
                opacity: 0;
                transform: translateY(-50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .modal-header {
            background: linear-gradient(45deg, #10b981, #059669);
            color: white;
            padding: 25px 30px;
            border-radius: 20px 20px 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-header h2 {
            margin: 0;
            font-size: 1.8rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .modal-close {
            background: none;
            border: none;
            color: white;
            font-size: 2rem;
            cursor: pointer;
            padding: 0;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s ease;
        }

        .modal-close:hover {
            background: rgba(255,255,255,0.2);
        }

        .modal-body {
            padding: 30px;
        }

        .plans-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 25px;
        }

        .plan-card {
            background: #f8f9fa;
            border: 2px solid #e5e7eb;
            border-radius: 15px;
            padding: 25px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
        }

        .plan-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.1);
        }

        .plan-card.premium {
            border-color: #f59e0b;
            background: linear-gradient(135deg, #fef3c7, #fde68a);
        }

        .plan-card.enterprise {
            border-color: #8b5cf6;
            background: linear-gradient(135deg, #f3e8ff, #e9d5ff);
        }

        .plan-badge {
            position: absolute;
            top: -10px;
            left: 50%;
            transform: translateX(-50%);
            background: linear-gradient(45deg, #f59e0b, #d97706);
            color: white;
            padding: 8px 20px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .plan-header h3 {
            font-size: 1.5rem;
            font-weight: bold;
            color: #1f2937;
            margin-bottom: 10px;
        }

        .plan-price {
            font-size: 2.5rem;
            font-weight: bold;
            color: #059669;
            margin-bottom: 20px;
        }

        .plan-price span {
            font-size: 1rem;
            color: #6b7280;
            font-weight: normal;
        }

        .plan-features ul {
            list-style: none;
            padding: 0;
            margin: 0 0 25px 0;
        }

        .plan-features li {
            padding: 8px 0;
            color: #4b5563;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .plan-features i {
            color: #10b981;
            font-size: 0.9rem;
        }

        .plan-button {
            margin-top: auto;
        }

        .btn-select {
            background: linear-gradient(45deg, #10b981, #059669);
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 25px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            width: 100%;
        }

        .btn-select:hover {
            background: linear-gradient(45deg, #5a67d8, #6b46c1);
            transform: translateY(-2px);
        }

        .current-plan {
            background: #6b7280;
            color: white;
            padding: 12px 30px;
            border-radius: 25px;
            font-weight: 600;
            display: inline-block;
            width: 100%;
        }

        @media (max-width: 768px) {
            .modal-content {
                margin: 2% auto;
                width: 95%;
            }
            
            .plans-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</body>
</html>
