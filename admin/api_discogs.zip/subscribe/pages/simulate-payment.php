<?php
/**
 * Simular pago para pruebas
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

// Iniciar sesión de forma segura
startSecureSession();

// Verificar que el usuario esté logueado
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Usuario no autenticado']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'simulate_payment') {
    // Log para debug
    error_log('[SIMULATE_PAYMENT] Iniciando pago simulado para subscriber_id: ' . $_SESSION['subscriber_id']);
    
    try {
        $db = getDatabase();
        $db->beginTransaction();
        
        $subscriberId = $_SESSION['subscriber_id'];
        $planType = $_POST['plan_type'] ?? 'free';
        
        // Obtener información del plan
        $planStmt = $db->prepare("SELECT price, plan_name FROM subscription_plans WHERE plan_type = ?");
        $planStmt->execute([$planType]);
        $planData = $planStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$planData) {
            throw new Exception('Plan no encontrado');
        }
        
        // Actualizar plan del suscriptor
        $stmt = $db->prepare("UPDATE subscribers SET plan_type = ?, status = 'active' WHERE id = ?");
        $stmt->execute([$planType, $subscriberId]);
        
        // Actualizar límite de uso de la licencia
        $usageLimit = ($planType === 'free') ? 10 : -1;
        $stmt = $db->prepare("UPDATE licenses SET status = 'active', usage_limit = ? WHERE subscriber_id = ?");
        $stmt->execute([$usageLimit, $subscriberId]);
        
        // No crear registro en payments - solo en billing_cycles
        
        // Crear o actualizar ciclo de facturación
        $paymentRef = 'TEST_' . time();
        
        // Verificar si existe un ciclo pendiente
        $cycleStmt = $db->prepare("
            SELECT id FROM billing_cycles 
            WHERE subscriber_id = ? AND status = 'pending' 
            ORDER BY created_at DESC LIMIT 1
        ");
        $cycleStmt->execute([$subscriberId]);
        $existingCycle = $cycleStmt->fetch(PDO::FETCH_ASSOC);
        
        if ($existingCycle) {
            // Generar número de factura para ciclo existente
            $invoiceNumber = 'INV-' . date('Y') . '-' . str_pad($subscriberId, 4, '0', STR_PAD_LEFT) . '-' . time();
            
            // Actualizar ciclo existente
            $stmt = $db->prepare("
                UPDATE billing_cycles 
                SET status = 'paid', 
                    paid_date = CURDATE(),
                    payment_method = 'test',
                    payment_reference = ?,
                    is_active = 1,
                    plan_type = ?,
                    amount = ?,
                    invoice_number = ?
                WHERE id = ?
            ");
            $stmt->execute([$paymentRef, $planType, $planData['price'], $invoiceNumber, $existingCycle['id']]);
            
            error_log('[SIMULATE_PAYMENT] Ciclo actualizado - ID: ' . $existingCycle['id'] . ', Invoice: ' . $invoiceNumber . ', Amount: ' . $planData['price']);
        } else {
            // Crear nuevo ciclo de facturación
            $licenseStmt = $db->prepare("SELECT license_key FROM licenses WHERE subscriber_id = ?");
            $licenseStmt->execute([$subscriberId]);
            $licenseData = $licenseStmt->fetch(PDO::FETCH_ASSOC);
            
            $cycleStart = date('Y-m-d');
            $cycleEnd = date('Y-m-d', strtotime('+30 days'));
            $dueDate = date('Y-m-d', strtotime('+7 days'));
            
            // Generar número de factura
            $invoiceNumber = 'INV-' . date('Y') . '-' . str_pad($subscriberId, 4, '0', STR_PAD_LEFT) . '-' . time();
            
            $stmt = $db->prepare("
                INSERT INTO billing_cycles (
                    subscriber_id, plan_type, license_key, cycle_start_date, 
                    cycle_end_date, due_date, amount, status, is_active, 
                    payment_method, payment_reference, paid_date, invoice_number, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, 'paid', 1, 'test', ?, CURDATE(), ?, NOW())
            ");
            $stmt->execute([
                $subscriberId, $planType, $licenseData['license_key'], 
                $cycleStart, $cycleEnd, $dueDate, $planData['price'], $paymentRef, $invoiceNumber
            ]);
            
            error_log('[SIMULATE_PAYMENT] Ciclo creado - Invoice: ' . $invoiceNumber . ', Amount: ' . $planData['price']);
        }
        
        $db->commit();
        
        // Limpiar estado de cuenta inactiva
        unset($_SESSION['account_status']);
        
        echo json_encode(['success' => true, 'message' => 'Pago simulado exitosamente']);
        
    } catch (Exception $e) {
        $db->rollback();
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Acción no válida']);
}
?>
