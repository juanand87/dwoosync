<?php
/**
 * Página de registro de suscripción - Versión nueva
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

// Iniciar sesión
startSecureSession();

// Si ya está logueado, redirigir al dashboard
if (isLoggedIn()) {
    header('Location: dashboard.php');
    exit;
}

$plan = $_GET['plan'] ?? 'free';
$plans = getSubscriptionPlans();

// Buscar el plan seleccionado
$selectedPlan = $plans[0];
foreach ($plans as $planData) {
    if ($planData['id'] === $plan) {
        $selectedPlan = $planData;
        break;
    }
}

$errors = [];
$success = '';

// Generar token CSRF
$csrfToken = generateCSRFToken();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verificar token CSRF
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Token de seguridad inválido';
    } else {
        // Sanitizar datos
        $data = sanitizeInput($_POST);
        
        // Validaciones
        if (empty($data['first_name'])) {
            $errors[] = 'El nombre es obligatorio';
        }
        
        if (empty($data['last_name'])) {
            $errors[] = 'El apellido es obligatorio';
        }
        
        if (empty($data['email']) || !isValidEmail($data['email'])) {
            $errors[] = 'El email es obligatorio y debe ser válido';
        }
        
        if (empty($data['password']) || strlen($data['password']) < 6) {
            $errors[] = 'La contraseña debe tener al menos 6 caracteres';
        }
        
        if ($data['password'] !== $data['confirm_password']) {
            $errors[] = 'Las contraseñas no coinciden';
        }
        
        if (empty($data['domain'])) {
            $errors[] = 'El dominio es obligatorio';
        }
        
        // Verificar si el dominio ya existe
        if (empty($errors)) {
            try {
                $db = Database::getInstance();
                $existingDomain = $db->fetch('SELECT id FROM subscribers WHERE domain = ?', [$data['domain']]);
                
                if ($existingDomain) {
                    $error = 'El dominio "' . htmlspecialchars($data['domain']) . '" ya se encuentra registrado. ';
                    $error .= 'Puedes <a href="login.php" style="color: #059669; text-decoration: underline;">iniciar sesión</a> o ';
                    $error .= '<a href="login.php" style="color: #059669; text-decoration: underline;">recuperar contraseña</a>. ';
                    $error .= 'Para más información puedes contactar a <a href="contact.php" style="color: #059669; text-decoration: underline;">soporte</a>.';
                    $errors[] = $error;
                }
            } catch (Exception $e) {
                $errors[] = 'Error al verificar el dominio: ' . $e->getMessage();
            }
        }
        
        // Si no hay errores, crear el usuario temporal y redirigir al checkout
        if (empty($errors)) {
            try {
                $db = Database::getInstance();
                
                // Hash de la contraseña
                $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);
                
                // Crear usuario con status 'pending' hasta completar el pago
                $userId = $db->insert('subscribers', [
                    'first_name' => $data['first_name'],
                    'last_name' => $data['last_name'],
                    'email' => $data['email'],
                    'password' => $hashedPassword,
                    'domain' => $data['domain'],
                    'company' => $data['company'] ?? '',
                    'city' => $data['city'] ?? '',
                    'country' => $data['country'] ?? '',
                    'phone' => $data['phone'] ?? '',
                    'plan_type' => $selectedPlan['id'],
                    'status' => 'pending', // Pendiente hasta completar pago
                    'created_at' => date('Y-m-d H:i:s')
                ]);
                
                // Crear licencia temporal con límite basado en el plan
                $licenseKey = 'DISC' . strtoupper(substr(md5($userId . time()), 0, 8));
                $subscriptionCode = 'SUB' . strtoupper(substr(md5($userId . time() . rand()), 0, 12));
                
                // Obtener límite de uso desde la base de datos
                $plan = $db->query("SELECT requests_per_month FROM subscription_plans WHERE plan_type = '{$selectedPlan['id']}'")->fetch();
                $usageLimit = $plan ? $plan['requests_per_month'] : 10;
                
                $db->insert('licenses', [
                    'subscriber_id' => $userId,
                    'subscription_code' => $subscriptionCode,
                    'license_key' => $licenseKey,
                    'domain' => $data['domain'],
                    'status' => 'pending', // Pendiente hasta completar pago
                    'usage_count' => 0,
                    'usage_limit' => $usageLimit,
                    'created_at' => date('Y-m-d H:i:s'),
                    'expires_at' => $selectedPlan['id'] === 'enterprise' ? null : 
                                   date('Y-m-d H:i:s', strtotime('+1 year'))
                ]);
                
                // Crear ciclo de facturación inicial
                $cycleStartDate = date('Y-m-d');
                $cycleEndDate = date('Y-m-d', strtotime('+30 days')); // Todos los planes: 30 días (mensual)
                
                // Crear número de factura
                $invoiceNumber = 'INV-' . date('Y') . '-' . str_pad($userId, 6, '0', STR_PAD_LEFT) . '-' . str_pad(time(), 4, '0', STR_PAD_LEFT);
                
                // Obtener precio del plan desde la base de datos
                $plan = $db->query("SELECT price FROM subscription_plans WHERE plan_type = '{$selectedPlan['id']}'")->fetch();
                $amount = $plan ? $plan['price'] : 0.00;
                $dueDate = $selectedPlan['id'] === 'free' ? 
                    date('Y-m-d', strtotime('+30 days')) : // Plan gratuito: vence en 30 días (mismo que el ciclo)
                    date('Y-m-d', strtotime('+7 days')); // Planes pagos: vence en 7 días
                
                // Crear ciclo de facturación (incluye toda la información de factura)
                $cycleId = $db->insert('billing_cycles', [
                    'subscriber_id' => $userId,
                    'plan_type' => $selectedPlan['id'],
                    'license_key' => $licenseKey,
                    'cycle_start_date' => $cycleStartDate,
                    'cycle_end_date' => $cycleEndDate,
                    'is_active' => $selectedPlan['id'] === 'free',
                    'invoice_number' => $invoiceNumber,
                    'amount' => $amount,
                    'currency' => 'USD',
                    'status' => $selectedPlan['id'] === 'free' ? 'paid' : 'pending',
                    'due_date' => $dueDate,
                    'paid_date' => $selectedPlan['id'] === 'free' ? date('Y-m-d') : null,
                    'sync_count' => 0,
                    'api_calls_count' => 0,
                    'products_synced' => 0,
                    'created_at' => date('Y-m-d H:i:s')
                ]);
                
                // Guardar datos en sesión para el checkout
                $_SESSION['subscriber_id'] = $userId;
                $_SESSION['user_id'] = $userId;
                $_SESSION['user_email'] = $data['email'];
                $_SESSION['user_name'] = $data['first_name'] . ' ' . $data['last_name'];
                $_SESSION['user_domain'] = $data['domain'];
                $_SESSION['user_plan'] = $selectedPlan['id'];
                $_SESSION['login_time'] = time();
                $_SESSION['license_key'] = $licenseKey;
                $_SESSION['signup_data'] = $data; // Datos completos para el checkout
                
                // Redirigir al checkout
                header('Location: checkout.php?plan=' . $selectedPlan['id']);
                exit;
                
            } catch (Exception $e) {
                $errors[] = 'Error al crear la cuenta: ' . $e->getMessage();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro - DiscogsSync</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/pages.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-logo">
                    <a href="../index.php" style="text-decoration: none; color: inherit;">
                        <h2><i class="fas fa-music"></i> DiscogsSync</h2>
                    </a>
                </div>
                <div class="nav-menu">
                    <a href="../index.php" class="nav-link">Inicio</a>
                    <a href="login.php" class="nav-link btn-login">Iniciar Sesión</a>
                </div>
            </div>
        </nav>
    </header>

    <!-- Main Content -->
    <main style="padding-top: 100px; min-height: 100vh; background: #f8fafc;">
        <div class="container" style="max-width: 800px;">
            <div style="background: white; border-radius: 16px; padding: 3rem; box-shadow: 0 10px 25px rgba(0,0,0,0.1);">
                <!-- Plan Selection -->
                <div style="margin-bottom: 2rem;">
                    <h2 style="text-align: center; margin-bottom: 2rem; color: #1f2937;">Selecciona tu Plan</h2>
                    
                    <div class="plans-grid" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 1.5rem; margin-bottom: 2rem;">
                        <?php foreach ($plans as $planData): ?>
                            <div class="plan-card" 
                                 style="border: 2px solid <?php echo $planData['id'] === $selectedPlan['id'] ? '#059669' : '#e5e7eb'; ?>; 
                                        border-radius: 12px; padding: 1.5rem; text-align: center; cursor: pointer; 
                                        transition: all 0.3s ease; background: <?php echo $planData['id'] === $selectedPlan['id'] ? '#f0fdf4' : 'white'; ?>;"
                                 data-plan="<?php echo $planData['id']; ?>"
                                 onclick="selectPlan('<?php echo $planData['id']; ?>')">
                                
                                <?php if ($planData['featured']): ?>
                                    <div style="background: #059669; color: white; padding: 0.5rem; border-radius: 8px; margin-bottom: 1rem; font-weight: bold;">
                                        Más Popular
                                    </div>
                                <?php endif; ?>
                                
                                <h3 style="font-size: 1.5rem; margin-bottom: 0.5rem; color: #1f2937;">
                                    <?php echo htmlspecialchars($planData['name']); ?>
                                </h3>
                                
                                <div style="font-size: 2rem; font-weight: bold; color: #059669; margin-bottom: 1rem;">
                                    $<?php echo number_format($planData['price']); ?>/mes
                                </div>
                                
                                <div style="margin-top: 1rem;">
                                    <div style="text-align: center; margin-bottom: 0.75rem;">
                                        <span style="color: #059669; cursor: pointer; text-decoration: underline; font-size: 1rem; font-weight: 500;"
                                              onclick="showPlanInfo('<?php echo $planData['id']; ?>')"
                                              onmouseover="this.style.color='#047857'; this.style.textDecoration='none';"
                                              onmouseout="this.style.color='#059669'; this.style.textDecoration='underline';">
                                            + Info
                                        </span>
                                    </div>
                                    
                                    <button type="button" 
                                            style="background: <?php echo $planData['id'] === $selectedPlan['id'] ? '#059669' : '#6b7280'; ?>; 
                                                   color: white; border: none; padding: 0.75rem 1.5rem; border-radius: 8px; 
                                                   cursor: pointer; font-weight: bold; width: 100%;"
                                            onclick="selectPlan('<?php echo $planData['id']; ?>')">
                                        <?php echo $planData['id'] === $selectedPlan['id'] ? 'Seleccionado' : 'Seleccionar'; ?>
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                </div>

                <!-- Form -->
                <h2 style="text-align: center; margin-bottom: 2rem; color: #1f2937;">Crear Cuenta</h2>
                
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-error" style="background: #fef2f2; border: 1px solid #fecaca; color: #dc2626; padding: 1rem; border-radius: 8px; margin-bottom: 1.5rem;">
                        <ul style="margin: 0; padding-left: 1.5rem;">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo $error; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="POST" data-validate>
                    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="first_name">Nombre *</label>
                            <input type="text" id="first_name" name="first_name" class="form-control" 
                                   value="<?php echo htmlspecialchars($_POST['first_name'] ?? ''); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="last_name">Apellido *</label>
                            <input type="text" id="last_name" name="last_name" class="form-control" 
                                   value="<?php echo htmlspecialchars($_POST['last_name'] ?? ''); ?>" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="email">Email *</label>
                        <input type="email" id="email" name="email" class="form-control" 
                               value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="password">Contraseña *</label>
                            <div style="position: relative;">
                                <input type="password" id="password" name="password" class="form-control" required>
                                <button type="button" class="password-toggle" style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); background: none; border: none; cursor: pointer;">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="confirm_password">Confirmar Contraseña *</label>
                            <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="domain">Dominio de tu sitio *</label>
                        <input type="text" id="domain" name="domain" class="form-control" 
                               placeholder="ejemplo.com" 
                               value="<?php echo htmlspecialchars($_POST['domain'] ?? ''); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="company">Empresa *</label>
                        <input type="text" id="company" name="company" class="form-control" 
                               value="<?php echo htmlspecialchars($_POST['company'] ?? ''); ?>" required>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="city">Ciudad</label>
                            <input type="text" id="city" name="city" class="form-control" 
                                   value="<?php echo htmlspecialchars($_POST['city'] ?? ''); ?>">
                        </div>
                        <div class="form-group">
                            <label for="country">País</label>
                            <input type="text" id="country" name="country" class="form-control" 
                                   value="<?php echo htmlspecialchars($_POST['country'] ?? ''); ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="phone">Teléfono</label>
                        <input type="tel" id="phone" name="phone" class="form-control" 
                               value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>">
                    </div>

                    <div style="text-align: center; margin-top: 2rem;">
                        <button type="submit" class="btn btn-primary btn-large">
                            <i class="fas fa-user-plus"></i> Crear Cuenta
                        </button>
                    </div>

                    <div style="text-align: center; margin-top: 1rem;">
                        <p>¿Ya tienes cuenta? <a href="login.php" style="color: #2563eb;">Iniciar Sesión</a></p>
                    </div>
                </form>
            </div>
        </div>
    </main>

    <!-- Modal de Información del Plan -->
    <div id="planInfoModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center;">
        <div style="background: white; border-radius: 16px; padding: 2rem; max-width: 500px; width: 90%; max-height: 80vh; overflow-y: auto; position: relative;">
            <button onclick="closePlanInfo()" style="position: absolute; top: 1rem; right: 1rem; background: none; border: none; font-size: 1.5rem; cursor: pointer; color: #6b7280;">
                <i class="fas fa-times"></i>
            </button>
            
            <div id="planInfoContent">
                <!-- Contenido se llena dinámicamente -->
            </div>
        </div>
    </div>

    <script src="../assets/js/script.js"></script>
    
    <style>
        @media (max-width: 768px) {
            .plans-grid {
                grid-template-columns: 1fr !important;
                gap: 1rem !important;
            }
        }
        
        @media (max-width: 1024px) and (min-width: 769px) {
            .plans-grid {
                grid-template-columns: repeat(3, 1fr) !important;
                gap: 1rem !important;
            }
        }
    </style>
    
    <script>
        // Datos de los planes
        const plans = <?php echo json_encode($plans); ?>;
        
        // Función para seleccionar un plan
        function selectPlan(planId) {
            // Actualizar URL sin recargar la página
            const url = new URL(window.location);
            url.searchParams.set('plan', planId);
            window.history.replaceState({}, '', url);
            
            // Actualizar visualmente las tarjetas
            document.querySelectorAll('.plan-card').forEach(card => {
                const isSelected = card.dataset.plan === planId;
                card.style.borderColor = isSelected ? '#059669' : '#e5e7eb';
                card.style.background = isSelected ? '#f0fdf4' : 'white';
                
                const button = card.querySelector('button');
                button.textContent = isSelected ? 'Seleccionado' : 'Seleccionar';
                button.style.background = isSelected ? '#059669' : '#6b7280';
            });
            
            // Actualizar información del plan seleccionado
            const selectedPlan = plans.find(plan => plan.id === planId);
            if (selectedPlan) {
                document.getElementById('selected-plan-name').textContent = selectedPlan.name;
                document.getElementById('selected-plan-price').textContent = '$' + selectedPlan.price + '/mes';
            }
        }
        
        // Función para mostrar información del plan
        function showPlanInfo(planId) {
            const plan = plans.find(p => p.id === planId);
            if (!plan) return;
            
            // Definir características que deben mostrar X roja
            const negativeFeatures = {
                'free': ['Sin soporte', 'Widget Spotify'],
                'premium': ['Widget Spotify'],
                'enterprise': []
            };
            
            const modal = document.getElementById('planInfoModal');
            const content = document.getElementById('planInfoContent');
            
            content.innerHTML = `
                <h2 style="margin-bottom: 1.5rem; color: #1f2937; text-align: center; font-size: 1.5rem;">
                    ${plan.name}
                </h2>
                
                <div style="margin-bottom: 1.5rem;">
                    <h3 style="margin-bottom: 0.75rem; color: #374151; font-size: 1.1rem;">
                        <i class="fas fa-star"></i> Características incluidas:
                    </h3>
                    <ul style="list-style: none; padding: 0; margin: 0;">
                        ${plan.features.map(feature => {
                            const isNegative = negativeFeatures[planId] && negativeFeatures[planId].includes(feature);
                            return `
                                <li style="padding: 0.4rem 0; display: flex; align-items: center;">
                                    <i class="fas ${isNegative ? 'fa-times' : 'fa-check'}" 
                                       style="color: ${isNegative ? '#dc2626' : '#059669'}; margin-right: 0.5rem; font-size: 0.9rem;"></i>
                                    <span style="color: #374151; font-size: 0.95rem;">${feature}</span>
                                </li>
                            `;
                        }).join('')}
                    </ul>
                </div>
                
                <div style="text-align: center;">
                    <button onclick="selectPlan('${planId}'); closePlanInfo();" 
                            style="background: #059669; color: white; border: none; padding: 0.75rem 1.5rem; border-radius: 6px; 
                                   cursor: pointer; font-weight: bold; font-size: 1rem; margin-right: 0.75rem;">
                        <i class="fas fa-check"></i> Seleccionar
                    </button>
                    <button onclick="closePlanInfo()" 
                            style="background: #f3f4f6; color: #374151; border: 1px solid #d1d5db; padding: 0.75rem 1.5rem; border-radius: 6px; 
                                   cursor: pointer; font-weight: bold; font-size: 1rem;">
                        <i class="fas fa-times"></i> Cerrar
                    </button>
                </div>
            `;
            
            modal.style.display = 'flex';
        }
        
        // Función para cerrar el modal
        function closePlanInfo() {
            document.getElementById('planInfoModal').style.display = 'none';
        }
        
        // Cerrar modal al hacer clic fuera de él
        document.addEventListener('DOMContentLoaded', function() {
            const modal = document.getElementById('planInfoModal');
            modal.addEventListener('click', function(e) {
                if (e.target === modal) {
                    closePlanInfo();
                }
            });
        });
    </script>
</body>
</html>
