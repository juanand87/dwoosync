<?php
/**
 * Página de perfil del usuario
 */

// Definir constante para acceso a la API
define('API_ACCESS', true);

// Incluir configuración de base de datos
require_once '../../config/database.php';

// Verificar sesión
session_start();
if (!isset($_SESSION['subscriber_id'])) {
    header('Location: ../index.php');
    exit;
}

$subscriber_id = $_SESSION['subscriber_id'];
$license_key = $_SESSION['license_key'] ?? '';

// Obtener información del suscriptor
$subscriber = $pdo->prepare("SELECT * FROM subscribers WHERE id = ?");
$subscriber->execute([$subscriber_id]);
$subscriber_data = $subscriber->fetch(PDO::FETCH_ASSOC);

// Obtener información de la licencia
$license = $pdo->prepare("SELECT * FROM licenses WHERE subscriber_id = ? AND license_key = ?");
$license->execute([$subscriber_id, $license_key]);
$license_data = $license->fetch(PDO::FETCH_ASSOC);

// Obtener ciclo activo actual
$current_billing_cycle = $pdo->prepare("
    SELECT * FROM billing_cycles 
    WHERE subscriber_id = ? AND license_key = ? AND is_active = 1
");
$current_billing_cycle->execute([$subscriber_id, $license_key]);
$cycle_data = $current_billing_cycle->fetch(PDO::FETCH_ASSOC);

$success_message = '';
$error_message = '';

// Procesar actualización de perfil
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    try {
        $first_name = trim($_POST['first_name']);
        $last_name = trim($_POST['last_name']);
        $email = trim($_POST['email']);
        $company = trim($_POST['company']);
        $city = trim($_POST['city']);
        $country = trim($_POST['country']);
        $phone = trim($_POST['phone']);
        
        // Validaciones básicas
        if (empty($first_name) || empty($last_name) || empty($email)) {
            throw new Exception('Los campos nombre, apellido y email son obligatorios');
        }
        
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception('El email no tiene un formato válido');
        }
        
        // Verificar si el email ya existe en otro usuario
        $check_email = $pdo->prepare("SELECT id FROM subscribers WHERE email = ? AND id != ?");
        $check_email->execute([$email, $subscriber_id]);
        if ($check_email->fetch()) {
            throw new Exception('Este email ya está registrado por otro usuario');
        }
        
        // Actualizar datos del suscriptor
        $update_stmt = $pdo->prepare("
            UPDATE subscribers 
            SET first_name = ?, last_name = ?, email = ?, company = ?, city = ?, country = ?, phone = ?, updated_at = NOW()
            WHERE id = ?
        ");
        
        $update_stmt->execute([
            $first_name, $last_name, $email, $company, $city, $country, $phone, $subscriber_id
        ]);
        
        // Actualizar datos de sesión
        $_SESSION['user_name'] = $first_name . ' ' . $last_name;
        $_SESSION['user_email'] = $email;
        
        // Actualizar datos locales
        $subscriber_data['first_name'] = $first_name;
        $subscriber_data['last_name'] = $last_name;
        $subscriber_data['email'] = $email;
        $subscriber_data['company'] = $company;
        $subscriber_data['city'] = $city;
        $subscriber_data['country'] = $country;
        $subscriber_data['phone'] = $phone;
        
        $success_message = 'Perfil actualizado correctamente';
        
    } catch (Exception $e) {
        $error_message = $e->getMessage();
    }
}

// Procesar cambio de contraseña
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    try {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        // Validaciones
        if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
            throw new Exception('Todos los campos de contraseña son obligatorios');
        }
        
        if ($new_password !== $confirm_password) {
            throw new Exception('Las contraseñas nuevas no coinciden');
        }
        
        if (strlen($new_password) < 6) {
            throw new Exception('La nueva contraseña debe tener al menos 6 caracteres');
        }
        
        // Verificar contraseña actual
        if (!password_verify($current_password, $subscriber_data['password'])) {
            throw new Exception('La contraseña actual es incorrecta');
        }
        
        // Actualizar contraseña
        $new_password_hash = password_hash($new_password, PASSWORD_DEFAULT);
        $update_password = $pdo->prepare("UPDATE subscribers SET password = ?, updated_at = NOW() WHERE id = ?");
        $update_password->execute([$new_password_hash, $subscriber_id]);
        
        $success_message = 'Contraseña actualizada correctamente';
        
    } catch (Exception $e) {
        $error_message = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Perfil - dwoosync</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/pages.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            padding: 20px;
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
        }
        
        .nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1400px;
            margin: 0 auto;
        }
        
        .logo {
            font-size: 28px;
            font-weight: bold;
            background: linear-gradient(45deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .nav-links {
            display: flex;
            gap: 20px;
        }
        
        .nav-links a {
            color: #333;
            text-decoration: none;
            padding: 12px 20px;
            border-radius: 25px;
            transition: all 0.3s ease;
            font-weight: 500;
        }
        
        .nav-links a:hover {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            transform: translateY(-2px);
        }
        
        .btn-logout {
            background: linear-gradient(45deg, #dc2626, #b91c1c);
            color: white !important;
        }
        
        .btn-logout:hover {
            background: linear-gradient(45deg, #b91c1c, #991b1b);
        }
        
        .container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 40px 20px;
        }
        
        .profile-header {
            text-align: center;
            margin-bottom: 40px;
        }
        
        .profile-title {
            font-size: 2.5rem;
            font-weight: bold;
            color: white;
            margin-bottom: 10px;
        }
        
        .profile-subtitle {
            font-size: 1.2rem;
            color: rgba(255, 255, 255, 0.8);
        }
        
        .profile-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-bottom: 30px;
        }
        
        .profile-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        }
        
        .card-title {
            font-size: 1.5rem;
            font-weight: bold;
            color: #1f2937;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            font-weight: 600;
            color: #374151;
            margin-bottom: 5px;
        }
        
        .form-input {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e5e7eb;
            border-radius: 10px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: #f9fafb;
        }
        
        .form-input:focus {
            outline: none;
            border-color: #667eea;
            background: white;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        
        .btn {
            display: inline-block;
            padding: 15px 30px;
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            text-decoration: none;
            border-radius: 25px;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            font-size: 1rem;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }
        
        .btn-success {
            background: linear-gradient(45deg, #10b981, #059669);
        }
        
        .btn-success:hover {
            box-shadow: 0 10px 20px rgba(16, 185, 129, 0.3);
        }
        
        .btn-secondary {
            background: linear-gradient(45deg, #6b7280, #4b5563);
        }
        
        .btn-secondary:hover {
            box-shadow: 0 10px 20px rgba(107, 114, 128, 0.3);
        }
        
        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        
        .alert-success {
            background: linear-gradient(135deg, #d1fae5, #a7f3d0);
            color: #065f46;
            border-left: 4px solid #10b981;
        }
        
        .alert-error {
            background: linear-gradient(135deg, #fee2e2, #fecaca);
            color: #991b1b;
            border-left: 4px solid #dc2626;
        }
        
        .account-info {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .info-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .info-item:last-child {
            border-bottom: none;
        }
        
        .info-label {
            font-weight: 600;
            color: #374151;
        }
        
        .info-value {
            color: #6b7280;
        }
        
        .plan-badge {
            background: linear-gradient(45deg, #10b981, #059669);
            color: white;
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.9rem;
        }
        
        .plan-badge.free {
            background: linear-gradient(45deg, #6b7280, #4b5563);
        }
        
        .license-display {
            background: #f0f4ff;
            border: 2px solid #d1d5db;
            border-radius: 10px;
            padding: 15px;
            margin: 15px 0;
            font-family: 'Courier New', monospace;
            font-size: 1rem;
            font-weight: 600;
            color: #667eea;
            word-break: break-all;
        }
        
        .btn-copy {
            background: linear-gradient(45deg, #10b981, #059669);
            color: white;
            padding: 8px 16px;
            border-radius: 8px;
            font-size: 0.9rem;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            margin-left: 10px;
        }
        
        .btn-copy:hover {
            background: linear-gradient(45deg, #059669, #047857);
            transform: translateY(-1px);
        }
        
        @media (max-width: 768px) {
            .profile-grid {
                grid-template-columns: 1fr;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-logo">
                    <h2><i class="fas fa-music"></i> dwoosync</h2>
                </div>
                <div class="nav-menu">
                    <a href="dashboard.php" class="nav-link">🏠 Inicio</a>
                    <a href="profile.php" class="nav-link btn-primary">👤 Perfil</a>
                    <a href="billing.php" class="nav-link">💳 Facturación</a>
                    <a href="plugin-config.php" class="nav-link">⚙️ Configurar Plugin</a>
                    <a href="logout.php" class="nav-link btn-logout">🚪 Cerrar Sesión</a>
                </div>
            </div>
        </nav>
    </header>

    <div class="container">
        <div class="profile-header">
            <h1 class="profile-title">Mi Perfil</h1>
            <p class="profile-subtitle">Gestiona tu información personal y configuración de cuenta</p>
        </div>

        <?php if ($success_message): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success_message); ?>
            </div>
        <?php endif; ?>

        <?php if ($error_message): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>

        <div class="profile-grid">
            <!-- Información Personal -->
            <div class="profile-card">
                <h2 class="card-title">
                    <i class="fas fa-user"></i> Información Personal
                </h2>
                
                <form method="POST">
                    <input type="hidden" name="update_profile" value="1">
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label" for="first_name">Nombre *</label>
                            <input type="text" id="first_name" name="first_name" class="form-input" 
                                   value="<?php echo htmlspecialchars($subscriber_data['first_name'] ?? ''); ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="last_name">Apellido *</label>
                            <input type="text" id="last_name" name="last_name" class="form-input" 
                                   value="<?php echo htmlspecialchars($subscriber_data['last_name'] ?? ''); ?>" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label" for="email">Email *</label>
                        <input type="email" id="email" name="email" class="form-input" 
                               value="<?php echo htmlspecialchars($subscriber_data['email'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label" for="company">Empresa</label>
                        <input type="text" id="company" name="company" class="form-input" 
                               value="<?php echo htmlspecialchars($subscriber_data['company'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label" for="city">Ciudad</label>
                            <input type="text" id="city" name="city" class="form-input" 
                                   value="<?php echo htmlspecialchars($subscriber_data['city'] ?? ''); ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="country">País</label>
                            <input type="text" id="country" name="country" class="form-input" 
                                   value="<?php echo htmlspecialchars($subscriber_data['country'] ?? ''); ?>">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label" for="phone">Teléfono</label>
                        <input type="tel" id="phone" name="phone" class="form-input" 
                               value="<?php echo htmlspecialchars($subscriber_data['phone'] ?? ''); ?>">
                    </div>
                    
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-save"></i> Actualizar Perfil
                    </button>
                </form>
            </div>

            <!-- Cambiar Contraseña -->
            <div class="profile-card">
                <h2 class="card-title">
                    <i class="fas fa-lock"></i> Cambiar Contraseña
                </h2>
                
                <form method="POST">
                    <input type="hidden" name="change_password" value="1">
                    
                    <div class="form-group">
                        <label class="form-label" for="current_password">Contraseña Actual *</label>
                        <input type="password" id="current_password" name="current_password" class="form-input" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label" for="new_password">Nueva Contraseña *</label>
                        <input type="password" id="new_password" name="new_password" class="form-input" required minlength="6">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label" for="confirm_password">Confirmar Nueva Contraseña *</label>
                        <input type="password" id="confirm_password" name="confirm_password" class="form-input" required minlength="6">
                    </div>
                    
                    <button type="submit" class="btn">
                        <i class="fas fa-key"></i> Cambiar Contraseña
                    </button>
                </form>
            </div>
        </div>

        <!-- Información de la Cuenta -->
        <div class="profile-card">
            <h2 class="card-title">
                <i class="fas fa-info-circle"></i> Información de la Cuenta
            </h2>
            
            <div class="account-info">
                <div class="info-item">
                    <span class="info-label">ID de Usuario:</span>
                    <span class="info-value">#<?php echo $subscriber_id; ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">Plan Actual:</span>
                    <span class="plan-badge <?php echo ($subscriber_data['plan_type'] ?? 'free') === 'free' ? 'free' : ''; ?>">
                        <?php echo ucfirst($subscriber_data['plan_type'] ?? 'free'); ?>
                    </span>
                </div>
                <div class="info-item">
                    <span class="info-label">Estado de la Cuenta:</span>
                    <span class="info-value" style="color: <?php echo ($subscriber_data['status'] ?? 'inactive') === 'active' ? '#10b981' : '#dc2626'; ?>">
                        <?php echo ucfirst($subscriber_data['status'] ?? 'inactive'); ?>
                    </span>
                </div>
                <div class="info-item">
                    <span class="info-label">Dominio:</span>
                    <span class="info-value"><?php echo htmlspecialchars($subscriber_data['domain'] ?? 'N/A'); ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">Miembro desde:</span>
                    <span class="info-value"><?php echo date('d/m/Y', strtotime($subscriber_data['created_at'] ?? 'now')); ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">Última actualización:</span>
                    <span class="info-value"><?php echo date('d/m/Y H:i', strtotime($subscriber_data['updated_at'] ?? $subscriber_data['created_at'] ?? 'now')); ?></span>
                </div>
            </div>
            
            <?php if ($license_data): ?>
                <div class="license-display">
                    <strong>Clave de Licencia:</strong><br>
                    <?php echo htmlspecialchars($license_key); ?>
                    <button class="btn-copy" onclick="copyLicenseKey()">
                        <i class="fas fa-copy"></i> Copiar
                    </button>
                </div>
            <?php endif; ?>
            
            <div style="margin-top: 20px;">
                <a href="dashboard.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Volver al Dashboard
                </a>
                <?php if (($subscriber_data['plan_type'] ?? 'free') === 'free'): ?>
                    <a href="plans.php" class="btn" style="background: linear-gradient(45deg, #f59e0b, #d97706);">
                        <i class="fas fa-arrow-up"></i> Mejorar Plan
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        function copyLicenseKey() {
            const licenseKey = '<?php echo addslashes($license_key); ?>';
            navigator.clipboard.writeText(licenseKey).then(function() {
                // Cambiar el botón temporalmente
                const btn = event.target.closest('.btn-copy');
                const originalText = btn.innerHTML;
                btn.innerHTML = '<i class="fas fa-check"></i> Copiado!';
                btn.style.background = 'linear-gradient(45deg, #10b981, #059669)';
                
                setTimeout(function() {
                    btn.innerHTML = originalText;
                }, 2000);
            }).catch(function(err) {
                alert('Error al copiar: ' + err);
            });
        }
        
        // Validación de contraseñas
        document.getElementById('confirm_password').addEventListener('input', function() {
            const newPassword = document.getElementById('new_password').value;
            const confirmPassword = this.value;
            
            if (newPassword !== confirmPassword) {
                this.setCustomValidity('Las contraseñas no coinciden');
            } else {
                this.setCustomValidity('');
            }
        });
    </script>
</body>
</html>

