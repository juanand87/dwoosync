<?php
/**
 * Página principal del sitio de suscripciones dwoosync
 * 
 * @package dwoosync
 * @version 1.0.0
 */

// Incluir configuración
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';

// Iniciar sesión
startSecureSession();

// Verificar si el usuario está logueado
$isLoggedIn = isLoggedIn();

// Obtener planes de suscripción
$plans = getSubscriptionPlans();

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>dwoosync - Suscripciones API</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-logo">
                    <h2><i class="fas fa-music"></i> dwoosync</h2>
                </div>
                <div class="nav-menu">
                    <a href="#plans" class="nav-link">Planes</a>
                    <a href="#features" class="nav-link">Características</a>
                    <a href="pages/screenshots.php" class="nav-link">Screenshots</a>
                    <a href="#contact" class="nav-link">Contacto</a>
                    <?php if ($isLoggedIn): ?>
                        <a href="pages/dashboard.php" class="nav-link btn-login">Ver Cuenta</a>
                    <?php else: ?>
                        <a href="pages/login.php" class="nav-link btn-login">Iniciar Sesión</a>
                    <?php endif; ?>
                </div>
            </div>
        </nav>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-container">
            <div class="hero-content">
                <h1 class="hero-title">
                    Plugin de Discogs para <span class="highlight">WooCommerce</span>
                </h1>
                <p class="hero-subtitle">
                    El mejor plugin para integrar Discogs con WooCommerce - WordPress. 
                    Importa datos de productos desde Discogs directamente a tu tienda. 
                    Fácil, rápido y confiable.
                </p>
                <div class="hero-buttons">
                    <a href="#plans" class="btn btn-primary btn-large">
                        <i class="fas fa-rocket"></i> Comenzar Ahora
                    </a>
                    <a href="#features" class="btn btn-secondary btn-large">
                        <i class="fas fa-play"></i> Ver Demo
                    </a>
                </div>
            </div>
            <div class="hero-image">
                <div class="hero-card">
                    <div class="card-header">
                        <div class="card-dots">
                            <span></span><span></span><span></span>
                        </div>
                    </div>
                    <div class="card-content">
                        <div class="code-line">
                            <span class="code-keyword">import</span> 
                            <span class="code-string">'dwoosync'</span>
                        </div>
                        <div class="code-line">
                            <span class="code-comment">// Buscar artista</span>
                        </div>
                        <div class="code-line">
                            <span class="code-variable">const</span> 
                            <span class="code-function">artist</span> = 
                            <span class="code-string">'Pink Floyd'</span>
                        </div>
                        <div class="code-line">
                            <span class="code-comment">// ¡Listo! 🎵</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section id="features" class="features">
        <div class="container">
            <div class="section-header">
                <h2>¿Por qué elegir dwoosync?</h2>
                <p>El mejor plugin para integrar Discogs con WooCommerce - WordPress</p>
            </div>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-bolt"></i>
                    </div>
                    <h3>Rápido y Eficiente</h3>
                    <p>Importa miles de productos en segundos con nuestra API optimizada</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <h3>Seguro y Confiable</h3>
                    <p>Sistema de licencias robusto con validación en tiempo real</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-cogs"></i>
                    </div>
                    <h3>Fácil de Usar</h3>
                    <p>Interfaz intuitiva que no requiere conocimientos técnicos</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-headset"></i>
                    </div>
                    <h3>Soporte 24/7</h3>
                    <p>Equipo de soporte disponible para ayudarte en todo momento</p>
                </div>
            </div>
        </div>
    </section>


    <!-- Pricing Section -->
    <section id="plans" class="pricing">
        <div class="container">
            <div class="section-header">
                <h2>Elige tu Plan</h2>
                <p>Planes flexibles para cada necesidad</p>
            </div>
            <div class="pricing-grid">
                <?php foreach ($plans as $plan): ?>
                <div class="pricing-card <?php echo $plan['featured'] ? 'featured' : ''; ?>">
                    <?php if ($plan['featured']): ?>
                    <div class="pricing-badge">Más Popular</div>
                    <?php endif; ?>
                    
                    <div class="pricing-header">
                        <h3><?php echo htmlspecialchars($plan['name']); ?></h3>
                        <div class="pricing-price">
                            <span class="currency">$</span>
                            <span class="amount"><?php echo $plan['price']; ?></span>
                            <span class="period">/mes</span>
                        </div>
                    </div>
                    
                    <div class="pricing-features">
                        <ul>
                            <?php foreach ($plan['features'] as $feature): ?>
                            <li>
                                <?php if ($plan['id'] === 'free' && ($feature === 'Sin soporte' || $feature === 'Estadística detallada' || $feature === 'Widget Spotify')): ?>
                                    <i class="fas fa-times" style="color: #dc2626;"></i>
                                <?php elseif ($plan['id'] === 'premium' && $feature === 'Widget Spotify'): ?>
                                    <i class="fas fa-times" style="color: #dc2626;"></i>
                                <?php else: ?>
                                    <i class="fas fa-check"></i>
                                <?php endif; ?>
                                <?php echo htmlspecialchars($feature); ?>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    
                    <div class="pricing-footer">
                        <a href="pages/signup.php?plan=<?php echo $plan['id']; ?>" 
                           class="btn <?php echo $plan['featured'] ? 'btn-primary' : 'btn-outline'; ?> btn-block">
                            <?php echo $plan['price'] == 0 ? 'Comenzar Gratis' : 'Suscribirse'; ?>
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta">
        <div class="container">
            <div class="cta-content">
                <h2>¿Listo para comenzar?</h2>
                <p>Únete a cientos de tiendas que ya usan dwoosync</p>
                <a href="#plans" class="btn btn-primary btn-large">
                    <i class="fas fa-arrow-right"></i> Ver Planes
                </a>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>dwoosync</h3>
                    <p>El mejor plugin para integrar Discogs con WooCommerce - WordPress</p>
                </div>
                <div class="footer-section">
                    <h4>Enlaces</h4>
                    <ul>
                        <li><a href="#plans">Planes</a></li>
                        <li><a href="#features">Características</a></li>
                        <li><a href="pages/screenshots.php">Screenshots</a></li>
                        <?php if ($isLoggedIn): ?>
                            <li><a href="pages/dashboard.php">Ver Cuenta</a></li>
                        <?php else: ?>
                            <li><a href="pages/login.php">Iniciar Sesión</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Soporte</h4>
                    <ul>
                        <li><a href="mailto:support@discogsync.com">support@discogsync.com</a></li>
                        <li><a href="#">Documentación</a></li>
                        <li><a href="#">FAQ</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2024 dwoosync. Todos los derechos reservados.</p>
            </div>
        </div>
    </footer>

    <script src="assets/js/script.js"></script>
</body>
</html>