<?php
/**
 * Configuración del sitio de suscripciones - Versión sin problemas de sesión
 */

// Configuración de la base de datos
define('DB_HOST', 'localhost');
define('DB_NAME', 'discogs_api');
define('DB_USER', 'root');
define('DB_PASS', 'mayorista2024');
define('DB_CHARSET', 'utf8mb4');

// Configuración del sitio
define('SITE_URL', 'http://localhost/api_discogs/subscribe');
define('API_URL', 'http://localhost/api_discogs/api');
define('ADMIN_URL', 'http://localhost/api_discogs/admin');

// Configuración de pagos (Stripe)
define('STRIPE_PUBLISHABLE_KEY', 'pk_test_...'); // Cambiar por tu clave pública
define('STRIPE_SECRET_KEY', 'sk_test_...'); // Cambiar por tu clave secreta
define('STRIPE_WEBHOOK_SECRET', 'whsec_...'); // Cambiar por tu webhook secret

// Configuración de email
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'your-email@gmail.com');
define('SMTP_PASSWORD', 'your-app-password');
define('FROM_EMAIL', 'noreply@discogsync.com');
define('FROM_NAME', 'DiscogsSync');

// Configuración de seguridad
define('CSRF_TOKEN_NAME', 'csrf_token');
define('SESSION_TIMEOUT', 3600); // 1 hora

// Configuración de errores
if (defined('WP_DEBUG') && WP_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// Función para iniciar sesión de forma segura
function startSecureSession() {
    if (session_status() === PHP_SESSION_NONE) {
        // Configurar sesión solo si no está iniciada
        ini_set('session.cookie_httponly', 1);
        ini_set('session.use_only_cookies', 1);
        ini_set('session.cookie_secure', 0); // Cambiar a 1 en producción con HTTPS
        session_start();
    }
}
?>
