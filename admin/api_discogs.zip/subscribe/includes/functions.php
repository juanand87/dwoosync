<?php
/**
 * Funciones auxiliares para el sitio de suscripciones
 */

require_once __DIR__ . '/Database.php';

/**
 * Obtener planes de suscripción
 */
function getSubscriptionPlans() {
    return [
        [
            'id' => 'free',
            'name' => 'Gratuito',
            'price' => 0,
            'featured' => false,
            'features' => [
                '10 importaciones/mes',
                'Llamadas API ilimitadas',
                'Sin soporte',
                'Documentación básica',
                '1 Dominio/Sitio Web',
                'Actualizaciones',
                'Estadística detallada',
                'Widget Spotify'
            ]
        ],
        [
            'id' => 'premium',
            'name' => 'Premium',
            'price' => 22,
            'featured' => true,
            'features' => [
                'Importaciones ilimitadas',
                'Llamadas API ilimitadas',
                'Soporte prioritario',
                'Documentación completa',
                '1 Dominio/Sitio Web',
                'Actualizaciones',
                'Estadística detallada',
                'Widget Spotify'
            ]
        ],
        [
            'id' => 'enterprise',
            'name' => '+Spotify',
            'price' => 29,
            'featured' => false,
            'features' => [
                'Importaciones ilimitadas',
                'Llamadas API ilimitadas',
                'Integración con Spotify',
                'Soporte prioritario',
                'Documentación completa',
                '1 Dominio/Sitio Web',
                'Actualizaciones',
                'Estadística detallada',
                'Widget Spotify'
            ]
        ]
    ];
}

/**
 * Conectar a la base de datos
 */
function getDatabase() {
    static $db = null;
    
    if ($db === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $db = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ]);
        } catch (PDOException $e) {
            die("Error de conexión: " . $e->getMessage());
        }
    }
    
    return $db;
}

/**
 * Generar clave de licencia
 */
function generateLicenseKey() {
    return 'DISC-' . strtoupper(substr(md5(uniqid(rand(), true)), 0, 16));
}

/**
 * Validar email
 */
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Sanitizar datos de entrada
 */
function sanitizeInput($data) {
    if (is_array($data)) {
        return array_map('sanitizeInput', $data);
    }
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

/**
 * Generar hash de contraseña
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

/**
 * Verificar contraseña
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * Generar token CSRF
 */
function generateCSRFToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verificar token CSRF
 */
function verifyCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Enviar email
 */
function sendEmail($to, $subject, $message, $isHTML = true) {
    $headers = [
        'From: ' . FROM_NAME . ' <' . FROM_EMAIL . '>',
        'Reply-To: ' . FROM_EMAIL,
        'X-Mailer: PHP/' . phpversion()
    ];
    
    if ($isHTML) {
        $headers[] = 'MIME-Version: 1.0';
        $headers[] = 'Content-type: text/html; charset=UTF-8';
    }
    
    return mail($to, $subject, $message, implode("\r\n", $headers));
}

/**
 * Redirigir con mensaje
 */
function redirectWithMessage($url, $message, $type = 'success') {
    $_SESSION['message'] = $message;
    $_SESSION['message_type'] = $type;
    header("Location: $url");
    exit;
}

/**
 * Mostrar mensaje
 */
function showMessage() {
    if (isset($_SESSION['message'])) {
        $message = $_SESSION['message'];
        $type = $_SESSION['message_type'] ?? 'info';
        
        echo "<div class='alert alert-{$type}'>{$message}</div>";
        
        unset($_SESSION['message']);
        unset($_SESSION['message_type']);
    }
}

/**
 * Verificar si el usuario está logueado
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Obtener usuario actual
 */
function getCurrentUser() {
    if (!isLoggedIn()) {
        return null;
    }
    
    $db = getDatabase();
    $stmt = $db->prepare("SELECT * FROM subscribers WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    
    return $stmt->fetch();
}

/**
 * Requerir login
 */
function requireLogin() {
    if (!isLoggedIn()) {
        redirectWithMessage('login.php', 'Debes iniciar sesión para acceder a esta página', 'error');
    }
}

/**
 * Formatear fecha
 */
function formatDate($date, $format = 'd/m/Y H:i') {
    return date($format, strtotime($date));
}

/**
 * Formatear precio
 */
function formatPrice($price, $currency = '$') {
    return $currency . number_format($price, 2);
}
?>
