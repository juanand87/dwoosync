<?php
// Configuración de claves de Discogs para pruebas
// Reemplaza estos valores con tus claves reales de Discogs

$discogs_config = [
    'api_key' => 'RHwdshtjSotKMFGXAwRe',
    'api_secret' => 'sXYOPlqNkzCosZwHAmNYjVlHQfMkCKvJ'
];

// Ejemplo de uso:
// $discogs_config = [
//     'api_key' => 'abc123def456ghi789',
//     'api_secret' => 'xyz789uvw456rst123'
// ];

return $discogs_config;
?>

