<?php
// Redirigir a la API
header('Location: api/index.php');
exit;
?>

