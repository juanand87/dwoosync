// Insert modal function if not defined
if (typeof showModal === 'undefined') {
    function showModal(content) {
        var modal = document.createElement('div');
        modal.setAttribute('id', 'discModal');
        modal.style.position = 'fixed';
        modal.style.top = '0';
        modal.style.left = '0';
        modal.style.width = '100%';
        modal.style.height = '100%';
        modal.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
        modal.style.display = 'flex';
        modal.style.justifyContent = 'center';
        modal.style.alignItems = 'center';
        modal.style.zIndex = '999999';
        modal.innerHTML = '<div style="background: white; padding: 20px; border-radius: 12px; box-shadow: 0 20px 60px rgba(0,0,0,0.3); position: relative;">' + content + '<div style="text-align: center; margin-top: 20px; padding-top: 15px; border-top: 1px solid #eee;"><button id="closeModal" style="background: linear-gradient(135deg, #0073aa 0%, #005177 100%); color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: 500; transition: transform 0.2s ease;" onmouseover="this.style.transform=\'translateY(-1px)\'" onmouseout="this.style.transform=\'translateY(0)\'" >Close</button></div></div>';
        document.body.appendChild(modal);
        document.getElementById('closeModal').addEventListener('click', function() {
            document.body.removeChild(modal);
        });
    }
}

// Galería de imágenes flotante
var currentImageIndex = 0;
var galleryImages = [];

function openImageGallery(index, images) {
    currentImageIndex = index;
    galleryImages = images;
    
    var imageUrl = galleryImages[currentImageIndex].resource_url || galleryImages[currentImageIndex].uri || galleryImages[currentImageIndex].uri150;
    
    var galleryModal = document.createElement('div');
    galleryModal.setAttribute('id', 'imageGalleryModal');
    galleryModal.style.position = 'fixed';
    galleryModal.style.top = '0';
    galleryModal.style.left = '0';
    galleryModal.style.width = '100%';
    galleryModal.style.height = '100%';
    galleryModal.style.backgroundColor = 'rgba(0, 0, 0, 0.9)';
    galleryModal.style.display = 'flex';
    galleryModal.style.justifyContent = 'center';
    galleryModal.style.alignItems = 'center';
    galleryModal.style.zIndex = '9999999';
    
    var galleryContent = '<div style="position: relative; max-width: 90%; max-height: 90%; display: flex; align-items: center; justify-content: center;">' +
        '<img id="galleryImage" src="' + imageUrl + '" style="max-width: 100%; max-height: 100%; object-fit: contain; border-radius: 8px; box-shadow: 0 10px 30px rgba(0,0,0,0.5);">' +
        '<button id="prevImage" style="position: absolute; left: -50px; top: 50%; transform: translateY(-50%); background: rgba(255,255,255,0.9); border: none; border-radius: 50%; width: 40px; height: 40px; cursor: pointer; font-size: 18px; display: flex; align-items: center; justify-content: center; box-shadow: 0 2px 10px rgba(0,0,0,0.3); transition: background 0.2s;">❮</button>' +
        '<button id="nextImage" style="position: absolute; right: -50px; top: 50%; transform: translateY(-50%); background: rgba(255,255,255,0.9); border: none; border-radius: 50%; width: 40px; height: 40px; cursor: pointer; font-size: 18px; display: flex; align-items: center; justify-content: center; box-shadow: 0 2px 10px rgba(0,0,0,0.3); transition: background 0.2s;">❯</button>' +
        '<button id="closeGallery" style="position: absolute; top: -40px; right: 0; background: rgba(255,255,255,0.9); border: none; border-radius: 50%; width: 35px; height: 35px; cursor: pointer; font-size: 16px; display: flex; align-items: center; justify-content: center; box-shadow: 0 2px 10px rgba(0,0,0,0.3); transition: background 0.2s;">✕</button>' +
        '<div style="position: absolute; bottom: -40px; left: 50%; transform: translateX(-50%); color: white; font-size: 14px; text-align: center;">' + (currentImageIndex + 1) + ' / ' + galleryImages.length + '</div>' +
    '</div>';
    
    galleryModal.innerHTML = galleryContent;
    document.body.appendChild(galleryModal);
    
    // Event listeners
    document.getElementById('closeGallery').addEventListener('click', closeImageGallery);
    document.getElementById('prevImage').addEventListener('click', showPrevImage);
    document.getElementById('nextImage').addEventListener('click', showNextImage);
    
    // Cerrar con click en el fondo
    galleryModal.addEventListener('click', function(e) {
        if (e.target === galleryModal) {
            closeImageGallery();
        }
    });
    
    // Navegación con teclado
    document.addEventListener('keydown', handleGalleryKeydown);
    
    // Ocultar botones si solo hay una imagen
    if (galleryImages.length <= 1) {
        document.getElementById('prevImage').style.display = 'none';
        document.getElementById('nextImage').style.display = 'none';
    }
}

function closeImageGallery() {
    var galleryModal = document.getElementById('imageGalleryModal');
    if (galleryModal) {
        document.body.removeChild(galleryModal);
        document.removeEventListener('keydown', handleGalleryKeydown);
    }
}

function showPrevImage() {
    currentImageIndex = (currentImageIndex - 1 + galleryImages.length) % galleryImages.length;
    updateGalleryImage();
}

function showNextImage() {
    currentImageIndex = (currentImageIndex + 1) % galleryImages.length;
    updateGalleryImage();
}

function updateGalleryImage() {
    var imageUrl = galleryImages[currentImageIndex].resource_url || galleryImages[currentImageIndex].uri || galleryImages[currentImageIndex].uri150;
    document.getElementById('galleryImage').src = imageUrl;
    document.querySelector('#imageGalleryModal div div:last-child').innerHTML = (currentImageIndex + 1) + ' / ' + galleryImages.length;
}

function handleGalleryKeydown(e) {
    if (e.key === 'Escape') {
        closeImageGallery();
    } else if (e.key === 'ArrowLeft') {
        showPrevImage();
    } else if (e.key === 'ArrowRight') {
        showNextImage();
    }
}

// Función global para importar el disco desde el modal de detalle
function importDiscRelease(releaseId) {
    if (confirm('¿Estás seguro de que quieres importar este disco?')) {
        console.log('Importando disco con ID:', releaseId);
        
        // Obtener el post_id de la página actual
        var postId = jQuery('#post_ID').val() || jQuery('input[name="post_ID"]').val() || '';
        
        if (!postId) {
            alert('No se pudo obtener el ID del producto. Asegúrate de estar editando un producto.');
            return;
        }
        
        // Preparar datos para debug
        var ajaxData = {
            action: 'import_discogs_release',
            release_id: releaseId,
            post_id: postId,
            nonce: (typeof wdi_secure_ajax !== 'undefined' ? wdi_secure_ajax.nonce : (wdi_admin_ajax.nonce || ''))
        };
        
        var ajaxUrl = wdi_admin_ajax.ajax_url || ajaxurl;
        
        console.log('AJAX URL:', ajaxUrl);
        console.log('AJAX Data:', ajaxData);
        console.log('wdi_secure_ajax:', typeof wdi_secure_ajax !== 'undefined' ? wdi_secure_ajax : 'undefined');
        console.log('wdi_admin_ajax:', typeof wdi_admin_ajax !== 'undefined' ? wdi_admin_ajax : 'undefined');
        
        // Ejemplo de llamada AJAX (ajusta según tu implementación)
        jQuery.ajax({
            url: ajaxUrl,
            method: 'POST',
            data: ajaxData,
            success: function(response) {
                console.log('Success response:', response);
                if (response.success) {
                    console.log('Import success data:', response.data);
                    
                    // Actualizar los campos del formulario directamente
                    var data = response.data;
                    
                    // Actualizar título del producto
                    if (data.title) {
                        jQuery('#title').val(data.title);
                        jQuery('input[name="post_title"]').val(data.title);
                    }
                    
                    // Actualizar descripción corta (excerpt)
                    if (data.short_description) {
                        jQuery('#excerpt').val(data.short_description);
                        if (typeof tinyMCE !== 'undefined' && tinyMCE.get('excerpt')) {
                            tinyMCE.get('excerpt').setContent(data.short_description);
                        }
                    }
                    
                    // Actualizar descripción larga (content)
                    if (data.long_description) {
                        jQuery('#content').val(data.long_description);
                        if (typeof tinyMCE !== 'undefined' && tinyMCE.get('content')) {
                            tinyMCE.get('content').setContent(data.long_description);
                        }
                    }
                    
                    // Actualizar imagen destacada si se importó
                    if (data.featured_image_id && data.featured_image_url) {
                        // Actualizar el thumbnail
                        jQuery('#postimagediv .inside').html(
                            '<p><a href="#" id="set-post-thumbnail">' +
                            '<img src="' + data.featured_image_url + '" alt="" style="max-width: 100%; height: auto;">' +
                            '</a></p>' +
                            '<p><a href="#" id="remove-post-thumbnail">Remove featured image</a></p>'
                        );
                        
                        // Actualizar el campo oculto
                        jQuery('#_thumbnail_id').val(data.featured_image_id);
                    }
                    
                    // Mostrar mensaje de éxito
                    var message = '¡Disco importado exitosamente!\n\n';
                    message += 'Título: ' + (data.title || 'N/A') + '\n';
                    message += 'Artista: ' + (data.artist || 'N/A') + '\n';
                    message += 'Imágenes: ' + (data.images ? data.images.length : 0) + '\n';
                    message += 'Imagen destacada: ' + (data.featured_image_id ? 'Sí' : 'No') + '\n';
                    message += '\nLos datos han sido actualizados en el formulario.';
                    
                    alert(message);
                    
                    // Cerrar el modal de vista previa
                    var modal = document.getElementById('discModal');
                    if (modal) {
                        document.body.removeChild(modal);
                    }
                    
                } else {
                    console.log('Error response data:', response.data);
                    alert('Error al importar: ' + (response.data.message || response.data));
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.log('Error details:', {
                    status: jqXHR.status,
                    statusText: jqXHR.statusText,
                    responseText: jqXHR.responseText,
                    textStatus: textStatus,
                    errorThrown: errorThrown
                });
                alert('Error de conexión al importar el disco. Ver consola para detalles.');
            }
        });
    }
}

(function( $ ) {
    'use strict';

    $(function() {

        const modalOverlay = $('#wdi-modal-overlay');
        const modalContent = $('#wdi-modal-content');

        // --- FUNCIONES PARA CONTROLAR LA MODAL ---
        function openModal() {
            modalOverlay.css('display', 'flex');
        }
        function closeModal() {
            modalOverlay.hide();
        }
        
        // Hacer closeModal accesible globalmente
        window.wdiCloseModal = closeModal;

        // --- FUNCIÓN PARA MOSTRAR INDICADOR DE CARGA ---
        function showLoadingIndicator(container, message = 'Cargando...') {
            container.html(`
                <div class="wdi-loading-container">
                    <div class="wdi-loading-spinner">
                        <div class="wdi-spinner-circle"></div>
                    </div>
                    <div class="wdi-loading-text">${message}</div>
                </div>
            `);
        }

        // --- FUNCIÓN PARA OCULTAR INDICADOR DE CARGA ---
        function hideLoadingIndicator(container) {
            container.find('.wdi-loading-container').remove();
        }

        // --- EVENTOS PARA CERRAR LA MODAL ---
        $('#wdi-modal-close').on('click', closeModal);
        modalOverlay.on('click', function(e) {
            // Si se hace clic en el fondo oscuro (overlay) y no en el contenido
            if (e.target === this) {
                closeModal();
            }
        });
        
        let fullSearchResults = []; // Almacena los resultados completos de la última búsqueda
        let lastSearchTerm = ''; // Almacena el último término buscado por texto

        // --- EVENTO PARA TECLA ENTER ---
        $('#discogs_release_id').on('keypress', function(e) {
            if (e.which === 13) { 
                e.preventDefault(); 
                $('#fetch-discogs-data').click(); 
            }
        });

        // --- FUNCIÓN DE BÚSQUEDA PRINCIPAL (se activa con el botón o al cambiar país) ---
        function performSearch(searchTerm, countryFilter = '') {
            const button = $('#fetch-discogs-data');
            const spinner = button.siblings('.spinner');
            const resultsDiv = $('#dwoosync-results');
            const countrySelect = $('#discogs_country_filter');
            const countryWrapper = $('#discogs-country-filter-wrapper');

            openModal();
            
            // Limpiar específicamente los mensajes de importación anterior sin afectar la estructura del modal
            $('#wdi-modal-button-container').remove(); // Contenedor "¡Importación Exitosa!"
            $('.wdi-auto-success-message').remove(); // Mensajes "Imágenes agregadas"
            $('#wdi-add-images-btn').remove(); // Botón de selección de imágenes residual
            
            console.log('🧹 Mensajes de importación anterior eliminados');
            
            spinner.addClass('is-active');
            button.prop('disabled', true);
            countrySelect.prop('disabled', true); // Deshabilitar mientras busca
            
            // Mostrar indicador de carga centrado
            showLoadingIndicator(resultsDiv, wdi_admin_ajax.searching_discogs_label || 'Buscando en Discogs...');

            const searchData = {
                action: 'wdi_fetch_discogs_data',
                nonce: wdi_secure_ajax.nonce,
                release_id: searchTerm,
                format: $('input[name="discogs_format"]:checked').val(),
                country: countryFilter // Pasar el país seleccionado
            };

            console.log('Enviando petición AJAX:', searchData);
            
            $.post(wdi_secure_ajax.ajax_url, searchData, function(response) {
                console.log('Respuesta recibida:', response);
                
                if (response.success) {
                    const searchResults = response.data.results;
                    
                    // Ocultar indicador de carga
                    hideLoadingIndicator(resultsDiv);
                    
                    // Mostrar warning si está en período de gracia
                    if (response.data.warning) {
                        showWarningInModal(response.data.warning);
                    }
                    
                    // Actualizar la lista de países solo si es una búsqueda inicial (sin filtro de país)
                    if (response.data.country_stats && countryFilter === '') {
                        countrySelect.empty();
                        
                        // Calcular total de ediciones
                        let totalEditions = 0;
                        response.data.country_stats.forEach(function(country) {
                            totalEditions += country.count;
                        });
                        
                        // Siempre mostrar todos los países disponibles
                        countrySelect.append($('<option>').val('').text('All Countries (' + totalEditions + ')'));
                        response.data.country_stats.forEach(function(country) {
                            const optionText = `${country.name} (${country.count} ediciones)`;
                            countrySelect.append($('<option>').val(country.name).text(optionText));
                        });
                        
                        // Mostrar el filtro de países si hay estadísticas
                        countryWrapper.show();
                    } else if (countryFilter !== '') {
                        // Si hay un filtro de país, solo actualizar la selección sin vaciar la lista
                        countrySelect.val(countryFilter);
                    }

                    renderResultsList(searchResults);
                    
                    // --- INICIO: Marcar categorías sugeridas en checkboxes nativos ---
                    if (response.data.suggested_categories && response.data.suggested_categories.length > 0) {
                        markNativeCategoryCheckboxes(response.data.suggested_categories, response.data.selected_format);
                    }
                    // --- FIN: Marcar categorías sugeridas en checkboxes nativos ---

                } else {
                    console.error('Error en la respuesta:', response);
                    // Ocultar indicador de carga en caso de error
                    hideLoadingIndicator(resultsDiv);
                    resultsDiv.html('<p style="color: red;">Error: ' + response.data.message + '</p>');
                    countrySelect.html('<option value="">Primero busca por ID</option>'); // Resetear en caso de error
                    countryWrapper.hide(); // Ocultar el filtro en caso de error
                }
            }).fail(function(xhr, status, error) {
                console.error('Error en petición AJAX:', {
                    status: status,
                    error: error,
                    responseText: xhr.responseText
                });
                
                // Ocultar indicador de carga en caso de error de conexión
                hideLoadingIndicator(resultsDiv);
                
                // Intentar extraer el mensaje específico de la respuesta
                let errorMessage = 'Error de conexión: ' + error;
                try {
                    const response = JSON.parse(xhr.responseText);
                    if (response.data && response.data.message) {
                        errorMessage = response.data.message;
                    }
                } catch (e) {
                    // Si no se puede parsear, usar el mensaje genérico
                }
                
                resultsDiv.html('<p style="color: red;">' + errorMessage + '</p>');
            }).always(function() {
                spinner.removeClass('is-active');
                button.prop('disabled', false);
                countrySelect.prop('disabled', false); // Rehabilitar al terminar
            });
        }

        // --- RENDERIZAR LA LISTA DE RESULTADOS (función auxiliar) ---
        function renderResultsList(results) {
            const resultsDiv = $('#dwoosync-results');
            resultsDiv.html('<h4>' + (wdi_admin_ajax.results_label || 'Resultados') + ' (' + results.length + '):</h4>');
            const ul = $('<ul>').css({ 'list-style-type': 'none', 'padding-left': 0 });

            if (!results || results.length === 0) {
                ul.append($('<li>').text(wdi_admin_ajax.no_results_found_label || 'No se encontraron resultados para este filtro.'));
            } else {
                results.forEach(function(item) {
                    const li = $('<li>').addClass('wdi-result-item');
                    const img = $('<img>').attr('src', item.thumb || '').addClass('wdi-thumb');
                    const textDiv = $('<div>').addClass('wdi-info');

                    // Hacer el nombre clickeable
                    const clickableTitle = $('<a href="#" class="wdi-preview-link"></a>')
                        .text(item.title)
                        .on('click', function(e) {
                            e.preventDefault();
                            showDiscPreviewModal(item);
                        });

                    textDiv.append(clickableTitle);
                    textDiv.append($('<br>'));
                    const countryText = wdi_admin_ajax.country_label || 'País:';
                    const yearText = wdi_admin_ajax.year_label || 'Año:';
                    textDiv.append($('<span>').text(`${countryText} ${item.country} | Cat#: ${item.catno} | ${yearText} ${item.year}`));

                    const importButton = $('<button>').attr('type', 'button').addClass('button button-secondary button-small wdi-import-btn').text(wdi_admin_ajax.import_label || 'Importar').data('release-id', item.id);

                    li.append(img).append(textDiv).append(importButton);
                    ul.append(li);
                });
        // Modal para mostrar los datos principales del disco
        function showDiscPreviewModal(item) {
            // Mostrar modal inmediatamente con indicador de carga
            var loadingContent = '<div style="text-align: center; padding: 20px;">' +
                '<div style="border: 4px solid #f3f3f3; border-top: 4px solid #3498db; border-radius: 50%; width: 40px; height: 40px; animation: spin 2s linear infinite; margin: 0 auto 20px;"></div>' +
                '<p>' + (wdi_admin_ajax.loading_disc_info_label || 'Cargando información del disco...') + '</p>' +
                '</div>' +
                '<style>@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }</style>';
            
            showModal(loadingContent);
            
            // Llamada AJAX optimizada
            console.log('Enviando petición get_discogs_details con nonce:', wdi_secure_ajax.nonce);
            $.ajax({
                url: ajaxurl,
                method: 'POST',
                dataType: 'json',
                timeout: 10000, // Reducir timeout a 10 segundos
                data: {
                    action: 'get_discogs_details',
                    release_id: item.id,
                    nonce: wdi_secure_ajax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        var details = response.data;
                        // Assuming details has properties: artists (array), title, genres (array), styles (array), format, country, year
                        var artist = (details.artists && details.artists.length > 0) ? details.artists.join(', ') : "Falta la info";
                        var genre = (details.genres && details.genres.length > 0) ? details.genres.join(', ') : "Falta la info";
                        var style = (details.styles && details.styles.length > 0) ? details.styles.join(', ') : "Falta la info";
                        
                        // Crear galería de imágenes
                        var imagesHtml = '';
                        var imageCount = (details.images && details.images.length > 0) ? details.images.length : 0;
                        if (imageCount > 0) {
                            imagesHtml = '<div style="margin: 20px 0; border-top: 1px solid #ddd; padding-top: 20px;"><h4 style="color: #333; margin-bottom: 15px; font-size: 16px;">🖼️ Images:</h4><div style="display: flex; flex-wrap: wrap; gap: 12px; justify-content: center;">';
                            details.images.forEach(function(image, index) {
                                var imageUrl = image.resource_url || image.uri || image.uri150;
                                if (imageUrl) {
                                    imagesHtml += '<img src="' + imageUrl + '" data-image-index="' + index + '" style="width: 100px; height: 100px; object-fit: cover; border-radius: 8px; cursor: pointer; border: 2px solid #f0f0f0; transition: transform 0.2s ease, border-color 0.2s ease;" onmouseover="this.style.transform=\'scale(1.05)\'; this.style.borderColor=\'#007cba\'" onmouseout="this.style.transform=\'scale(1)\'; this.style.borderColor=\'#f0f0f0\'" onclick="openImageGallery(' + index + ', ' + JSON.stringify(details.images).replace(/"/g, '&quot;') + ')">';
                                }
                            });
                            imagesHtml += '</div></div>';
                        }
                        
                        // Ajustar ancho del modal basado en número de imágenes
                        var modalWidth = imageCount > 4 ? '700px' : (imageCount > 2 ? '600px' : '500px');
                        
                        var modalContent = '<div style="max-width: ' + modalWidth + '; max-height: 80vh; overflow-y: auto;">' +
                            '<div style="background: white; color: #333; padding: 25px 20px 20px 20px; margin: -20px -20px 20px -20px; border-radius: 8px 8px 0 0; text-align: center; border-bottom: 2px solid #f0f0f0; position: relative;">' +
                                '<h3 style="margin: 0; font-size: 20px; font-weight: bold; color: #333;">' + (details.title ? details.title : "Unknown Title") + '</h3>' +
                                '<p style="margin: 8px 0 0 0; font-size: 15px; color: #666; font-weight: bold;">' + artist + '</p>' +
                            '</div>' +
                            '<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">' +
                                '<div style="background: #f8f9fa; padding: 12px; border-radius: 6px; border-left: 4px solid #007cba;">' +
                                    '<strong style="color: #333; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px;">🎵 Genre</strong><br>' +
                                    '<span style="color: #666; font-size: 14px;">' + genre + '</span>' +
                                '</div>' +
                                '<div style="background: #f8f9fa; padding: 12px; border-radius: 6px; border-left: 4px solid #28a745;">' +
                                    '<strong style="color: #333; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px;">🎨 Style</strong><br>' +
                                    '<span style="color: #666; font-size: 14px;">' + style + '</span>' +
                                '</div>' +
                                '<div style="background: #f8f9fa; padding: 12px; border-radius: 6px; border-left: 4px solid #ffc107;">' +
                                    '<strong style="color: #333; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px;">💿 Format</strong><br>' +
                                    '<span style="color: #666; font-size: 14px;">' + (details.format ? details.format : "Unknown") + '</span>' +
                                '</div>' +
                                '<div style="background: #f8f9fa; padding: 12px; border-radius: 6px; border-left: 4px solid #dc3545;">' +
                                    '<strong style="color: #333; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px;">📅 Year</strong><br>' +
                                    '<span style="color: #666; font-size: 14px;">' + (details.year ? details.year : "Unknown") + '</span>' +
                                '</div>' +
                            '</div>' +
                            '<div style="background: #f8f9fa; padding: 12px; border-radius: 6px; border-left: 4px solid #6f42c1; margin-bottom: 15px;">' +
                                '<strong style="color: #333; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px;">🌍 Country</strong><br>' +
                                '<span style="color: #666; font-size: 14px;">' + (details.country ? details.country : "Unknown") + '</span>' +
                            '</div>' +
                            imagesHtml +
                        '</div>';
                        
                        // Actualizar el contenido del modal existente
                        document.getElementById('discModal').querySelector('div').innerHTML = modalContent + '<div style="text-align: center; margin-top: 20px; padding-top: 15px; border-top: 1px solid #eee;"><button id="closeModal" style="background: linear-gradient(135deg, #0073aa 0%, #005177 100%); color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: 500; transition: transform 0.2s ease;" onmouseover="this.style.transform=\'translateY(-1px)\'" onmouseout="this.style.transform=\'translateY(0)\'" >Close</button></div>';
                        document.getElementById('closeModal').addEventListener('click', function() {
                            document.body.removeChild(document.getElementById('discModal'));
                        });
                    } else {
                        console.error('Error retrieving disc details: ', response.data);
                        document.getElementById('discModal').querySelector('div').innerHTML = '<p>Error retrieving disc details: ' + response.data + '</p><br><button id="closeModal">Close</button>';
                        document.getElementById('closeModal').addEventListener('click', function() {
                            document.body.removeChild(document.getElementById('discModal'));
                        });
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.error('Error retrieving disc details:', textStatus, errorThrown);
                    console.log('Response Text:', jqXHR.responseText);
                    document.getElementById('discModal').querySelector('div').innerHTML = '<p>Error retrieving disc details.</p><br><button id="closeModal">Close</button>';
                    document.getElementById('closeModal').addEventListener('click', function() {
                        document.body.removeChild(document.getElementById('discModal'));
                    });
                }
            });
            
            // ...existing code to optionally clear modal or show loading state...
        }


            }
            resultsDiv.append(ul);
        }

        // --- EVENTO CLICK DEL BOTÓN "BUSCAR" ---
        $('#fetch-discogs-data').on('click', function() {
            const searchTerm = $('#discogs_release_id').val();
            if (!searchTerm) {
                alert('Por favor, introduce un término de búsqueda.');
                return;
            }
            $('#discogs_country_filter').val(''); // Resetea el select de país a "Todos"
            $('#discogs-country-filter-wrapper').hide(); // Ocultar el filtro hasta que se carguen los resultados
            performSearch(searchTerm);
        });
        
        // --- EVENTO CHANGE DEL SELECT DE PAÍS ---
        $('#discogs_country_filter').on('change', function() {
            const searchTerm = $('#discogs_release_id').val();
            if (!searchTerm) {
                // Esto no debería pasar si el select está deshabilitado, pero es una buena práctica
                alert('Realiza una búsqueda principal primero.');
                return;
            }
            const selectedCountry = $(this).val();
            performSearch(searchTerm, selectedCountry);
        });

        // --- LÓGICA DE IMPORTACIÓN ---
        $('#dwoosync-results').on('click', '.wdi-import-btn', function(e) {
            e.preventDefault();

            const importButton = $(this);
            const releaseId = importButton.data('release-id');
            const spinner = $('#fetch-discogs-data').siblings('.spinner');
            const postId = $('#post_ID').val(); // <-- AÑADIR ESTA LÍNEA
            const resultsDiv = $('#dwoosync-results');

            spinner.addClass('is-active');
            importButton.prop('disabled', true).text('Importando...');
            
            // Mostrar indicador de carga centrado
            showLoadingIndicator(resultsDiv, wdi_admin_ajax.importing_data_label || 'Importando datos...');
            
            // --- INICIO: Obtener categorías seleccionadas de checkboxes nativos ---
            const selectedCategories = [];
            $('input[type="checkbox"][value]:checked').each(function() {
                const value = $(this).val();
                // Solo incluir si es un ID de categoría válido (números)
                if (/^\d+$/.test(value)) {
                    selectedCategories.push(value);
                }
            });
            console.log('Categorías seleccionadas para importación:', selectedCategories);
            // --- FIN: Obtener categorías seleccionadas de checkboxes nativos ---
            
            const importData = {
                action: 'wdi_import_discogs_release',
                nonce: wdi_secure_ajax.nonce,
                release_id: releaseId,
                post_id: postId,
                selected_categories: selectedCategories // <-- AÑADIR CATEGORÍAS SELECCIONADAS
            };
            
            $.post(wdi_secure_ajax.ajax_url, importData)
                .done(function(response) {
                    if (response.success) {
                    const data = response.data;
                    
                    // Ocultar indicador de carga
                    hideLoadingIndicator(resultsDiv);
                    
                    resultsDiv.html('<p style="color: green;">' + (wdi_admin_ajax.data_filled_success_label || '¡Datos rellenados con éxito!') + '</p>');

                    // 1. Rellenar el título del producto (YA VIENE PROCESADO DESDE PHP)
                    if (data.title) {
                        $('#title').val(data.title);
                        $('#title-prompt-text').addClass('screen-reader-text');
                    }
                    
                    // 2. Rellenar Descripción Corta (ya viene procesada desde PHP)
                    if (data.short_description) {
                        if ($('#excerpt').length) {
                            $('#excerpt').val(data.short_description);
                             // Forzar actualización si hay TinyMCE
                            if (typeof tinymce !== 'undefined' && tinymce.get('excerpt')) {
                                tinymce.get('excerpt').setContent(data.short_description);
                            }
                        }
                    }

                    // 3. Rellenar Descripción Larga (ya viene procesada desde PHP)
                    if (data.long_description) {
                        let finalContent = data.long_description;
                        
                        // Para usuarios premium y enterprise, agregar crédito en el editor
                        if (data.plan_type === 'premium' || data.plan_type === 'enterprise') {
                            const discogsCredit = '<p style="font-size: 11px; color: #666; margin-top: 20px; text-align: center;">Data provided by <a href="https://discogs.com" target="_blank" style="color: #666; text-decoration: none;">Discogs.com</a></p>';
                            finalContent = data.long_description + discogsCredit;
                        }
                        
                        if (typeof tinymce !== 'undefined' && tinymce.get('content')) {
                            tinymce.get('content').setContent(finalContent);
                        } else {
                            $('#content').val(finalContent);
                        }
                    }
                    
                    // 4. Preparar imágenes para la galería (esto ya lo hace el backend, pero lo dejamos para UI)
                    if(data.images && data.images.length > 0){
                         const imageUrls = data.images.join(',');
                         $('#discogs_gallery_to_import').val(imageUrls);

                         // --- INICIO: Mostrar previsualización bajo el botón de búsqueda ---
                         $('#discogs-preview-image').attr('src', data.images[0]);
                         $('#discogs-preview-text').text('Las demás imágenes se agregarán a la galería después de guardar el producto.');
                         $('#discogs-preview-wrapper').show();
                         // --- FIN: Mostrar previsualización ---
                    }

                    // El bloque que actualizaba la imagen destacada principal ha sido eliminado por petición.
                    
                    // --- INICIO: Añadir etiquetas automáticamente ---
                    if (data.tags && Array.isArray(data.tags) && data.tags.length > 0) {
                        const tagInput = $('#new-tag-product_tag');
                        const addButton = $('.tagadd');
                        
                        if (tagInput.length && addButton.length) {
                            // Limpiar etiquetas existentes para evitar duplicados en re-importaciones
                            $('.tagchecklist .ntdelbutton').click();
                            
                            // Añadir cada etiqueta nueva
                            data.tags.forEach(function(tag) {
                                tagInput.val(tag);
                                addButton.click();
                            });
                        }
                    }
                    // --- FIN: Añadir etiquetas automáticamente ---

                    // --- INICIO: El botón está visible por defecto ---
                    // Ya no necesitamos mostrarlo aquí ya que está visible desde el inicio
                    // --- FIN: El botón está visible por defecto ---

                    // --- INICIO: Mostrar y activar campos rápidos ---
                    const $quickFieldsWrapper = $('#wdi-quick-fields-wrapper');
                    if ($quickFieldsWrapper.length) {
                        $quickFieldsWrapper.show();

                        // Activar el selector de categorías si existe
                        const $categorySelector = $('#wdi-quick-categories');
                        if ($categorySelector.length) {
                            try {
                                $categorySelector.select2({
                                    ajax: {
                                        url: wdi_secure_ajax.ajax_url,
                                        dataType: 'json',
                                        delay: 250,
                                        type: 'POST', // <-- AÑADIR ESTA LÍNEA
                                        data: function (params) {
                                            return {
                                                action: 'wdi_search_product_categories', // <-- NUESTRO PROPIO BUSCADOR
                                                nonce: wdi_secure_ajax.search_categories_nonce, // <-- Cambiado a 'nonce'
                                                term: params.term
                                            };
                                        },
                                        processResults: function( data ) {
                                            // El formato ya viene como lo necesita Select2
                                            return {
                                                results: data.results 
                                            };
                                        },
                                        cache: true
                                    },
                                    minimumInputLength: 2,
                                    placeholder: 'Buscar y seleccionar categorías...'
                                });
                            } catch (e) {
                                console.error('Error al inicializar Select2:', e);
                            }
                        }
                    }
                    // --- FIN: Mostrar y activar campos rápidos ---
                    
                    // --- INICIO: Lógica para modo de selección de imágenes ---
                    if (data.image_import_mode === 'all' && data.gallery_images_data && data.gallery_images_data.length > 0) {
                        // Modo automático: actualizar galería inmediatamente
                        console.log('Modo ALL detectado: actualizando galería automáticamente');
                        
                        // Mostrar filtro de país en modo automático (si había sido ocultado)
                        $('#discogs-country-filter-wrapper').show();
                        console.log('👁️ Filtro de país mostrado para modo automático');
                        
                        updateGalleryDisplayAutomatic(data.gallery_images_data, data.gallery_ids);
                    } else if (data.image_import_mode === 'select' && data.all_images && data.all_images.length > 0) {
                        // Modo selección: mostrar botón para abrir modal
                        console.log('Modo SELECT detectado: agregando botón de selección');
                        console.log('Imágenes disponibles para selección:', data.all_images.length);
                        
                        // Almacenar imágenes en variable global para acceso posterior
                        window.currentDiscogsImages = data.all_images;
                        
                        addSelectImagesButton(data.all_images);
                        
                        // NO cerrar la modal en modo selección - mantenerla abierta para que el usuario pueda ver el botón
                        console.log('Modal mantenida abierta para modo selección manual');
                    }
                    // --- FIN: Lógica para modo de selección de imágenes ---

                    // Cerrar la modal después de 1 segundo SOLO si NO está en modo selección
                    if (data.image_import_mode !== 'select') {
                        setTimeout(function() { closeModal(); }, 1000);
                    }

                 } else {
                    // Ocultar indicador de carga en caso de error
                    hideLoadingIndicator(resultsDiv);
                    
                    // Manejar diferentes tipos de errores
                    let errorMessage = 'Error al importar: ';
                    if (response.data && response.data.message) {
                        errorMessage += response.data.message;
                    } else if (response.data) {
                        errorMessage += JSON.stringify(response.data);
                    } else {
                        errorMessage += 'Error desconocido';
                    }
                    
                    // Mostrar error en la interfaz en lugar de alert
                    resultsDiv.html('<div style="color: red; padding: 10px; border: 1px solid red; background: #ffe6e6; border-radius: 4px;">' + errorMessage + '</div>');
                    importButton.prop('disabled', false).text(wdi_admin_ajax.import_label || 'Importar');
                    
                    console.error('Error en importación:', response);
                 }
                })
                .fail(function(xhr, status, error) {
                    // Ocultar indicador de carga en caso de error HTTP
                    hideLoadingIndicator(resultsDiv);
                    
                    let errorMessage = 'Error al importar: ';
                    
                    // Intentar parsear la respuesta JSON
                    try {
                        const response = JSON.parse(xhr.responseText);
                        if (response.data && response.data.message) {
                            errorMessage += response.data.message;
                        } else {
                            errorMessage += 'Error HTTP ' + xhr.status + ': ' + error;
                        }
                    } catch (e) {
                        errorMessage += 'Error HTTP ' + xhr.status + ': ' + error;
                    }
                    
                    // Mostrar error en la interfaz
                    resultsDiv.html('<div style="color: red; padding: 10px; border: 1px solid red; background: #ffe6e6; border-radius: 4px;">' + errorMessage + '</div>');
                    importButton.prop('disabled', false).text(wdi_admin_ajax.import_label || 'Importar');
                    
                    console.error('Error HTTP en importación:', xhr, status, error);
                })
                .always(function() {
                    spinner.removeClass('is-active');
                });
        });
        
        // --- INICIO: Funcionalidad del botón Publicar ---
        $('#dwoosync-wrapper').on('click', '#publish-from-importer', function(e) {
            e.preventDefault();
            const publishButton = $(this);
            const mainPublishButton = $('#publish');

            // Sincronizar campos antes de guardar
            syncDWooSyncFields();

            if (mainPublishButton.length) {
                publishButton.text(wdi_admin_ajax.publishing_label || 'Publicando...').prop('disabled', true);
                mainPublishButton.click(); // Simula el clic en el botón principal de WordPress
            } else {
                alert(wdi_admin_ajax.publish_button_not_found_label || 'No se pudo encontrar el botón de publicación principal.');
            }
        });
        // --- FIN: Funcionalidad del botón Publicar ---


        // --- INICIO: Sincronización de campos rápidos ---
        
        // Sincronizar selector de categorías
        $('#dwoosync-wrapper').on('change', '#wdi-quick-categories', function() {
            const selectedCategories = $(this).val(); // Obtiene un array de IDs
            
            // Primero, desmarcar todas las categorías en la caja de checklist de WooCommerce
            $('#product_catchecklist input[type="checkbox"]').prop('checked', false);
            
            // Luego, marcar solo las que están seleccionadas en el Select2
            if (selectedCategories && selectedCategories.length > 0) { // <-- CORREGIDO
                $.each(selectedCategories, function(index, catId) {
                    $('#in-product_cat-' + catId).prop('checked', true);
                });
            }
        });
        
        // Sincronizar campo de precio en tiempo real
        $('#dwoosync-wrapper').on('input change', '#wdi-quick-price', function() {
            const priceValue = $(this).val().trim();
            
            // Sincronizar con campos de WooCommerce
            $('#_regular_price').val(priceValue);
            $('#_price').val(priceValue);
            
            console.log('Precio sincronizado en tiempo real:', priceValue);
        });

        // --- FIN: Sincronización de campos rápidos ---
        
        /**
         * Función para sincronizar todos los campos de DWooSync con WooCommerce
         */
        function syncDWooSyncFields() {
            console.log('Sincronizando campos de DWooSync...');
            
            // Sincronizar precio
            const quickPrice = $('#wdi-quick-price').val();
            if (quickPrice && quickPrice.trim() !== '') {
                // Buscar el campo de precio regular de WooCommerce
                const regularPriceField = $('#_regular_price');
                if (regularPriceField.length) {
                    regularPriceField.val(quickPrice.trim());
                    console.log('Precio sincronizado:', quickPrice);
                } else {
                    console.warn('Campo de precio regular de WooCommerce no encontrado');
                }
                
                // También sincronizar con el campo de precio normal (fallback)
                const priceField = $('#_price');
                if (priceField.length) {
                    priceField.val(quickPrice.trim());
                }
            }
            
            // Sincronizar categorías (ya existe la lógica, la llamamos)
            const categoriesField = $('#wdi-quick-categories');
            if (categoriesField.length) {
                categoriesField.trigger('change');
            }
            
            console.log('Sincronización de campos completada');
        }
        
    });

    // Función para mostrar warning en el modal
    function showWarningInModal(warningMessage) {
        console.log('Mostrando warning en modal:', warningMessage);
        
        // Buscar el modal
        const modal = $('#wdi-modal-content');
        const modalHeader = $('#wdi-modal-header');
        
        if (modal.length > 0 && modalHeader.length > 0) {
            // Remover warning anterior si existe
            modal.find('.discogs-warning').remove();
            
            // Los mensajes de warning ya vienen en inglés desde la API
            let translatedMessage = warningMessage;
            
            // Crear el warning
            const warningHtml = `
                <div class="discogs-warning" style="background: #fff3cd; border: 1px solid #ffeaa7; color: #856404; padding: 10px; margin: 10px 0; border-radius: 4px; font-size: 13px;">
                    <strong>⚠️ ${wdi_admin_ajax.warning_label || 'Warning:'}</strong> ${translatedMessage.replace(/http:\/\/www\.dwoosync\.com/g, '<a href="http://www.dwoosync.com" target="_blank" style="color: #856404; text-decoration: underline;">http://www.dwoosync.com</a>')}
                </div>
            `;
            
            // Insertar después del header
            modalHeader.after(warningHtml);
            console.log('Warning agregado al modal');
        } else {
            console.log('No se encontró el modal o header');
        }
    }

    // --- FUNCIÓN PARA MARCAR CHECKBOXES NATIVOS DE WOOCOMMERCE ---
    function markNativeCategoryCheckboxes(categories, format) {
        console.log('Marcando categorías nativas:', categories, 'para formato:', format);
        
        // Limpiar categorías sugeridas anteriores
        $('#suggested-categories-wrapper').remove();
        
        // Mostrar notificación de categorías marcadas
        const resultsDiv = $('#dwoosync-results');
        let notificationHtml = `
            <div id="suggested-categories-wrapper" style="background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; padding: 15px; margin: 15px 0;">
                <h4 style="margin-top: 0; color: #155724; font-size: 14px;">
                    ✅ ${wdi_admin_ajax.categories_marked_automatically_label || 'Categorías marcadas automáticamente para'} ${format}:
                </h4>
                <div id="suggested-categories-list" style="margin: 10px 0;">
        `;
        
        categories.forEach(function(category) {
            notificationHtml += `<span style="display: inline-block; background: #28a745; color: white; padding: 2px 8px; margin: 2px; border-radius: 3px; font-size: 12px;">${category.name}</span>`;
        });
        
        notificationHtml += `
                </div>
                <p style="margin: 10px 0 0 0; font-size: 12px; color: #155724;">
                    ✓ ${wdi_admin_ajax.check_product_tab_label || 'Revisa la pestaña "Producto" para ver las categorías marcadas.'}
                </p>
            </div>
        `;
        
        resultsDiv.append(notificationHtml);
        
        // Marcar los checkboxes nativos de WooCommerce
        setTimeout(function() {
            // --- INICIO: Limpiar categorías de formatos anteriores ---
            clearFormatCategories();
            // --- FIN: Limpiar categorías de formatos anteriores ---
            
            let markedCount = 0;
            categories.forEach(function(category) {
                // Buscar en todas las pestañas de categorías
                const checkboxes = $(`input[value="${category.id}"][type="checkbox"]`);
                checkboxes.each(function() {
                    if (!$(this).is(':checked')) {
                        $(this).prop('checked', true).trigger('change');
                        markedCount++;
                        console.log('Categoría nativa marcada:', category.name, 'ID:', category.id);
                    }
                });
            });
            
            console.log(`Categorías nativas marcadas: ${markedCount} de ${categories.length}`);
            
            // Mostrar mensaje de confirmación
            if (markedCount > 0) {
                const confirmationHtml = `
                    <div style="background: #d1ecf1; border: 1px solid #bee5eb; color: #0c5460; padding: 10px; margin: 10px 0; border-radius: 4px; font-size: 12px;">
                        ✅ ${markedCount} ${wdi_admin_ajax.categories_marked_product_tab_label || 'categoría(s) marcada(s) automáticamente en la pestaña "Producto"'}
                    </div>
                `;
                resultsDiv.append(confirmationHtml);
            }
        }, 500);
        
        // Guardar las categorías sugeridas para usar en la importación
        window.suggestedCategories = categories;
        
        // Guardar todas las categorías de formatos para limpieza futura
        if (!window.formatCategories) {
            window.formatCategories = [];
        }
        categories.forEach(function(category) {
            if (window.formatCategories.indexOf(category.id) === -1) {
                window.formatCategories.push(category.id);
            }
        });
        
        console.log('Categorías nativas marcadas correctamente');
    }

    // --- FUNCIÓN PARA LIMPIAR CATEGORÍAS DE FORMATOS ANTERIORES ---
    function clearFormatCategories() {
        console.log('Limpiando categorías de formatos anteriores...');
        
        // Obtener todas las categorías configuradas para formatos
        const formatCategories = window.formatCategories || [];
        
        if (formatCategories.length === 0) {
            // Si no tenemos las categorías guardadas, intentar obtenerlas de la configuración
            // Esto se ejecutará la primera vez
            console.log('No hay categorías de formatos guardadas, saltando limpieza');
            return;
        }
        
        let clearedCount = 0;
        formatCategories.forEach(function(categoryId) {
            const checkboxes = $(`input[value="${categoryId}"][type="checkbox"]`);
            checkboxes.each(function() {
                if ($(this).is(':checked')) {
                    $(this).prop('checked', false).trigger('change');
                    clearedCount++;
                    console.log('Categoría desmarcada:', categoryId);
                }
            });
        });
        
        console.log(`Categorías de formatos desmarcadas: ${clearedCount}`);
    }

    // --- INICIO: Event listener para botón "Agregar imágenes a la galería" ---
    $(document).on('click', '#wdi-add-images-btn', function(e) {
        e.preventDefault();
        console.log('Event listener del botón activado');
        
        // Intentar obtener las imágenes del data attribute primero
        let images = $(this).data('images');
        
        // Si no hay imágenes en data, buscar en variables globales o contexto
        if (!images || images.length === 0) {
            console.log('No hay imágenes en data attribute, buscando en contexto global');
            
            // Buscar en el contexto global que pudiera tener las imágenes
            if (window.currentDiscogsImages && window.currentDiscogsImages.length > 0) {
                images = window.currentDiscogsImages;
                console.log('Imágenes encontradas en contexto global:', images.length);
            } else {
                console.log('No se encontraron imágenes en ningún contexto');
                alert('No hay imágenes disponibles para seleccionar. Por favor, importa un producto primero.');
                return;
            }
        }
        
        console.log('Cerrando ventana flotante y abriendo modal con', images.length, 'imágenes');
        
        // Cerrar la ventana flotante antes de abrir el modal
        if (typeof window.wdiCloseModal === 'function') {
            window.wdiCloseModal();
        } else {
            console.error('wdiCloseModal no está disponible');
        }
        
        // Crear modal de selección de imágenes
        createImageSelectionModal(images);
    });
    
    function createImageSelectionModal(images) {
        console.log('=== CREANDO MODAL DE SELECCIÓN ===');
        console.log('Imágenes recibidas:', images);
        console.log('Tipo de datos:', typeof images);
        console.log('Es array:', Array.isArray(images));
        console.log('Longitud:', images ? images.length : 'undefined');
        
        if (!images) {
            console.error('ERROR: No se pasaron imágenes al modal');
            alert('Error: No se recibieron datos de imágenes.');
            return;
        }
        
        if (!Array.isArray(images)) {
            console.error('ERROR: Las imágenes no son un array');
            alert('Error: Formato de datos de imágenes incorrecto.');
            return;
        }
        
        if (images.length === 0) {
            console.error('ERROR: Array de imágenes está vacío');
            alert('No hay imágenes disponibles para este lanzamiento.');
            return;
        }
        
        console.log('✅ Datos de imágenes válidos, creando modal...');
        
        // Crear overlay
        const overlay = $('<div>')
            .attr('id', 'wdi-image-selection-overlay')
            .css({
                'position': 'fixed',
                'top': '0',
                'left': '0',
                'width': '100%',
                'height': '100%',
                'background': 'rgba(0,0,0,0.7)',
                'z-index': '9999',
                'display': 'flex',
                'align-items': 'center',
                'justify-content': 'center'
            });
        
        // Crear contenido de la modal
        const modalContent = $('<div>')
            .css({
                'background': 'white',
                'border-radius': '8px',
                'padding': '20px',
                'min-width': '600px', // Ancho mínimo de 600px
                'max-width': '800px',
                'width': 'auto', // Se ajusta al contenido pero respeta min-width
                'max-height': '80vh',
                'overflow-y': 'auto',
                'position': 'relative'
            });
        
        // Título
        const title = $('<h2>').text(wdi_admin_ajax.select_images_for_gallery_label || 'Seleccionar imágenes para la galería').css('margin-top', '0');
        
        // Botón cerrar
        const closeBtn = $('<button>')
            .html('&times;')
            .css({
                'position': 'absolute',
                'top': '10px',
                'right': '15px',
                'background': 'none',
                'border': 'none',
                'font-size': '24px',
                'cursor': 'pointer'
            })
            .on('click', function() {
                if (confirm('¿Estás seguro de que quieres cerrar sin seleccionar imágenes?')) {
                    overlay.remove();
                }
            });
        
        // Contenedor de imágenes
        const imagesContainer = $('<div>')
            .css({
                'display': 'grid',
                'grid-template-columns': 'repeat(4, 1fr)', // Siempre 4 columnas exactas
                'gap': '15px',
                'margin': '20px 0',
                'min-width': '560px' // Ancho mínimo para 4 columnas (4 * 130px + gaps)
            });
        
        // Agregar cada imagen
        images.forEach((image, index) => {
            const imageCard = $('<div>')
                .css({
                    'border': '2px solid #ddd',
                    'border-radius': '8px',
                    'padding': '10px',
                    'text-align': 'center',
                    'cursor': 'pointer',
                    'transition': 'border-color 0.3s'
                })
                .data('image-data', image);
            
            const img = $('<img>')
                .attr('src', image.uri)
                .css({
                    'width': '100%',
                    'height': '120px',
                    'object-fit': 'cover',
                    'border-radius': '4px'
                });
            
            const checkbox = $('<input>')
                .attr('type', 'checkbox')
                .attr('id', 'img-' + index)
                .css('margin-top', '8px');
            
            const label = $('<label>')
                .attr('for', 'img-' + index)
                .text(wdi_admin_ajax.include_label || 'Incluir')
                .css({
                    'display': 'block',
                    'margin-top': '5px',
                    'font-size': '12px'
                });
            
            // Toggle selection al hacer click
            imageCard.on('click', function() {
                checkbox.prop('checked', !checkbox.prop('checked'));
                updateCardSelection(imageCard, checkbox.prop('checked'));
            });
            
            checkbox.on('change', function() {
                updateCardSelection(imageCard, $(this).prop('checked'));
            });
            
            imageCard.append(img, checkbox, label);
            imagesContainer.append(imageCard);
        });
        
        // Botones de acción
        const actionsContainer = $('<div>')
            .css({
                'display': 'flex',
                'justify-content': 'space-between',
                'margin-top': '20px'
            });
        
        const selectAllBtn = $('<button>')
            .addClass('button')
            .text(wdi_admin_ajax.select_all_label || 'Seleccionar todas')
            .on('click', function() {
                imagesContainer.find('input[type="checkbox"]').prop('checked', true).trigger('change');
            });
        
        const deselectAllBtn = $('<button>')
            .addClass('button')
            .text(wdi_admin_ajax.deselect_all_label || 'Deseleccionar todas')
            .on('click', function() {
                imagesContainer.find('input[type="checkbox"]').prop('checked', false).trigger('change');
            });
        
        const confirmBtn = $('<button>')
            .addClass('button button-primary')
            .text(wdi_admin_ajax.add_label || 'Agregar')
            .on('click', function() {
                const selectedImages = [];
                imagesContainer.find('input[type="checkbox"]:checked').each(function() {
                    const card = $(this).parent();
                    const imageData = card.data('image-data');
                    console.log('Found checked checkbox, card:', card, 'imageData:', imageData);
                    if (imageData) {
                        selectedImages.push(imageData);
                    }
                });
                
                console.log('Total selected images:', selectedImages.length);
                
                if (selectedImages.length === 0) {
                    alert('Por favor selecciona al menos una imagen.');
                    return;
                }
                
                // Procesar imágenes seleccionadas
                processSelectedImages(selectedImages);
                
                // Cerrar el modal - redundante pero seguro
                overlay.remove();
            });
        
        actionsContainer.append(
            $('<div>').append(selectAllBtn, ' ', deselectAllBtn),
            confirmBtn
        );
        
        // Ensamblar modal
        modalContent.append(title, closeBtn, imagesContainer, actionsContainer);
        overlay.append(modalContent);
        
        // Agregar al DOM
        $('body').append(overlay);
    }
    
    function updateCardSelection(card, selected) {
        if (selected) {
            card.css('border-color', '#0073aa');
            card.css('background-color', '#f0f8ff');
        } else {
            card.css('border-color', '#ddd');
            card.css('background-color', 'white');
        }
    }
    
    function processSelectedImages(selectedImages) {
        // Prevenir cualquier comportamiento de formulario que pueda causar recarga
        event.preventDefault();
        
        // Desactivar el aviso de "¿desea salir de la página?" temporalmente
        window.onbeforeunload = null;
        
        // Deshabilitar el formulario temporalmente para evitar cambios
        $('form#post').find('input, select, textarea').prop('disabled', true);
        
        // Mostrar indicador de carga
        const loadingMsg = $('<div>')
            .attr('id', 'wdi-loading-images')
            .css({
                'position': 'fixed',
                'top': '50%',
                'left': '50%',
                'transform': 'translate(-50%, -50%)',
                'background': 'white',
                'padding': '20px',
                'border-radius': '8px',
                'box-shadow': '0 4px 12px rgba(0,0,0,0.3)',
                'z-index': '10000',
                'text-align': 'center'
            })
            .html('<div class="spinner is-active"></div><p>' + wdi_admin_ajax.adding_images_to_gallery_label + '</p>');
        
        $('body').append(loadingMsg);
        
        // Preparar URLs de imágenes seleccionadas
        console.log('Selected images data:', selectedImages);
        const imageUrls = selectedImages.map(img => {
            console.log('Processing image:', img);
            return img ? img.uri : null;
        }).filter(url => url !== null);
        
        console.log('Image URLs to send:', imageUrls);
        
        if (imageUrls.length === 0) {
            alert('Error: No se pudieron obtener las URLs de las imágenes seleccionadas.');
            loadingMsg.remove();
            $('form#post').find('input, select, textarea').prop('disabled', false);
            return;
        }
        
        // Llamar al backend para procesar las imágenes
        $.ajax({
            url: wdi_secure_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'wdi_add_images_to_gallery',
                nonce: wdi_secure_ajax.nonce,
                post_id: $('#post_ID').val(),
                image_urls: imageUrls
            },
            success: function(response) {
                loadingMsg.remove();
                
                // Rehabilitar el formulario
                $('form#post').find('input, select, textarea').prop('disabled', false);
                
                if (response.success) {
                    console.log('✅ Imágenes agregadas correctamente, cerrando modal');
                    
                    // Cerrar el modal con el ID correcto
                    const modalOverlay = $('#wdi-image-selection-overlay');
                    if (modalOverlay.length > 0) {
                        modalOverlay.remove();
                        console.log('✅ Modal cerrado correctamente');
                    } else {
                        console.warn('⚠️ No se encontró el modal para cerrar');
                    }
                    
                    // Ocultar el botón "Agregar imágenes a la galería"
                    $('#wdi-add-images-btn').hide();
                    
                    // Log para debug de la estructura de la página
                    console.log('=== DEBUG: Estructura de la página ===');
                    console.log('Elementos ul encontrados:', $('ul').length);
                    $('ul').each(function(i) {
                        console.log(`UL ${i}:`, this.className, this.id);
                    });
                    console.log('Elementos con "image":', $('[class*="image"]').length);
                    console.log('Elementos con "gallery":', $('[class*="gallery"], [id*="gallery"]').length);
                    
                    // Actualizar la galería visualmente al instante
                    updateGalleryDisplay(response.data.gallery_ids, response.data.total_gallery_ids, response.data.image_data);
                    
                    // Mostrar mensaje de éxito
                    const successMsg = $('<div>')
                        .css({
                            'background': '#d4edda',
                            'color': '#155724',
                            'padding': '10px',
                            'border': '1px solid #c3e6cb',
                            'border-radius': '4px',
                            'margin-top': '10px'
                        })
                        .text(`¡${response.data.processed_count} imágenes agregadas a la galería exitosamente!`);
                    
                    $('#wdi-add-images-btn').after(successMsg);
                    
                    // Log para debug
                    console.log('Imágenes procesadas:', response.data);
                    
                    // NO recargar la página, solo mostrar mensaje
                    setTimeout(function() {
                        successMsg.fadeOut();
                        
                        // Mostrar un mensaje permanente más discreto
                        const permanentMsg = $('<div>')
                            .css({
                                'background': '#e7f3ff',
                                'color': '#0073aa',
                                'padding': '8px',
                                'border': '1px solid #b3d9ff',
                                'border-radius': '4px',
                                'margin-top': '5px',
                                'font-size': '12px'
                            })
                            .html('✓ Imágenes agregadas. <strong>Guarda el producto</strong> para completar.');
                        
                        $('#wdi-add-images-btn').after(permanentMsg);
                        
                        // Reactivar avisos de WordPress solo si es necesario
                        restoreBeforeUnloadWarning();
                    }, 3000);
                } else {
                    console.error('❌ Error del servidor:', response.data);
                    alert('Error al agregar imágenes: ' + (response.data.message || 'Error desconocido'));
                    
                    // Cerrar el modal también en caso de error
                    const modalOverlay = $('#wdi-image-selection-overlay');
                    if (modalOverlay.length > 0) {
                        modalOverlay.remove();
                        console.log('✅ Modal cerrado después de error del servidor');
                    }
                    
                    // Reactivar avisos en caso de error
                    restoreBeforeUnloadWarning();
                }
            },
            error: function(xhr, status, error) {
                loadingMsg.remove();
                
                // Rehabilitar el formulario
                $('form#post').find('input, select, textarea').prop('disabled', false);
                
                console.error('❌ Error de AJAX:', error, xhr.responseText);
                alert('Error de conexión al agregar imágenes: ' + error);
                
                // Cerrar el modal también en caso de error de conexión
                const modalOverlay = $('#wdi-image-selection-overlay');
                if (modalOverlay.length > 0) {
                    modalOverlay.remove();
                    console.log('✅ Modal cerrado después de error de conexión');
                }
                
                // Reactivar avisos en caso de error
                restoreBeforeUnloadWarning();
            }
        });
        
        // Retornar false para prevenir cualquier acción adicional
        return false;
    }
    
    function updateGalleryDisplayAutomatic(imagesData, galleryIds) {
        console.log('Actualizando galería automáticamente con:', imagesData);
        
        // Buscar el contenedor de la galería de WooCommerce
        const possibleSelectors = [
            '#product_images_container ul.product_images',
            '.product_images',
            '#product_images_container .product_images',
            '.woocommerce_product_images',
            '#woocommerce-product-images ul',
            '.wc-metabox-content .product_images'
        ];
        
        let galleryContainer = null;
        
        for (let selector of possibleSelectors) {
            galleryContainer = $(selector);
            if (galleryContainer.length > 0) {
                console.log('Galería encontrada con selector:', selector);
                break;
            }
        }
        
        // Si no encontramos la galería, buscar de forma más amplia
        if (!galleryContainer || galleryContainer.length === 0) {
            galleryContainer = $('ul').filter(function() {
                return $(this).find('li.image').length > 0 || $(this).hasClass('product_images');
            }).first();
        }
        
        if (galleryContainer && galleryContainer.length > 0) {
            console.log('Procesando imágenes para galería automática...');
            
            // Procesar solo las imágenes de galería (no la destacada)
            const galleryImages = imagesData.filter(img => img.type === 'gallery');
            
            galleryImages.forEach(function(image, index) {
                const newImageHtml = $(`
                    <li class="image" data-attachment_id="${image.id}">
                        <img src="${image.thumb || image.url}" alt="Imagen ${index + 1}" width="150" height="150" />
                        <ul class="actions">
                            <li><a href="#" class="delete" title="Eliminar imagen">×</a></li>
                        </ul>
                    </li>
                `);
                
                const addButton = galleryContainer.find('li.add-image, .add-image');
                if (addButton.length > 0) {
                    addButton.before(newImageHtml);
                } else {
                    galleryContainer.append(newImageHtml);
                }
            });
            
            // Actualizar el campo oculto de la galería
            const galleryInputs = [
                'input#product_image_gallery',
                'input[name="product_image_gallery"]',
                '#product_image_gallery'
            ];
            
            for (let inputSelector of galleryInputs) {
                const galleryInput = $(inputSelector);
                if (galleryInput.length > 0 && galleryIds) {
                    const newValue = galleryIds.join(',');
                    galleryInput.val(newValue);
                    console.log('Campo galería actualizado automáticamente:', newValue);
                    break;
                }
            }
            
            // Actualizar imagen destacada si existe
            const featuredImage = imagesData.find(img => img.type === 'featured');
            if (featuredImage) {
                // Actualizar el campo oculto de imagen destacada
                $('#_thumbnail_id').val(featuredImage.id);
                
                // Actualizar la visualización de la imagen destacada
                const featuredContainer = $('#postimagediv .inside');
                if (featuredContainer.length > 0) {
                    const featuredHtml = `
                        <p class="hide-if-no-js">
                            <a title="Establecer imagen destacada" href="#" id="set-post-thumbnail">
                                <img width="266" height="266" src="${featuredImage.thumb}" alt="">
                            </a>
                        </p>
                        <p class="hide-if-no-js howto" id="set-post-thumbnail-desc">Clic en la imagen para editarla o actualizarla</p>
                        <p class="hide-if-no-js">
                            <a href="#" id="remove-post-thumbnail">Eliminar imagen destacada</a>
                        </p>
                    `;
                    featuredContainer.html(featuredHtml);
                }
            }
            
            // Disparar eventos para que WooCommerce detecte los cambios
            galleryContainer.trigger('change');
            $(document).trigger('woocommerce_gallery_updated');
            
            // Mostrar mensaje de éxito
            showSuccessMessage('✅ Imágenes cargadas automáticamente en la galería');
            
            console.log('Galería actualizada automáticamente');
        } else {
            console.log('No se pudo encontrar el contenedor de galería para actualización automática');
        }
    }
    
    function showSuccessMessage(message) {
        // Remover mensajes anteriores
        $('.wdi-auto-success-message').remove();
        
        const successMsg = $('<div>')
            .addClass('wdi-auto-success-message')
            .css({
                'background': '#d4edda',
                'color': '#155724',
                'padding': '10px 15px',
                'border': '1px solid #c3e6cb',
                'border-radius': '4px',
                'margin': '10px 0',
                'display': 'none'
            })
            .text(message);
        
        // Insertar después del botón de importar o en un lugar visible
        const targetElement = $('.wdi-import-section, #wdi-import-btn').first();
        if (targetElement.length > 0) {
            targetElement.after(successMsg);
        } else {
            $('#normal-sortables').prepend(successMsg);
        }
        
        successMsg.fadeIn().delay(4000).fadeOut();
    }
    
    function addSelectImagesButton(allImages) {
        console.log('Agregando botón de selección de imágenes');
        
        // Remover botón anterior si existe
        $('#wdi-add-images-btn, #wdi-modal-button-container, #wdi-image-selector-container').remove();
        
        // Ocultar el filtro de país cuando aparece el botón de selección manual
        $('#discogs-country-filter-wrapper').hide();
        console.log('🙈 Filtro de país ocultado para modo de selección manual');
        
        // Crear el botón
        const selectButton = $('<button>')
            .attr('type', 'button')
            .attr('id', 'wdi-add-images-btn')
            .addClass('button button-primary button-large')
            .data('images', allImages) // Almacenar imágenes en el botón
            .css({
                'margin': '15px 0',
                'display': 'block',
                'width': '100%',
                'padding': '12px 20px',
                'font-size': '14px',
                'font-weight': 'bold',
                'text-align': 'center',
                'background': 'linear-gradient(135deg, #0073aa 0%, #005a8a 100%)',
                'border': 'none',
                'border-radius': '6px',
                'box-shadow': '0 3px 6px rgba(0,0,0,0.15)',
                'transition': 'all 0.3s ease',
                'cursor': 'pointer'
            })
            .text('🖼️ ' + (wdi_admin_ajax.select_images_for_gallery_label || 'Seleccionar imágenes para la galería'))
            .hover(
                function() {
                    $(this).css({
                        'background': 'linear-gradient(135deg, #005a8a 0%, #004570 100%)',
                        'box-shadow': '0 5px 10px rgba(0,0,0,0.25)',
                        'transform': 'translateY(-1px)'
                    });
                },
                function() {
                    $(this).css({
                        'background': 'linear-gradient(135deg, #0073aa 0%, #005a8a 100%)',
                        'box-shadow': '0 3px 6px rgba(0,0,0,0.15)',
                        'transform': 'translateY(0)'
                    });
                }
            )
            .on('click', function(e) {
                e.preventDefault();
                console.log('Botón clickeado, cerrando ventana flotante y abriendo modal');
                
                // Cerrar la ventana flotante antes de abrir el modal de selección
                if (typeof window.wdiCloseModal === 'function') {
                    window.wdiCloseModal();
                } else {
                    console.error('wdiCloseModal no está disponible');
                }
                
                // Abrir modal de selección con las imágenes
                createImageSelectionModal(allImages);
            });
        
        // Buscar específicamente el área de resultados de búsqueda
        let inserted = false;
        
        // Detectar si estamos dentro de la ventana flotante
        const isInModal = $('#wdi-modal-overlay').is(':visible');
        console.log('¿Estamos en la ventana flotante?', isInModal);
        
        // Opción 1: Si estamos en la ventana flotante, insertar en el contenido del modal
        if (isInModal) {
            const modalContent = $('#wdi-modal-content');
            if (modalContent.length > 0) {
                // Crear un contenedor especial para la ventana flotante
                const modalButtonContainer = $('<div>')
                    .attr('id', 'wdi-modal-button-container')
                    .css({
                        'background': 'linear-gradient(135deg, #f0f8ff 0%, #e6f3ff 100%)',
                        'border': '2px solid #0073aa',
                        'border-radius': '8px',
                        'padding': '20px',
                        'margin': '15px 0',
                        'text-align': 'center',
                        'box-shadow': '0 4px 12px rgba(0,0,0,0.1)'
                    })
                    .append(
                        $('<h3>')
                            .html('🎵 ' + (wdi_admin_ajax.import_success_label || '¡Importación Exitosa!'))
                            .css({
                                'margin': '0 0 10px 0',
                                'color': '#0073aa',
                                'font-size': '18px'
                            }),
                        $('<p>')
                            .text(wdi_admin_ajax.product_imported_message || 'El producto ha sido importado. Ahora puedes seleccionar las imágenes que deseas agregar a la galería.')
                            .css({
                                'margin': '10px 0 20px 0',
                                'color': '#666',
                                'line-height': '1.5'
                            }),
                        selectButton,
                        $('<button>')
                            .attr('type', 'button')
                            .addClass('button')
                            .text('✕ ' + (wdi_admin_ajax.close_window_label || 'Cerrar ventana'))
                            .css({
                                'margin': '10px 0 0 0',
                                'padding': '8px 16px',
                                'background': '#f1f1f1',
                                'border': '1px solid #ccc',
                                'border-radius': '4px',
                                'cursor': 'pointer'
                            })
                            .on('click', function() {
                                if (typeof window.wdiCloseModal === 'function') {
                                    window.wdiCloseModal();
                                }
                            })
                    );
                
                modalContent.append(modalButtonContainer);
                inserted = true;
                console.log('Botón insertado en ventana flotante con contenedor especial');
            }
        }
        
        // Opción 2: Después del contenedor de resultados (fuera de modal)
        if (!inserted) {
            const resultsContainer = $('#dwoosync-results');
            if (resultsContainer.length > 0) {
                resultsContainer.after(selectButton);
                inserted = true;
                console.log('Botón insertado después de #dwoosync-results');
            }
        }
        
        // Opción 3: Dentro del metabox de Discogs (fuera de modal)
        if (!inserted) {
            const discogsMetabox = $('.wdi-discogs-data, #wdi-discogs-metabox .inside');
            if (discogsMetabox.length > 0) {
                discogsMetabox.append(selectButton);
                inserted = true;
                console.log('Botón insertado en metabox de Discogs');
            }
        }
        
        // Opción 4: Buscar cualquier contenedor con clase wdi (fuera de modal)
        if (!inserted) {
            const wdiContainer = $('[class*="wdi"]').last();
            if (wdiContainer.length > 0) {
                wdiContainer.after(selectButton);
                inserted = true;
                console.log('Botón insertado después de contenedor WDI');
            }
        }
        
        // Opción 4: Fallback - crear un contenedor específico
        if (!inserted) {
            const container = $('<div>')
                .attr('id', 'wdi-image-selector-container')
                .css({
                    'background': '#f0f8ff',
                    'border': '1px solid #0073aa',
                    'border-radius': '4px',
                    'padding': '15px',
                    'margin': '15px 0'
                })
                .append(
                    $('<h4>')
                        .text('✨ Imágenes de Discogs disponibles')
                        .css({
                            'margin-top': '0',
                            'color': '#0073aa'
                        }),
                    $('<p>')
                        .text('Se encontraron imágenes de este lanzamiento. Selecciona cuáles agregar a la galería del producto.')
                        .css({
                            'margin': '10px 0',
                            'color': '#666'
                        }),
                    selectButton
                );
            
            // Buscar un lugar para el contenedor
            const targetSelectors = [
                '#normal-sortables',
                '#postdivrich',
                '#wpbody-content .wrap'
            ];
            
            for (let selector of targetSelectors) {
                const target = $(selector).first();
                if (target.length > 0) {
                    target.prepend(container);
                    inserted = true;
                    console.log('Contenedor de botón insertado en:', selector);
                    break;
                }
            }
        }
        
        if (!inserted) {
            console.error('No se pudo insertar el botón de selección de imágenes');
        }
    }
    
    function updateGalleryDisplay(newGalleryIds, allGalleryIds, imageData) {
        console.log('Intentando actualizar galería con:', imageData);
        
        // Múltiples selectores para encontrar la galería de WooCommerce
        const possibleSelectors = [
            '#product_images_container ul.product_images',
            '.product_images',
            '#product_images_container .product_images',
            '.woocommerce_product_images',
            '#woocommerce-product-images ul',
            '.wc-metabox-content .product_images'
        ];
        
        let galleryContainer = null;
        
        // Buscar el contenedor correcto
        for (let selector of possibleSelectors) {
            galleryContainer = $(selector);
            if (galleryContainer.length > 0) {
                console.log('Galería encontrada con selector:', selector);
                break;
            }
        }
        
        // Si no encontramos la galería, buscar de forma más amplia
        if (!galleryContainer || galleryContainer.length === 0) {
            console.log('Buscando galería de forma alternativa...');
            galleryContainer = $('ul').filter(function() {
                return $(this).find('li.image').length > 0 || $(this).hasClass('product_images');
            }).first();
            
            if (galleryContainer.length > 0) {
                console.log('Galería encontrada con búsqueda alternativa');
            }
        }
        
        if (galleryContainer && galleryContainer.length > 0 && imageData) {
            console.log('Actualizando galería WooCommerce con imágenes:', imageData);
            
            // Agregar las nuevas imágenes
            imageData.forEach(function(image, index) {
                // Crear HTML compatible con WooCommerce
                const newImageHtml = $(`
                    <li class="image" data-attachment_id="${image.id}">
                        <img src="${image.thumb || image.url}" alt="Imagen ${index + 1}" width="150" height="150" />
                        <ul class="actions">
                            <li><a href="#" class="delete" title="Eliminar imagen">×</a></li>
                        </ul>
                    </li>
                `);
                
                // Insertar la imagen
                const addButton = galleryContainer.find('li.add-image, .add-image');
                if (addButton.length > 0) {
                    addButton.before(newImageHtml);
                } else {
                    galleryContainer.append(newImageHtml);
                }
            });
            
            // Actualizar el campo oculto de la galería
            const galleryInputs = [
                'input#product_image_gallery',
                'input[name="product_image_gallery"]',
                '#product_image_gallery'
            ];
            
            for (let inputSelector of galleryInputs) {
                const galleryInput = $(inputSelector);
                if (galleryInput.length > 0 && allGalleryIds) {
                    const newValue = allGalleryIds.join(',');
                    galleryInput.val(newValue);
                    console.log('Campo galería actualizado:', newValue);
                    break;
                }
            }
            
            // Disparar eventos para que WooCommerce detecte los cambios
            galleryContainer.trigger('change');
            $(document).trigger('woocommerce_gallery_updated');
            
            console.log('Galería actualizada visualmente');
        } else {
            console.log('No se pudo encontrar el contenedor de galería de WooCommerce');
            console.log('Contenedores disponibles:', $('ul').map(function() { return this.className; }).get());
        }
    }
    
    function updateProductGalleryDisplay(galleryIds) {
        // Función legacy - mantener por compatibilidad
        console.log('Galería actualizada con IDs:', galleryIds);
    }
    
    function restoreBeforeUnloadWarning() {
        // Restaurar el comportamiento original de WordPress solamente si había cambios pendientes
        setTimeout(function() {
            if (typeof wp !== 'undefined' && wp.data && wp.data.select('core/editor')) {
                // Para Gutenberg
                window.onbeforeunload = function(e) {
                    if (wp.data.select('core/editor').hasUnsavedChanges()) {
                        return true;
                    }
                };
            } else {
                // Para editor clásico, no restaurar el warning automáticamente
                // ya que las imágenes han sido guardadas exitosamente
                console.log('Imágenes guardadas, no restaurando warning de salida');
            }
        }, 1000);
    }
    // --- FIN: Event listener para botón "Agregar imágenes a la galería" ---

})( jQuery );

