=== DWooSync ===
Contributors: dwoosync
Tags: discogs, woocommerce, import, music, vinyl
Requires at least: 5.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Import music products from Discogs.com database directly into your WooCommerce store with complete product information.

== Description ==

DWooSync is a powerful WordPress plugin that seamlessly integrates Discogs.com's extensive music database with your WooCommerce store. Import detailed product information for vinyl records, CDs, cassettes, and digital music releases with just a few clicks.

**Key Features:**

* **Direct Discogs Integration** - Connect to Discogs.com API to access millions of music releases
* **Complete Product Import** - Import titles, artists, genres, release dates, images, and more
* **Multiple Format Support** - Works with vinyl, CD, cassette, and digital releases
* **Smart Search & Filter** - Search by release ID, catalog number, or matrix number
* **Year-based Filtering** - Filter releases by decade or specific year ranges
* **Bulk Operations** - Import multiple products efficiently
* **Image Gallery Import** - Automatically import multiple product images
* **Category Auto-mapping** - Automatically assign WooCommerce categories based on genres
* **Price Management** - Quick price field for easy pricing
* **Multilingual Support** - Available in English and Spanish
* **Spotify Integration** - Optional Spotify player integration for product pages

**Perfect for:**

* Record stores and music retailers
* Vinyl collectors selling their collections
* Online music merchandise stores
* Discogs sellers expanding to WooCommerce
* Any music-related e-commerce business

**How it Works:**

1. Install and configure your Discogs API credentials
2. Search for releases using Discogs release IDs or catalog numbers
3. Preview complete product information before importing
4. Import with one click - all data is automatically populated
5. Fine-tune product details and pricing as needed

**API Integration:**

This plugin uses the official Discogs.com API to fetch product information. You'll need free Discogs API credentials to use this plugin. The plugin respects Discogs' rate limits and terms of service.

**Data Imported:**

* Product title and description
* Artist information
* Genre and style classifications
* Release year and label information
* Track listings
* Multiple product images
* Format details (vinyl size, CD type, etc.)
* Catalog and matrix numbers

== Installation ==

1. Upload the plugin files to `/wp-content/plugins/dwoosync/` directory, or install through WordPress admin
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Go to WooCommerce > DWooSync to configure your settings
4. Enter your Discogs API credentials (get them free at discogs.com/developers)
5. Configure your import preferences and start importing!

**Minimum Requirements:**

* WordPress 5.0 or higher
* WooCommerce 3.0 or higher
* PHP 7.4 or higher
* Valid Discogs API credentials

== Frequently Asked Questions ==

= Do I need a Discogs account? =

Yes, you need a free Discogs account to obtain API credentials. Visit discogs.com/developers to create your API application.

= Is this plugin free? =

The plugin is free to use with basic functionality. Premium features may require a subscription.

= What music formats are supported? =

The plugin supports all formats available in the Discogs database: vinyl (all sizes), CDs, cassettes, digital releases, and more.

= Can I import images? =

Yes, the plugin can import multiple images for each release, including cover art and additional photos.

= Does it work with variable products? =

Currently, the plugin creates simple products. Variable product support is planned for future releases.

= Is there bulk import functionality? =

Yes, you can search and import multiple releases efficiently using the bulk operations features.

== Screenshots ==

1. Main import interface with search functionality
2. Product preview modal with complete Discogs information
3. Configuration screen with API settings
4. Imported product with complete information and images
5. Category mapping and quick pricing tools

== Changelog ==

= 1.0.0 =
* Initial release
* Discogs API integration
* Product search and import functionality
* Image gallery import
* Category auto-mapping
* Multilingual support (English/Spanish)
* Quick pricing tools
* Spotify integration support
* Bulk import operations

== Upgrade Notice ==

= 1.0.0 =
Initial release of DWooSync. Install to start importing music products from Discogs into your WooCommerce store.

== Additional Information ==

**Support:**
For support and documentation, visit our website or contact us through the WordPress support forum.

**Data Usage:**
This plugin connects to the Discogs.com API to retrieve product information. No personal data is sent to third-party services except for the API requests necessary to fetch product details.

**Credits:**
We thank Discogs.com for providing access to their comprehensive music database through their API.

== Privacy Policy ==

This plugin does not collect or store personal user data. It only makes API requests to Discogs.com to retrieve product information based on user searches. All product data imported remains on your WordPress installation.