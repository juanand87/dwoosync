<?php
/**
 * Plugin Name:       DWooSync
 * Plugin URI:        https://dwoosync.com/
 * Description:       Import information from the Discogs.com database directly into your WooCommerce products via their API. We thank Discogs.com for providing this data.
 * Version:           1.0.0
 * Author:            DWooSync
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       dwoosync
 * Domain Path:       /languages
 * WC requires at least: 3.0
 * WC tested up to: 8.0
 */

// Si este archivo es llamado directamente, abortar.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Declara la compatibilidad con el Almacenamiento de Pedidos de Alto Rendimiento (HPOS).
 */
add_action( 'before_woocommerce_init', function() {
    if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
    }
} );

/**
 * Comprobar si WooCommerce está activado.
 */
function wdi_check_woocommerce_active() {
    // Verificar si WooCommerce está activo de forma más robusta
    $active_plugins = apply_filters( 'active_plugins', get_option( 'active_plugins', array() ) );
    
    // Asegurar que $active_plugins sea un array
    if ( ! is_array( $active_plugins ) ) {
        $active_plugins = array();
    }
    
    if ( in_array( 'woocommerce/woocommerce.php', $active_plugins ) ||
         class_exists( 'WooCommerce' ) ) {

        // Cargar la clase principal del plugin de forma segura
        add_action( 'plugins_loaded', 'wdi_init_plugin' );
    } else {
        // Mostrar una notificación de error si WooCommerce no está activo.
        add_action( 'admin_notices', 'wdi_woocommerce_not_active_notice' );
    }
}

/**
 * Muestra una notificación en el admin si WooCommerce no está activo.
 */
function wdi_woocommerce_not_active_notice() {
    ?>
    <div class="error">
        <p><?php esc_html_e( 'Discogs Importer requiere que WooCommerce esté instalado y activo. Por favor, active WooCommerce.', 'dwoosync' ); ?></p>
    </div>
    <?php
}

/**
 * Función para inicializar el plugin de forma segura.
 */
function wdi_init_plugin() {
    // Verificar que WooCommerce esté realmente cargado
    if ( ! class_exists( 'WooCommerce' ) ) {
        return;
    }

    // Cargar traducciones iniciales
    wdi_load_textdomain();

    // Cargar los archivos necesarios
    $core_file_path = __DIR__ . '/includes/class-wdi-core.php';
    if ( file_exists( $core_file_path ) ) {
        require_once $core_file_path;

        // Cargar la clase API client
        $api_client_path = __DIR__ . '/wordpress_integration/class-wdi-api-client.php';
        if ( file_exists( $api_client_path ) ) {
            require_once $api_client_path;
        }

        // Verificar que la clase existe antes de instanciarla
        if ( class_exists( 'WDI_Core' ) ) {
            $plugin = new WDI_Core();
        }
        
    }
}

/**
 * Sistema de traducciones basado en archivos .po
 */

// Variable global para controlar el idioma actual
$wdi_current_language = 'es'; // español por defecto

/**
 * Función para obtener el idioma actual desde configuración
 */
function wdi_get_current_language() {
    // Obtener configuración guardada
    $options = get_option('dwoosync_options');
    $plugin_language = isset($options['plugin_language']) ? $options['plugin_language'] : 'es_ES';
    
    // NOTA: Esta función solo lee configuración guardada en la base de datos
    // No procesa datos de formularios directamente para evitar warnings de nonce
    // Los datos de $_POST se procesan en callbacks AJAX con verificación de nonce
    
    // Devolver el idioma de configuración
    return ($plugin_language === 'en_US') ? 'en' : 'es';
}

/**
 * Función principal de traducción compatible con WordPress.org
 * Retorna contenido escapado automáticamente para seguridad
 */
function wdi_get_translation($text) {
    // Obtener el idioma configurado directamente de las opciones
    $options = get_option('dwoosync_options');
    $plugin_language = isset($options['plugin_language']) ? $options['plugin_language'] : 'es_ES';
    
    $result = '';
    
    // Si el idioma configurado es español, usar el texto original
    if ($plugin_language === 'es_ES') {
        $result = $text;
    }
    // Si es inglés, cargar textdomain y usar la traducción
    else if ($plugin_language === 'en_US') {
        // Cargar textdomain inglés
        wdi_load_textdomain('en');
        
        // Usar load_textdomain manualmente para evitar errores de WordPress.org
        global $l10n;
        if (isset($l10n['dwoosync']) && is_object($l10n['dwoosync']) && method_exists($l10n['dwoosync'], 'translate')) {
            $translated = $l10n['dwoosync']->translate($text);
            $result = ($translated !== $text) ? $translated : $text;
        } else {
            $result = $text;
        }
    }
    // Por defecto, devolver el texto original
    else {
        $result = $text;
    }
    
    // Escapar el contenido para cumplir con WordPress.org
    return esc_html($result);
}

/**
 * Cargar textdomain basado en el idioma actual
 */
function wdi_load_textdomain($language = null) {
    static $loaded_language = '';
    
    if ($language === null) {
        $language = wdi_get_current_language();
    }
    
    // Convertir formato corto a formato WordPress
    $locale = ($language === 'en') ? 'en_US' : 'es_ES';
    
    // Si ya está cargado el idioma correcto, no hacer nada
    if ($loaded_language === $locale) {
        return true;
    }
    
    // Descargar textdomain anterior si existe
    if (!empty($loaded_language)) {
        unload_textdomain('dwoosync');
    }
    
    // Cargar el nuevo textdomain
    $mo_file = plugin_dir_path(__FILE__) . 'languages/dwoosync-' . $locale . '.mo';
    
    if (file_exists($mo_file)) {
        $result = load_textdomain('dwoosync', $mo_file);
        if ($result) {
            $loaded_language = $locale;
            return true;
        }
    }
    
    return false;
}

/**
 * Cargar textdomain para inglés (mantener por compatibilidad)
 */
function wdi_load_english_textdomain() {
    return wdi_load_textdomain('en');
}

/**
 * Función para cambiar idioma via AJAX
 */
function wdi_ajax_change_language() {
    global $wdi_current_language;
    
    // Verificar nonce de seguridad
    check_ajax_referer('wdi_language_nonce', 'nonce');
    
    // Nonce ya verificado - seguro procesar $_POST
    if (isset($_POST['language'])) {
        $language = sanitize_text_field(wp_unslash($_POST['language']));
        
        if (in_array($language, ['es', 'en'])) {
            $wdi_current_language = $language;
            
            wp_send_json_success([
                'language' => $language,
                'message' => 'Idioma cambiado correctamente'
            ]);
        }
    }
    
    wp_send_json_error('Idioma no válido');
}

// Hook para AJAX
add_action('wp_ajax_wdi_change_language', 'wdi_ajax_change_language');
add_action('wp_ajax_nopriv_wdi_change_language', 'wdi_ajax_change_language');

/**
 * Inicializar sistema de actualizaciones automáticas
 */
function dwoosync_init_updater() {
    if (is_admin()) {
        $updater_file = plugin_dir_path(__FILE__) . 'includes/class-plugin-updater.php';
        if (file_exists($updater_file)) {
            require_once $updater_file;
            new DWooSync_Plugin_Updater(__FILE__);
        }
    }
}
add_action('init', 'dwoosync_init_updater');

/**
 * Modificar los enlaces del plugin para que se abran en nueva pestaña y agregar enlace de configuración.
 */
function dwoosync_plugin_row_meta($links, $file) {
    if (plugin_basename(__FILE__) == $file) {
        // Agregar enlace de configuración
        $settings_link = '<a href="' . admin_url('admin.php?page=dwoosync') . '">Settings</a>';
        array_unshift($links, $settings_link);
        
        // Modificar el enlace del sitio del plugin para que se abra en nueva pestaña
        foreach ($links as &$link) {
            if (strpos($link, 'https://dwoosync.com') !== false) {
                $link = str_replace('<a ', '<a target="_blank" ', $link);
            }
        }
    }
    return $links;
}
add_filter('plugin_row_meta', 'dwoosync_plugin_row_meta', 10, 2);

// Iniciar la comprobación.
wdi_check_woocommerce_active();
